# Qwen3.5-27B 整模型对齐记录

日期：2026-11-01。使用本地真实 checkpoint、conda lumina、两张 A100 80GB。

## 结论

基础单卡文本推理通过本轮行为检查：两种 HF attention 后端下，各 8 条请求 × 8 步，共 64 个 next-token argmax 均与 Lumina 一致。比较使用相同 token 历史，包含真实引擎调度、分块 prefill 和递归状态复用。

**严格 raw logits 检查尚未通过**。脚本保留非零退出状态与原定阈值（max_abs≤1.0，RMSE≤0.1，近邻 argmax gap≤0.25），未根据结果放宽阈值。不能把 top-1 一致解释为逐元素一致或完整适配验收。

## 本次修复

- DeltaNet gated RMSNorm：按 HF 的 bf16 顺序舍入 recurrence 输出、归一化输出及 weight 乘积，再应用 fp32 SiLU gate。
- Qwen3.5 partial RoPE：cos/sin 转到激活 dtype，保留 bf16 中间乘积的舍入；只影响 Qwen3.5，保留其他模型的共用 RoPE。
- 两项独立 GPU 单测与 HF 对应函数逐元素精确一致。算子和调度回归合计 15 项通过。

## 当前版本结果

| HF 后端 | 请求数 | 比较步骤 | top-1 一致 | 最大绝对偏差 | 最大 RMSE | 原阈值失败步骤 |
|---|---:|---:|---:|---:|---:|---:|
| SDPA | 8 | 64 | 64/64 | 7.546875 | 1.106640 | 29 |
| FlashAttention 2 | 8 | 64 | 64/64 | 8.875000 | 1.416720 | 28 |

覆盖：中英文短请求；65/257/513-token 不等长批处理；128-token 预算下的分块 prefill；重复长前缀；相同前缀不同后缀；请求结束后的状态槽复用。每个请求生成 8 个 token。

## 参考模型自身的数值对照

同一 HF bf16 模型、FlashAttention 2、相同 token 历史，仅将单请求改为重复的双请求：

| prompt 长度 | 最大绝对偏差 | 最大 RMSE | top-1 一致 |
|---|---:|---:|---:|
| 65 | 2.500000 | 0.536386 | 8/8 |
| 257 | 8.421875 | 0.999954 | 8/8 |
| 513 | 3.375000 | 0.368341 | 8/8 |

这说明该重复文本负载下，batch 形状引入的 bf16 差异本身就可能超过原阈值。它解释了不能仅凭 raw logits 阈值判断架构错误，但不证明 Lumina 的全部剩余误差均来自舍入。

逐层诊断：修复后的相同 FlashAttention 后端下，单条 65-token 请求前 7 层 hidden states 精确一致；抽查 7 个线性注意力层在相同 HF hidden states 上精确一致。抽查 full attention 的最大输出差异为 0～0.03125。

## 复现

在 Lumina 目录、GPU 可访问的会话运行（完整模型对齐默认需要两张约 80GB GPU）：

```bash
conda activate lumina
python -m pytest tests/test_gated_delta.py tests/test_scheduler_state.py -q
python -m benchmarks.validate_qwen35
python -m benchmarks.validate_qwen35 --hf-attention flash_attention_2 --output benchmarks/qwen35_alignment_flash2.json
python -m benchmarks.diagnose_qwen35
python -m benchmarks.check_qwen35_hf_batch
```

原始数据：benchmarks/qwen35_alignment.json、qwen35_alignment_flash2.json、qwen35_layer_diagnostics.json、qwen35_hf_batch_sensitivity.json。整模型对齐报告含实现源码 SHA256。before_* 报告保存修复过程的失败结果。

## 边界与待验收项

尚未覆盖超长上下文、大规模并发、GPU 抢占恢复与完整服务请求；TP、CUDA Graph、视觉输入仍未支持。需扩充非重复自然文本案例，建立数值误差基线，再制定正式 logits 验收标准。本次修改后未重测性能，之前 7.8% 的收益仅对应前一版本。
