# 简历准备文档

## 1. 项目叙事（为什么做、解决了什么）

> 为了**深入理解 LLM 推理引擎的底层机制**（而非仅作黑盒调用 API），从零实现了一个 vLLM 风格的推理引擎。除复现社区标配能力外，在四个关键路径做了针对性工作：**EP 专家并行**（让 MoE 模型用 all-to-all 路由分布到多卡）、**手写 paged decode attention**（GQA 共享 KV，把自研 kernel 追到 flash-attn 的 1.05x）、**FP8 KV cache**（显存优化）、**手写 Triton 采样**（低开销、可复现）。跑通真实 Qwen3-32B（dense）和 Qwen3-30B-A3B（MoE），吞吐接近官方 vLLM。

**一句话定位**：不是「复刻 vLLM」，而是「通过从零实现来掌握推理引擎的核心技术，并在关键路径上做了工业级实践」。面试时要主动讲清楚这个动机，避免被质疑「重做轮子」。

## 2. 核心亮点 vs 标准工程能力

### 标准工程能力（社区标配，复现掌握）

- Paged Attention、chunked prefill、连续批处理、抢占式调度、前缀缓存
- 张量并行（TP）、CUDA Graph

这些是「我会做」的证明，但面试时**不要花大篇幅讲**——是 vLLM 社区标配。

### 核心亮点（差异化，重点展开）

1. **EP 专家并行 + TP/EP 维度解耦**：MoE 专家用 all-to-all 路由分布到 8 卡，跑通 Qwen3-30B-A3B（128 专家 top-8）。难点在于把 TP 与 EP 两个并行维度解耦（KV cache 的头切分属 TP 维度，EP 下非 MoE 层 replicated）。
2. **手写 paged decode attention**：自研 Triton decode 注意力内核替代 `flash_attn_with_kvcache`，两处优化把性能从 8.84x 追到 1.05x（vs flash-attn）：**GQA shared-KV**（grid 从 `num_heads` 改成 `num_kv_heads`，KV 读取降 8x）+ **tensor core 小 tile**（BLOCK_N=64，避免整页 256 tile 的寄存器 spill）。还诚实记录了一个 negative result：split-K 对 memory-bound decode 不划算（并行度提升被 reduce 开销抵消），试过并回退。
3. **手写 Triton 采样内核**：top_k/top_p 二分阈值 + Gumbel-max + Philox 可复现，全程无 Python 层循环，`O(vocab)` 而非 `O(vocab log vocab)`。
4. **FP8 KV cache**：e4m3 + per-token scale，显存减半（533 → 1062 blocks）。
5. **完整正确性测试**：23 项测试，logits 与 HuggingFace 逐元素对齐，覆盖前缀缓存 / chunked prefill / TP / EP 多路径（很多引擎 MoE + 抢占的组合路径测不全）。

## 3. 简历 bullet（5 条，每条都带量化 + 具体技术点）

> 原则：**每一条 = 动作 + 技术方案 + 量化结果**，亮点（EP / Triton / FP8 / 测试）放最前面，标准工程能力（连续批处理 / Paged Attention / CUDA Graph）作为铺垫打包进第 1 条。

1. 从零实现 LLM 推理引擎，手写 continuous batching、**自研 paged decode attention**（block table 分页 + GQA shared-KV + tensor core，性能追平 flash-attn）、chunked prefill、LIFO 抢占式调度、decode 阶段按 batch 分桶做 CUDA Graph；**Qwen3-32B（4×A100 TP=4）吞吐达 vLLM 的 87–98%（随 workload），前缀缓存（vs 无缓存）+53% 吞吐 / TTFT p99 降 71%**。
2. 设计并实现**专家并行（EP）**：all-to-all 路由将 MoE 专家分布到 8 卡（router replicated），并独立记录 TP 维度以支持 EP 下非 MoE 层 replicated；跑通 Qwen3-30B-A3B（30B 总参 / 3B 激活，128 专家 top-8），**TP=4 与 EP=8 结果一致**。
3. 手写 **Triton 采样内核**（top_k/top_p 二分阈值 + Gumbel-max + Philox，`O(vocab)` 免排序）；实现 **FP8 KV cache** 量化（e4m3 + per-token scale），显存减半（**533 → 1062 blocks**）。
4. 建立 **23 项正确性测试**，logits 与 HuggingFace 逐元素对齐，用「噪声阈值 + 近邻 tie」量化分析区分真 bug，覆盖前缀缓存 / chunked prefill / TP / EP 多路径。
5. 封装 **OpenAI 兼容 SSE 流式服务**（异步引擎 + continuous batching），逐 token 记录时间戳；**真实 Poisson 负载下 TTFT p99 281ms（32B），高并发尾延迟低于 vLLM**。

## 4. 量化指标 + 基准测试条件

| 指标 | 数值 |
|---|---|
| 吞吐（vs vLLM） | 见下表 |
| KV cache 显存 | FP8 后容量翻倍（533 → 1062 blocks） |
| 模型规模 | Qwen3-30B-A3B（30B 总参/3B 激活，128 专家）|
| 并行 | TP（1~4）+ EP（8 卡）|
| 测试 | 23 项正确性测试 |

### vs 官方 vLLM 0.11.0 吞吐对比

| 配置 | zjh-vllm | vLLM 0.11.0 | 对比 |
|---|---|---|---|
| Qwen3-0.6B，单卡 | 10368 tok/s | 8159 tok/s | +27% |
| Qwen3-32B，4×A100（TP=4） | 2997 tok/s | 3069 tok/s | -2.4%（97.6%） |

**基准测试条件（被问到时能说清楚，数字才有说服力）**：

- 模型：Qwen3-32B；硬件：4×A100 80GB，TP=4
- workload：256 条并发序列，**随机 token**（`randint(0,10000)`，非真实文本），input 100~1024 / output 100~1024 均匀随机
- 采样：`temperature=0.6, ignore_eos=True`
- CUDA Graph：开（仅 decode 阶段）；FP8 KV：**关**（bf16）；前缀缓存：不触发（随机 prompt 无共享前缀）
- 指标：吞吐 = 总生成 token / 总时间（端到端，含调度，不含模型加载）；先 warmup 再计时

> 诚实提醒：吞吐数字**强依赖 workload 的 input:output 比**（「吞吐」分母只算 output token）。上面 32B 的 97.6% 是固定随机负载（input/output 各 100~1024 均匀）；换成重尾短请求负载（中位 input 181 / output 74），vLLM 略快，zjh ≈ 87%。所以面试时说「87–98%，随 workload」比说「98%」更严谨，也更经得起追问。

### paged decode attention 性能（自研 kernel vs flash-attn）

自研 Triton decode kernel（`zjhvllm/layers/paged_attention.py`）替代 `flash_attn_with_kvcache`，用 [benchmarks/bench_paged_attention.py](../benchmarks/bench_paged_attention.py) 扫 batch × ctx 对比，两版优化：

| case | v1（逐 Q 头 naive） | v2（GQA shared-KV + tensor core） |
|---|---|---|
| batch 256 / ctx 4096 | 8.84x | **1.05x** |
| batch 128 / ctx 1024 | 4.87x | **1.12x** |
| batch 32 / ctx 4096 | 3.42x | **0.85x**（反超） |

- 正确性：与 `flash_attn_with_kvcache` 逐元素对比，max abs diff 0.001953（bf16 噪声内），见 [tests/test_paged_attention.py](../tests/test_paged_attention.py)。
- batch ≥ 32（真实连续批处理区间）全程 0.85–1.12x，追平/反超 flash-attn。
- 剩余差距在小 batch 长 context（batch=1 / ctx=4096 约 3–6x）：只有 `num_kv_heads=8` 个 program 喂 108 SM，是**并行度问题**，不是算法问题。

> 关键认知：这个 kernel 的含金量不在「最终比 flash-attn 快多少」，而在**从 8.84x 追到 1.05x 的诊断过程**——定位到「GQA 没复用 KV 读取（8 个 Q 头各读一遍同一 KV）+ 整页 256 tile 撑爆寄存器」，然后对症改。面试讲「我一眼能看出慢在哪」比「我跑得和 flash-attn 一样快」更能证明掌握。

### 延迟 + 前缀缓存（真实负载，重尾长度 + 共享前缀 + Poisson 到达）

用 [benchmarks/bench_trace_zjh.py](../benchmarks/bench_trace_zjh.py)（open-loop，2000 条 Poisson 到达）测真实负载下的尾延迟，样本量 256 → 2000：

| 配置 | TTFT p99 | 说明 |
|---|---|---|
| Qwen3-0.6B，单卡，2000 条 rate=50/s | **39ms** | 旧「256 条同时到达」是 916ms（同时排队 artifact） |
| Qwen3-32B，TP=4，1000 条 rate=10/s | **281ms** | ITL p99 226ms |

前缀缓存收益（公平 abl，等长 1024-token 前缀，共享 vs 各不同，256 并发饱和）：

| 指标 | 共享前缀（缓存命中） | 唯一前缀（无缓存） | 收益 |
|---|---|---|---|
| 吞吐 | 6665 tok/s | 4348 tok/s | **+53%** |
| TTFT p99 | 681ms | 2357ms | **-71%** |

并发扫描（[bench_sweep_zjh.py](../benchmarks/bench_sweep_zjh.py)）也印证：高并发下 zjh 的 p99 尾延迟低于 vLLM（32B 256 并发 4108ms vs vLLM 4861ms）。

> 关键认知：旧的「p99 比 vLLM 低 62%/73%」是在「同时到达」的 artifact 负载上测的（两边 p99 都被同时排队放大，vLLM 调度更复杂被放得更大），不可辩护。可辩护的是**真实 open-loop 下的绝对 p99（281ms/39ms）** + **前缀缓存 +53%/-71%** + **高并发尾延迟优于 vLLM**。

## 5. Tradeoff 与局限性（评审/面试很看重）

| 取舍点 | 现状 | 代价 / 未做 |
|---|---|---|
| 抢占式调度 | LIFO 抢占，被抢占序列 KV 直接丢弃 | 恢复需重新 prefill，**频繁抢占时吞吐下降**；未量化抢占开销 |
| FP8 KV cache | e4m3 + per-token scale | ~3% 精度损失；**只做了 logits 对齐，未测 PPL / 下游评测（MMLU 等）** |
| EP all-to-all | 专家分布到多卡 | **通信开销未量化**；**负载不均衡未处理**（无 aux loss，可能专家热点） |
| CUDA Graph | 仅 decode 阶段 | prefill 走 eager，**长 prompt 未加速**；不支持 chunked prefill 的 graph |
| 延迟 | 已补 TTFT / ITL / p99（引擎记录时间戳 + `bench_trace_*.py`），真实负载 + 2000 样本 | 仍是固定 Poisson 速率（rate 参数），未用真实 ShareGPT 长尾 trace 文件；未测真实多轮对话/系统提示混合 |
| 自研 paged decode attention | bf16 路径手写 Triton kernel，batch≥32 追平/反超 flash-attn | 仅 bf16（fp8 decode 仍走 `gather_dequant`）；小 batch 长 context 落后 3–6x（并行度问题，非算法问题）；split-K 试过、不划算、回退 |

面试时主动说「我知道这里还有不足 + 怎么改进」，比只讲成果更可信。比如：
- FP8 精度：可以说「下一步会用 MMLU/PPL 评估精度损失，参考 vLLM 的 FP8 校准方案」。
- EP 负载均衡：可以说「参考 DeepSeek 的 aux loss，或 vLLM 的 expert 均衡策略」。
- 延迟：可以说「已用真实负载（重尾 + 前缀 + Poisson 到达）测了 TTFT p99（32B 281ms / 0.6B 39ms），下一步换成真实 ShareGPT 长尾 trace 文件 + 多轮对话 + 系统提示混合，进一步逼近生产」。

## 6. 面试高频问题与参考答案

### 6.1 为什么 decode 是 memory-bound、prefill 是 compute-bound？

- **Decode**：每步只算 1 个 token，attention 计算量 `O(context_len)`，但权重 `O(1)` 次访问。瓶颈是**读权重和 KV cache 的带宽**，而非算力 → memory-bound。
- **Prefill**：一次性算完整 prompt，`num_tokens` 大，attention `O(n²)`，计算量大且能并行 → compute-bound。
- 这也是 decode 用 CUDA graph、prefill 用 chunked 分批的原因。

### 6.2 Paged Attention 解决什么？block_table 怎么索引？

- 传统 KV cache 按 `[batch, max_len, ...]` 预分配连续显存，按最大长度分配浪费严重，且无法共享前缀。
- **Paged Attention** 把 KV cache 切成固定大小的物理块，序列通过 `block_table`（逻辑块 → 物理块映射）引用，按需分配/释放。
- `block_table[seq][i]` 给出第 i 个逻辑块的物理块 id；token t 落在 `block_table[seq][t // block_size]` 块的 `t % block_size` 位置。

### 6.3 连续批处理里 prefill 和 decode 怎么交替？为什么 decode 优先？

- 调度器维护 waiting / running 两个队列，每轮 `step()` 决定做 prefill 还是 decode。
- **Decode 优先**：已投入的 running 序列持续产出 token，避免新来的长 prefill 请求饿死已有请求。
- 交替旗标平衡：waiting 和 running 都非空时每轮切换一次，保证新请求不被饿死。

### 6.4 前缀缓存怎么实现？hash 碰撞怎么处理？抢占策略？

- 对每个物理块的 token 序列算 xxhash 指纹，存入 `hash → block_id` 字典，新序列逐块比对命中则复用。
- **碰撞处理**：命中时再比对 `block.token_ids == 当前 token 序列`（二次校验），不一致视为未命中。
- **抢占**：KV 块不足时，按 LIFO 抢占 running 队尾序列（最晚调度、影响最小），释放块、放回 waiting。

### 6.5 张量并行哪些层 column/row parallel？为什么 row 要 all-reduce？

- **Column-parallel**（QKV、gate_up）：按输出维度切分，每卡算一部分 head/专家，**不通信**。
- **Row-parallel**（o_proj、down_proj）：按输入维度切分，每卡输入是上一层的部分输出，算完**需 all_reduce 汇总**。
- 本质：column 输入完整、输出局部；row 反之。

### 6.6 MoE 的 router 怎么工作？EP 的 all-to-all 做了什么？

- **Router**：`Linear(hidden, num_experts)` 输出路由 logits，`top-k` 选活跃专家，`softmax` 得权重。
- **稀疏激活**：每 token 只算 top-k 专家，计算量由「激活参数」决定，而非「总参数」。
- **EP + all-to-all**：专家权重分布多卡。token 的活跃专家可能在其他卡，先 `all-to-all` dispatch hidden state 到专家所在卡，算完再 combine 回来加权求和。
- 关键：router replicated，非 MoE 层可 TP 或 replicated，这是 TP 与 EP 两个维度的解耦。

### 6.7 FP8 KV cache 怎么量化？为什么能省显存？

- KV 用 `float8_e4m3fn`（1 字节）替代 bf16（2 字节），显存减半。
- **per-token scale**：每 token 的 K/V 各算 `scale = max(|x|)`，`x_fp8 = x / scale`，读时 `x = x_fp8 * scale`。scale 存 fp32，开销仅 `4/head_dim ≈ 3%`。
- 数值误差 ~3%（e4m3 有 3 位尾数）。

### 6.8 CUDA Graph 为什么能加速 decode？

- Decode 每步只算 1 token，kernel launch 开销相对计算占比大。
- CUDA Graph 把整套 kernel 序列捕获成一张图，一次 replay 执行，消除逐个 launch 的 CPU 开销。
- 按 batch 分桶（1/2/4/8/…），因为 graph 要求固定形状。

### 6.9 采样器的 top_k/top_p 怎么实现？Gumbel-max 是什么？

- **top_k**：二分查找第 k 大 logit 阈值（`ITERS=14` 次），低于阈值置 `-inf`，`O(vocab)` 而非排序的 `O(vocab log vocab)`。
- **top_p（nucleus）**：在 top-k 保留集上二分概率累积阈值，保留累计概率 ≤ p 的最小集合。
- **Gumbel-max**：`argmax_i(logit_i + Gumbel_i)` 等价于从 softmax 采样（`Gumbel(0,1) = -log(-log(U(0,1)))`），免显式 softmax。

### 6.10 你怎么保证实现是对的？

- **logits 对齐**：前向 logits 与 HF 逐元素对比。flash-attn vs SDPA 有 ~0.1~0.4 噪声，用 `max_abs_diff < 1.0` 区分「噪声」和「真 bug」。
- **greedy 近邻 tie**：某步 top1-top2 gap 小于噪声时 argmax 翻转、级联发散（预期）。测试在分歧点验证 HF 的 top1-top2 gap 来区分。
- **多路径对比**：batch == 单条、前缀缓存/chunked prefill == HF、TP 与 EP == 单卡。

### 6.11 自研 paged decode attention 的两处优化是什么？split-K 为什么回退？

- **GQA shared-KV**：decode 里每个序列只有 1 个 Q token，Q 是 `[head_dim]` 向量，attention 是 GEMV。v1 的 grid 是 `(num_seqs, num_heads)`，8 个共享同一 KV 头的 Q 头**各自读一遍同一 KV**（8x 冗余带宽）。v2 改成 `(num_seqs, num_kv_heads)`，一个 program 读一遍 KV 喂给 8 个 Q 头，KV 读取量降 8x——这是 memory-bound decode 的全部游戏。
- **tensor core 小 tile**：v1 用整页 `block_size=256` 做单 tile，把 `[256, head_dim]` 的中间量撑爆寄存器、疯狂 spill。v2 切成 64 一个 tile，Q 补零到 16 行走 `tl.dot`（MMA），score 和 p·V 都吃 tensor core，不再 spill。
- **split-K 为什么回退**：小 batch 长 context 时只有 `num_kv_heads` 个 program，108 SM 吃不满，本想按 token 切段并行（split-K）+ reduce 重归一化。但 decode 是 memory-bound，切段**不减 KV 读取量**，partial 缓冲区写入 + reduce kernel 启动的开销把并行度收益抵消了，只在 batch=8/ctx=4096 一个格子有收益，却让 batch=8/ctx=1024 从 1.40x 退化到 2.58x。所以回退，留注释记录 negative result。

## 7. 讲述框架（STAR）

- **S**：想深入理解 LLM 推理引擎底层，而非黑盒调用，于是从零实现。
- **T**：复现核心推理技术，并在关键路径（EP/FP8/采样）做针对性工作，跑通真实模型。
- **A**：逐模块实现（调度器/块管理器/并行/采样/量化），正确性测试驱动，跑通 Qwen3-32B 和 Qwen3-30B-A3B（MoE，TP + EP）。
- **R**：32B 吞吐达 vLLM 87–98%（随 workload）；前缀缓存 +53% 吞吐 / p99 降 71%；真实负载 TTFT p99 281ms（32B）；FP8 让 KV 容量翻倍；30B MoE 用 EP=8 跑通；23 项测试全过。

## 8. 最能体现深度的 3 个点（主动引导面试）

1. **EP 接入**（TP/EP 维度解耦 + all-to-all + 专家权重按 rank 过滤）—— 分布式并行维度理解。
2. **手写 paged decode attention**（GQA shared-KV + tensor core，8.84x→1.05x + split-K negative result）—— kernel 性能优化与诊断能力。
3. **手写 Triton 采样内核**（top_k 二分阈值 + Gumbel-max + Philox 可复现）—— 算子级实现与数值理解。

（FP8 KV cache 与正确性测试仍是很强的点，放第 2/4 梯队：FP8 体现量化理解，测试体现工程严谨，只是不如上面三点「深」。）

---

*简历建议：技能栏 `PyTorch / Triton / NCCL / Flash Attention / 分布式推理（TP、EP）`；项目栏用 5 条 bullet + 1~2 个量化数字；面试主动讲「亮点 + 局限 + 改进方向」，而非只讲成果。*

## Qwen3.5 最新可核验成果（可选素材）

当前支持 Qwen3.5-27B 单卡文本推理：16 层 full attention 使用 paged KV，48 层 Gated DeltaNet 使用 fp32 recurrent state 与卷积历史。TP、CUDA Graph 和视觉输入尚未实现。2026-11-06 已接入真实 checkpoint MTP-1，但批量验证仍有数值验收失败，不能写成已实现通用无损投机加速。

可用于描述具体工作的素材：

> 基于 Nsight Systems 定位 Gated DeltaNet prefill 扫描热点，调整 Triton warp 配置以减少寄存器溢出；在单张 A100 80GB、Qwen3.5-27B、单请求 1024-token prefill 生成首 token 的 eager 场景中，相对原 IEEE 扫描实现耗时由 0.917s 降至 0.437s（约 2.10×），优化前后完整 logits 一致。

该数字是同引擎旧扫描路径的对照，**不是对 vLLM 的提升，也不是 decode 或并发吞吐指标**。计时包含调度、状态清零、采样与校验用 logits CPU 拷贝，排除加载及预热，3 次运行取中位数。

面试可讲的负结果：tf32x3 在算子测试中误差很小，但整模型首 token 回归失败，最终保留 IEEE FP32，只调整 warp 数。

原始数据、profile 和完整限制见 [PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md)；HF 严格 raw logits 验证尚有未过项，见 [ALIGNMENT.md](ALIGNMENT.md)。

## 八卡容量验证：最新简历指标与追问口径

简历已加入真实测得的八卡指标：Qwen3.5-27B **8 个单卡副本**，引擎原生闭环接口；1024 请求、128-token 输入 / 64-token 输出、总并发 128 时 **1157.5 output tok/s**，TTFT/TPOT p99 为 **2.17s/102.8ms**。这是单机副本容量，不是 Qwen3.5 TP=8，也未包含 HTTP/网络开销。

独立扩展测试保持每卡并发 8，1/2/4/8 卡分别为 82.7/163.9/324.0/649.6 output tok/s，1→8 的容量扩展 **7.85×、效率 98.2%**。每卡固定 128 条请求，属于弱扩展；单卡样本只有 128 条，不能把其 p99 当成稳定生产尾延迟。

面试应主动讲清楚的取舍：

- 总并发 64：649.6 tok/s，TTFT/TPOT p99=1.10s/95.7ms，本轮预设 2s/100ms SLO 下 1024/1024 达标。
- 总并发 128：1157.5 tok/s，TTFT/TPOT p99=2.17s/102.8ms，960/1024 达标（93.75%）；ITL p99 约 879ms，存在 prefill 打断 decode 的长停顿。
- Poisson 聚合 8 req/s：TTFT p99=216ms，TPOT p99≈102ms，957/1024 达标（93.46%）。这是 arrival-limited 结果，不能当饱和吞吐，也不能与闭环吞吐拼接。

方法论亮点：共同 makespan 聚合；从计划到达时刻计 TTFT；保留逐 token 原始时间戳；区分请求平均 TPOT 和 token 间隔 ITL；记录 SLO goodput 而非只报吞吐；896 次相同请求的跨副本数量对照输出 hash 全部一致。

当前没有同模型 vLLM 对照，现有 vLLM 0.11.0 未注册 Qwen3.5，不能宣称对 vLLM 加速。所有负载是固定长度合成文本，不是真实线上数据。完整证据见 [实验报告](benchmarks/service_8gpu/REPORT.md)。


## 调度路径优化：CPU 元数据缓存（2026-11-01）

默认复用 CPU 侧序列边界/状态槽，消除 48 层 Gated DeltaNet 对 GPU 标量的重复读取；原 alternating 调度与模型算术不变。4 副本、每卡并发 16、同一 1024 请求闭环复测，吞吐 573.7→602.1 output tok/s，ITL p99 879→688ms，预设 2s TTFT/100ms TPOT 门槛的 SLO goodput 7.284→9.408 req/s。nsys 单个 8 请求 prefill 的流同步 1154→2 次；27B 完整 logits 最大差异 0，1024/1024 输出 hash 一致。

这是单次固定长度合成负载，门槛附近的小变化会放大 goodput 的增益，不应宣称生产 SLA。bounded 预算策略虽降低 ITL，但闭环 goodput 明显下降，仅保留显式选项；混合执行因数值验收失败已撤回并归档。用户明确不需要 TP=8，勿扩展模型并行。复现和完整限制见 [SCHEDULING_OPTIMIZATION.md](SCHEDULING_OPTIMIZATION.md) 与 [实验报告](benchmarks/SCHEDULING_REPORT.md)。


## Qwen3.5 状态管理的新增证据（2026-11-06）

可以作为面试实现细节讲述：针对 Qwen3.5 混合注意力，构建请求级递归状态/卷积历史快照与私有 KV 验证窗口，处理草稿拒绝、页边界和异常恢复；接入 checkpoint 全部 15 组 MTP 权重，共享 embedding/LM head，独立维护草稿 KV 与条件配对。最终 71 项相关 CPU/GPU 回归通过。

当前默认草稿已改为真实 MTP-1。27B 三种输入各生成 32 token，serial 全部一致，草稿接受数为 13/17、15/15、15/15；MTP KV 写入后的故障恢复通过。serial 是无加速的正确性参考，批量实验仍有 1/3 组 token 分歧。暂不能把本轮写成“实现无损投机解码并获得加速”，也不能将历史测试专用 oracle 草稿的时间当成真实收益。范围和原始数据见 [SPECULATIVE_DECODING.md](SPECULATIVE_DECODING.md)。原有 HF raw-logits 验收失败仍保留。

## 混合负载基线与实验性自适应调度（2026-11-01）

2026-11-06 又完成 [MTP 八卡扩大对照](MTP_SCALE.md)：768 次生成、72,834 输出 token；串行参考 256/256 一致，批量实验 72/256 条分歧，接受率约 89.2%。可以讲跨卡可复现验证、状态回收与发现的精度边界；不能把未验收的吞吐差值写成有效加速。每卡只有1个活跃请求，不是高并发MTP能力。

旧Qwen3-0.6B批次一致性失败已定位：prefill相同，首次decode首层QKV GEMM输入相同、输出差0.001953125；第8个生成位置因单条路径候选同分而分叉。原严格断言保留，新增固定batch形状的请求重排隔离测试通过。不是把所有Qwen3.5误差都归因于近邻tie。

完成8×A100、两组四副本、交换GPU的两轮混合输入/输出长度与Poisson/突发对照，共3072请求、219264生成token。自适应策略根据执行耗时拟合与decode余量选择预算，并以TTFT保护推进队首请求；保持默认alternating。饱和闭环goodput约+39.7%，但吞吐−4.7%、SLO达标率仅16.6%；突发goodput−3.7%、TTFT p99约0.85s→1.81s，Poisson基本持平。

重要：跨策略1536对输出中400对不同；抽样16处HF共享历史审计有7处candidate相对baseline regret高出1以上，数值验收未通过，不能把性能数据写成已验收成果。adaptive是显式实验选项，不默认启用；不要放宽阈值或把所有分歧解释成BF16近邻tie。下一步应先根据HF自身参考路径对照定位长序列/缓存数值差异，再决定是否继续策略优化。详情见 [ADAPTIVE_SCHEDULING.md](ADAPTIVE_SCHEDULING.md) 与 [交叉实验报告](benchmarks/adaptive_holdout/REPORT.md)。

最终回归44 passed、1 failed；保留的失败为上述严格跨batch测试，日志/JUnit及源码快照校验均归档。没有扩展TP/EP，没有默认mixed执行，也没有用这些未验收数据改简历。


补充HF自身参考路径对照：上述16处真实共享历史中，HF的batch1完整、batch2完整与batch1缓存增量前向有11处top1不一致，最大logits差异分别达17.25/19.73；但仍有3处candidate在所有参考下相对baseline regret高出1以上。参考敏感性不能豁免剩余误差，adaptive仍未通过数值验收。证据见benchmarks/adaptive_holdout/hf_self_reference_audit.json。
