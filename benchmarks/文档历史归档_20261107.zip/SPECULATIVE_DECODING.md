# Qwen3.5 混合状态与投机验证

最新多卡验证Graph和连续补位已实现，使用与独立验收见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)。以下保留历史实验边界。

普通推理后续已扩展TP1/2/4/8及原生混合decode Graph，见 [QWEN35_TP.md](QWEN35_TP.md)。后续 MTP/投机已接入 TP1/2/4/8，见 [MTP_TP.md](MTP_TP.md)。本文件以下数字保留原单卡实验范围。

最新可选实验为 [SGLang批量执行移植](SGLANG_MTP_EXECUTION.md)：`qwen35_linear_backend="batch_invariant"` 对窗口批量投影、固定归约；135项相关回归通过，16输入两轮与同后端普通decode32/32一致，Graph投机比同后端Graph无草稿控制约快32.2%。新旧后端8/32输出不同，默认保留旧路径，不宣称旧基线兼容。

最新验证Graph优化：显式设置 `verification_cuda_graph=True`，单请求MTP-1的目标验证可重放原逐token算子。完整归档256/256一致、105项相关测试通过；组合路径八副本合计150.50 vs普通eager decode 88.52 tok/s。普通decode/MTP草稿/多请求Graph不在本轮范围，默认仍关闭；性能归因和证据见 [MTP_VERIFICATION_GRAPH.md](MTP_VERIFICATION_GRAPH.md)。

2026-11-07后续：常规MTP-1已按接受边界直接提交暂存S/conv，取消拒绝后的整模型重放；新增每请求独立的多请求cohort接口。C1全归档256/256、C2/C4各32/32通过，97项相关测试通过；性能与限制见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。下面restore/replay与旧吞吐数字保留为此前阶段和显式参考路径的记录。

2026-11-06，单张 A100-SXM4-80GB，本地 Qwen3.5-27B，BF16 权重、FP32 递归状态，TP=1、eager。
本轮实现重点是状态事务和可复现验证，尚未完成可默认使用的批量无损投机加速。

最新数值修复已接入正式 `batched_experimental` 验证及拒绝重放：归档 128 输入×两轮，输出 256/256 与普通 decode 一致，84 项相关回归通过。批量路径内部沿用逐 token 的投影、norm、递归和 attention 算子；当前吞吐 76.69 vs 基线 87.58 output tok/s，没有加速收益。见 [MTP_NUMERICAL_FIX.md](MTP_NUMERICAL_FIX.md)。下面历史验收中的失败数字保留原样。

## 已实现

- `HybridCheckpoint` 只快照当前请求的全部线性层 S 和卷积历史，不复制整个状态池。
- KV 验证窗口必须使用私有页、禁用前缀共享；容量不足时不修改页表。
- K 个草稿对应 K+1 个目标预测；首个不匹配位置输出目标 token，全接受时输出 bonus。
- 批量验证拒绝后恢复 S 与 conv，再重放保留输入；回收多余 KV 页，通过已提交长度隐藏保留页中的无效后缀。
- 验证和重放出现异常时恢复初始 S/conv、页表和 token 元数据，清除全局上下文；可以恢复普通生成。
- 默认草稿来源为 checkpoint MTP-1，显式 `enable_mtp=True` 加载全部 15 组权重。共享主模型 embedding 与 LM head，额外 424,699,392 参数（BF16 约 810 MiB）。不启用时继续跳过 MTP 权重。
- 显式 `draft_method="prompt_lookup"` 保留历史 n-gram 对照，不将其称为 MTP。

关键不变量：每轮提交后 `num_tokens = num_cached_tokens + 1`，最后一个输出仍是待计算 token。
假设草稿 d0…dK-1 在第 j 项被拒绝，本轮输出 d0…d(j-1) 加 correction，共 j+1 项；
实际提交输入是此前待计算 token 加 d0…d(j-1)，也为 j+1 项。
状态恢复需要同时覆盖 full-attention 的逻辑 KV 长度、48 层递归状态和卷积历史。

## 接口与限制

```python
from zjhvllm import LLM, SamplingParams

llm = LLM("/home/data/jhzhou/huggingface/Qwen3.5-27B",
          enable_mtp=True, max_num_seqs=1, max_model_len=1024,
          max_num_batched_tokens=128, enforce_eager=True)
try:
    result = llm.generate_speculative(
        "The quick brown fox jumps over the lazy dog. " * 8,
        SamplingParams(greedy=True, max_tokens=24),
        draft_method="mtp", max_draft_tokens=1,
        verification_mode="serial",  # 默认；正确性参考，无投机加速
    )
finally:
    llm.exit()
```

`speculative_step(seq_id, draft_token_ids)` 可对已完成 prefill 的请求显式提供草稿。
MTP 目前每轮只生成一个草稿，不将多轮单层递推伪装成多个独立 MTP 层。
`generate_speculative()` 默认使用 MTP；prompt lookup 须显式指定 `draft_method="prompt_lookup"`。
本节原实验为一个 Qwen3.5 单卡请求；后续新增多卡与多请求接口，见 [MTP_TP.md](MTP_TP.md)。仍要求 greedy argmax、无 repetition penalty/top-k/top-p 修改。
最多 32 个草稿；草稿窗口必须给 correction/bonus 留出输出预算。
不支持并发调度、TP、随机采样或 P-D。普通 `generate()` 和服务端调度不会自动启用新路径。
每轮统计包含草稿数、接受数、重放 token、快照字节和目标前向次数。
投机一次发出多个 token，其时间戳不能解释成普通逐 token ITL。

## MTP-1 实现与验收

结构参考本地 SGLang 提交 `e2982985110fb432fd8ddba5f0147a5004fd03ab` 的
[qwen3_5_mtp.py](https://github.com/sgl-project/sglang/blob/e2982985110fb432fd8ddba5f0147a5004fd03ab/python/sglang/srt/models/qwen3_5_mtp.py)，独立实现使用 PyTorch SDPA 管理私有草稿 KV。
将归一化后的 token embedding 与主模型最终 norm 后 hidden 按 embedding-first 顺序拼接，经 `fc`、一个 full-attention decoder layer 和独立 final norm，接共享 LM head。

草稿位置 t 的条件为 `(target_hidden[t], token[t+1])`，RoPE 使用 t。
主模型已缓存 C 个输入且保留一个待计算 token 时，只扩展 MTP KV 到 C 个配对。
验证接受后下轮扩展两个配对；拒绝后只扩展一个，因此未提交的 target 后缀不会进入草稿 KV。
新请求清空草稿逻辑长度；草稿前向或目标验证异常时恢复对应的草稿发布边界。
加载缺少任何一个 MTP 参数都会报错，不允许使用随机初始化的 MTP 层。

最终相关回归 **71 passed**：包括增量/full MTP 对照、因果性、显式 GQA attention 对照、Transformers decoder/norm/RoPE 独立组件对照、全部权重加载审计、条件错位检查及故障恢复。
日志见 [qwen35_mtp_regression.log](benchmarks/qwen35_mtp_regression.log)。

单张 A100 80GB、27B BF16、eager、TP=1、chunk=128，每条生成 32 token、ignore_eos，每场景一次，不含 oracle 草稿：

| 输入 | serial 草稿接受 | serial 输出与普通 decode | batched 实验输出 |
|---|---|---|---|
| 自然文本 | 13/17（76.5%） | 一致 | 不一致，第 8 个 token 首次分歧 |
| 代码补全 | 15/15（100%） | 一致 | 一致 |
| 513-token 重复输入 | 15/15（100%） | 一致 | 一致 |

每条输出 32 token，接受率的分母是实际提出的草稿数，不是总输出 token。
3 组的页/状态槽均全部回收；真实 MTP 在 attention 写入草稿 KV 后的故障注入恢复通过，重试后普通生成与基线一致。
原始 token、每轮 MTP KV 长度/接受信息、耗时和源码 SHA256 见 [validation.json](benchmarks/qwen35_mtp/validation.json)。
报告的 `serial_passed=true`、`batched_passed=false`、整体 `passed=false` 如实保留。
serial 没有投机计算节省；批量实验只在通过逐 token 对照的两个样例上观察到较低耗时，单次测量且整体验收未通过，不作为通用加速成果。

```bash
conda activate lumina
python -m pytest tests/test_qwen35_mtp.py tests/test_speculative.py tests/test_gated_delta.py \
  tests/test_scheduler_state.py tests/test_scheduler_policy.py -q
python benchmarks/validate_qwen35_mtp.py --output /tmp/qwen35_mtp_validation.json
# 上述历史版本自然文本批量模式失败；当前修复结果见 MTP_NUMERICAL_FIX.md。
```

## 八卡扩大对照

已完成 [八卡扩大对照](MTP_SCALE.md)：128 个不同输入、两轮、三模式共 768 次生成和 72,834 输出 token。
串行参考 256/256 一致；批量实验 184/256 一致、72/256 分歧（跨自然语言、数学、代码和长上下文），接受率约 89.2%。
三种模式换卡后各自的两轮输出完全复现；所有资源回收通过。批量吞吐 115.74 vs 基线 88.21 output tok/s 属于未通过数值验收的诊断数据，不能宣称有效加速。

## 前一阶段 prompt-lookup/可控草稿验证记录

相关 CPU/GPU 回归 **62 passed**，覆盖所有拒绝位置、EOS/输出预算、私有页容量、255/256/257 页边界、异常回滚、槽位隔离，以及 128 步生产头数（48×128×128）线性状态与 FP32 显式递归对照。日志见 [qwen35_speculative_tests.log](benchmarks/qwen35_speculative_tests.log)。

27B 的三种输入为自然文本、255-token 页边界、513-token 分块 prefill，生成 24 token、ignore_eos，四种草稿策略为测试专用 oracle、首位错误、中间错误和真实 prompt lookup。

| 路径 | 严格逐 token 对照 | 页/状态槽回收 | 结论 |
|---|---|---|---|
| serial 参考 | 12/12 通过 | 12/12 通过 | 沿用普通 decode 内核；不代表加速 |
| batched 实验 | 10/12 通过 | 12/12 通过 | 自然文本两组在第 8 个 token 首次分歧，未验收 |

原始记录：[批量失败](benchmarks/qwen35_speculative/batched_failed.json)、[串行参考](benchmarks/qwen35_speculative/serial_validation.json)。
文件记录源码 SHA256；失败记录对应最初批量实现，之后新增模式选择及串行参考，不覆盖旧文件。
该阶段真实故障注入结果见 [serial_with_faults.json](benchmarks/qwen35_speculative/serial_with_faults.json)。
该阶段的 12 组 token 对照通过；另有 3 组真实故障注入通过：serial 首次前向、batched 首次前向、batched 拒绝后重放。
每组均在实际模型写入缓存后抛出异常，S/conv 精确恢复、逻辑 token/页表不变，随后普通生成与基线逐 token 相同，最终页和槽位全部回收。

这些对照的基线是本引擎普通 greedy decode，不能替代 HF logits 验证。
[ALIGNMENT.md](ALIGNMENT.md) 中原有 HF raw-logits 严格阈值失败仍然有效。
oracle 草稿只用于控制接受与拒绝位置，不能用其耗时宣称实际投机加速。

```bash
conda activate lumina
python -m pytest tests/test_speculative.py tests/test_scheduler_state.py \
  tests/test_scheduler_policy.py tests/test_gated_delta.py -q
python benchmarks/validate_qwen35_speculative.py \
  --output benchmarks/qwen35_speculative/serial_with_faults.json
# 以下是已知存在严格 token 分歧的实验路径，脚本会记录失败并返回非零：
python benchmarks/validate_qwen35_speculative.py \
  --verification-mode batched_experimental --output /tmp/batched_validation.json
```

## 后续优先级

1. 对固定前缀逐层比较批量验证与 serial decode 的 hidden/logits、S、conv，定位首次放大差异；保持现有精度门槛。
2. 批量路径通过严格逐 token 对照后，再考虑保存中间递归状态代替恢复重放，并测量快照与拒绝成本。
3. 在已有真实 MTP-1 的基础上扩大自然文本/代码测试集与重复次数，通过严格输出对照后再报告稳定端到端收益；然后考虑多步草稿。
