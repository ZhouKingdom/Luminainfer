# Lumina 交接记录（已核对 Claude 原始对话）

更新日期：2026-11-06。本文区分用户已确认的目标、Claude 历史结果和 Codex 实测。

**新接手请先读 [QWEN35_HANDOFF.md](QWEN35_HANDOFF.md)。** 该文档按当前代码整理完整的 Qwen3.5/MTP 接手步骤、失败样本和复现命令；本文件以下保留历史，旧阶段的功能状态与优先级不要当成最新结论。

## 最新工作范围（2026-11-06）

用户暂停第二项目，要求聚焦 Lumina 的 Qwen3.5，完善投机解码与线性注意力。
P-D 暂缓，不扩展 TP。新增状态事务、私有 KV 验证窗口、prompt-lookup 接口和串行参考/批量实验两种模式。
用户随后明确要求使用 MTP，现已加载 checkpoint 的全部 15 组 MTP 权重，接入 MTP-1、共享 embedding/LM head 与独立草稿 KV。`enable_mtp=True, max_num_seqs=1` 后 `generate_speculative()` 默认使用真实 MTP。
最终相关回归 71 项通过；27B 3 组 MTP 串行参考全部一致，批量实验 1/3 失败（自然文本第 8 个 token），真实 MTP KV 故障恢复通过。不能宣称通用无损投机加速。
前阶段 prompt-lookup 的 12 组串行对照通过、批量 2/12 失败的记录也继续保留。
随后按用户要求完成八卡 768 次生成（128 条不同输入×两轮×三模式），72,834 输出 token。
串行参考 256/256 一致，批量 184/256 一致、72 条分歧；换卡与顺序反转后逐 token 复现，所有页/槽回收。普通 decode 88.21、串行 87.85、批量实验 115.74 output tok/s；批量数字未通过数值验收。
八卡已释放。每卡仅一个活跃请求，总并发8，不是MTP高并发C128或TP8。详细数据见 [MTP_SCALE.md](MTP_SCALE.md)。
实现、原始证据与下一步见 [SPECULATIVE_DECODING.md](SPECULATIVE_DECODING.md)。
以下 Claude 历史与先前阶段结果继续保留，不能用旧“未选择投机解码”描述覆盖最新用户要求。

## 当前主线与用户偏好

- 用户明确要求 Lumina 支持 **Qwen3.5-27B**，先单卡文本推理跑通，再做性能。
- 跑通引擎后，用户最后明确选择 **“直接开始 Triton kernel 优化”**，重点是 Gated DeltaNet prefill 的 chunk 间扫描。
- Lumina 是推理引擎项目；Furnace 最后被保留为独立底层 CUDA 算子库。此前存在合并讨论，不应把旧建议当作最后决定。
- 用户希望用 **nsys 分析整个框架**；无管理员权限、无 ncu 硬件计数器权限。不要以安装驱动、获取 root 或 ncu 作为优化前提。
- 用户主要阅读 **TUTORIAL.md 和 RESUME_PREP.md**；结果稳定后应同步这两个文档，性能数字必须附带模型、GPU、batch、长度和对照条件。
- 共享服务器：运行前查看 GPU 占用，不影响其他用户进程。历史“GPU 空闲了”只是当时状态。

## 原始历史依据

主要会话：`/home/jhzhou/.claude/projects/-home-jhzhou-sft-prj/e6da0cab-563a-49d4-af9d-36b3f1f8d87b.jsonl`。
另一个较新的 `3f6b0e9e-f770-4442-a25d-9cf1497dd8b4.jsonl` 大量重复相同消息，应视为相关副本/分支，不能算作第二次独立验证。

| 主要会话行号 | 历史事实 |
|---|---|
| 2779 | Claude 报告完整模型 prefill logits 最大偏差约 0.156，argmax 为 Paris；属于当时的短输入结果 |
| 2839、2848 | 补齐 causal conv 历史状态后，手动 decode 4 token 与 HF 一致 |
| 2874 | 用户选择继续“引擎集成” |
| 3236、3264、3285 | Claude 报告单请求及 3 个不同长度短请求的引擎生成与 HF 一致，每请求 4 token |
| 3288 | 用户明确要求“直接开始 Triton kernel 优化” |
| 3346、3355 | Claude 报告 torch chunk 与逐 token 递归对齐；L=256 算子耗时约 45ms→1.2ms，属于历史局部 benchmark |
| 3360 | Claude 报告一次 profile 中 chunk scan 约占 92%，约 60.95ms；不能直接当作当前版本性能 |
| 3472～3551 | Triton scan 仍有错误，期间排查 head stride、tf32、随机数据发散和 denormal；这些猜测不是最终结论 |
| 3586 | 最后有效结果：`kd load diff: 0.0`，`nv load diff: 3.4119396209716797` |
| 3587 | 额度耗尽，未完成 Triton scan 正确性闭环 |

因此准确交接点是：**单卡引擎已经接入；torch chunk 已有历史验证；Triton chunk scan 正在调试、尚未验收**。任务.md 是之前的记忆摘录，不能代替最后对话状态。

保留的历史脚本：`/tmp/test_qwen35_engine.py`、`/tmp/test_qwen35_batch.py`、`/tmp/gen_qwen35.py`、`/tmp/debug_scan.py`。它们是历史参考，不保证能在当前版本原样运行；正式回归以项目内新测试为准。

## Claude 已实现的基础适配

- 模型注册 `qwen3_5_text`，多模态 config 抽取 text_config。
- 文本 checkpoint 名映射，跳过视觉和 MTP 权重。
- Hybrid：16 full attention 层使用 paged KV；48 Gated DeltaNet 层维护独立的 fp32 S 与 bf16 conv 历史。
- Scheduler 管理状态 slot，结束及抢占时释放；分块 prefill 保留状态。
- Qwen3.5 特有 norm、query/gate 排列、partial RoPE、标准 Pre-LN 残差。
- **未实现 Qwen3.5 TP、CUDA Graph、MTP 投机解码、视觉输入。** 之前讨论过投机解码，不代表用户当前选择实施它。

## Codex 本次已完成及证据

1. 修复 hybrid 模型错误复用 KV 前缀的问题：没有 S/conv 快照时不允许跳过前缀；普通模型保留前缀缓存。
2. KV 容量检查成功后才分配状态 slot，避免失败请求占用槽位。
3. **修复 Claude 未完成的 scan 输入布局问题**：三角求解等操作可能输出非连续张量，而 Triton 按连续 head-major 布局读取；在 wrapper 显式整理布局。与最后 nv 读取错误的线索吻合。
4. 添加 Triton decode 原地状态更新，支持跨层缓存的 slot stride，避免完整 S gather/scatter 临时张量。
5. 修复 gated RMSNorm 与 partial RoPE 的 bf16 舍入语义，两项函数级测试与 HF 精确一致。
6. 当前 `test_gated_delta.py` + `test_scheduler_state.py` **15 项通过**，包括非整 chunk、非零初始状态、乱序槽位、多步更新、完整层分块续算和状态槽回收。

性能记录：精度修复前，状态更新 microbenchmark 在 batch=1/4/16 下分别约 6.62×/5.19×/4.80×；单请求 24 token 整模型中位耗时 2.2550s→2.0786s（约 -7.8%）。**这些数字对应更早源码，不是当前精度修复后的最终性能验收；也不能替代尚缺的 prefill scan 专项 benchmark。**

## 当前整模型验证边界

完整报告及原始数据索引见 [ALIGNMENT.md](ALIGNMENT.md)。

- 当前源码对 HF SDPA、FlashAttention 2 两种参考，各覆盖 8 条请求 × 8 步，**64/64 next-token argmax 一致**。
- 覆盖短请求、不等长 batch、65/257/513-token 输入、128-token 预算分块、重复前缀、不同后缀及状态槽复用。
- 严格 raw logits 阈值仍未通过，JSON 与验证程序保留失败状态；不能写成“完整精度验收通过”。
- HF 自身 batch=1 对 batch=2 在相同长重复文本上最大 raw logits 偏差可达 8.42，24/24 argmax 一致。存在明显 bf16 数值敏感性，但这不证明 Lumina 全部剩余误差都来自舍入。
- 未验证超长上下文、大并发和真实引擎 GPU 抢占恢复；未跑全仓库测试。

## 接下来的优先顺序

1. **本轮已完成 prefill Triton 主线的专项基准与一次优化**：逐 token/torch chunk/Triton 三路径、真实 48 heads 与 128×128 状态、多长度、非零初始状态及分块续算均已测；默认采用 IEEE 8-warps。最新结果见文末及 PREFILL_OPTIMIZATION.md。
2. **已完成当前 Qwen3.5 prefill 的 nsys/NVTX 复测**：扫描占整请求 kernel 时间从约 58% 降到 11%，BF16 GEMM 约 47%；下一步优先分析剩余热点，历史 92% 已过时。
3. 扩充非重复自然文本正确性案例，建立 HF 本身的数值基线；保持已有压力测试和失败报告，避免仅凭 greedy 相同声称逐元素对齐。
4. 单变量优化并记录正确性与性能；之后重测整模型 TTFT、TPOT/ITL、吞吐和显存。
5. 当前结果稳定后同步 TUTORIAL.md、RESUME_PREP.md。这两个主要文档目前还没有 Qwen3.5 章节，不能遗漏。
6. CUDA Graph、TP、MTP 是后续方向，尚未完成；不应在 prefill 优化闭环前无依据切换主线。

## 环境与复现

- 仓库目录：`/home/jhzhou/sft_prj/Lumina`；当前没有 .git。
- conda 环境：`lumina`；Python：`/home/data/jhzhou/conda_envs/lumina/bin/python`。
- PyTorch 2.8.0+cu128，flash-attn 2.8.3.post1；不要使用其他 conda 环境代替。
- 权重：`/home/data/jhzhou/huggingface/Qwen3.5-27B`。
- 8 张 A100-SXM4-80GB。Codex 沙箱内可能看不到 GPU，获准在沙箱外运行即可；已证实服务器驱动正常，不需要重装。
- 现有 `benchmarks/bench_nsys.py` 默认是 Qwen3-0.6B，不能直接冒充 Qwen3.5 profile。

在 Lumina 目录运行：

```bash
conda activate lumina
python -m pytest tests/test_gated_delta.py tests/test_scheduler_state.py -q
python -m benchmarks.bench_delta_decode
python -m benchmarks.bench_qwen35_decode
# 以下完整 HF 对齐默认分别在 GPU0/GPU1 加载模型，需两张足够空闲的 80GB 卡；raw 阈值未过会非零退出。
python -m benchmarks.validate_qwen35
python -m benchmarks.validate_qwen35 --hf-attention flash_attention_2 --output benchmarks/qwen35_alignment_flash2.json
python -m benchmarks.check_qwen35_hf_batch
```

## prefill 主线已推进（2026-11-01）

完成逐 token / torch chunk / Triton prefill 三路径专项验证、6 组 geometry 调优和 nsys CUDA/NVTX profile。
采用保持 IEEE FP32 的 4→8 warps 优化，真实 27B 单请求 1024-token 首 token 中位耗时 0.917s→0.437s，完整 logits 精确一致。
拒绝了整模型 token 翻转的 tf32x3 默认方案；它只保留为显式实验选项。
结果已同步 TUTORIAL.md 与 RESUME_PREP.md，详见 [PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md)。下一步根据新 trace 优化剩余瓶颈，并补多长度/并发的整模型性能验证。

最终回归：18 passed。整模型 nsys 分路径聚合见 benchmarks/qwen35_prefill_nsys_summary.json。

## 八卡容量与尾延迟基准（用户选择：不扩展模型并行）

已完成 8 个 Qwen3.5-27B 独立单卡副本的 1/2/4/8 GPU 容量扩展、总并发 64/128 和 Poisson 到达测试。主实验 3968 请求、253952 个生成 token；各八副本场景 1024 请求。
总并发 128 实测 1157.5 output tok/s、TTFT/TPOT p99=2.17s/102.8ms；固定每卡并发 8 的 1→8 容量扩展为 7.85×。
100ms TPOT/2s TTFT 门槛在总并发 128 时达标率 93.75%、Poisson 8 req/s 下 93.46%；这些负结果不能隐藏。
简历 sx/infra简历.tex、TUTORIAL.md、RESUME_PREP.md 已同步。原始数据、快照和报告在 benchmarks/service_8gpu/。
仅增加 configurable distributed_port 以隔离独立 engine 的 rendezvous，不实现新 TP/EP；所有 benchmark worker 完成后已退出，GPU 显存已释放。
后续若继续优化，可针对 prefill 对 decode 的阻塞研究调度/SLO goodput；不要把容量扩展结果说成模型并行加速或 HTTP 服务 SLA。


## 调度路径优化：CPU 元数据缓存（2026-11-01）

默认复用 CPU 侧序列边界/状态槽，消除 48 层 Gated DeltaNet 对 GPU 标量的重复读取；原 alternating 调度与模型算术不变。4 副本、每卡并发 16、同一 1024 请求闭环复测，吞吐 573.7→602.1 output tok/s，ITL p99 879→688ms，预设 2s TTFT/100ms TPOT 门槛的 SLO goodput 7.284→9.408 req/s。nsys 单个 8 请求 prefill 的流同步 1154→2 次；27B 完整 logits 最大差异 0，1024/1024 输出 hash 一致。

这是单次固定长度合成负载，门槛附近的小变化会放大 goodput 的增益，不应宣称生产 SLA。bounded 预算策略虽降低 ITL，但闭环 goodput 明显下降，仅保留显式选项；混合执行因数值验收失败已撤回并归档。用户明确不需要 TP=8，勿扩展模型并行。复现和完整限制见 [SCHEDULING_OPTIMIZATION.md](SCHEDULING_OPTIMIZATION.md) 与 [实验报告](benchmarks/SCHEDULING_REPORT.md)。


最终回归：调度专项 25 项通过；扩展包含 Qwen3 logits/生成共 36 passed、1 failed。失败为 `test_batch_equals_individual`，关闭 CPU 元数据缓存后同样复现且输出完全相同，说明旧路径已有该问题；根因尚未诊断。未修改测试断言，不能宣称完整测试全绿。记录见 `benchmarks/scheduling_verification.json`。


## 混合负载基线与实验性自适应调度（2026-11-01）

旧Qwen3-0.6B批次一致性失败已定位：prefill相同，首次decode首层QKV GEMM输入相同、输出差0.001953125；第8个生成位置因单条路径候选同分而分叉。原严格断言保留，新增固定batch形状的请求重排隔离测试通过。不是把所有Qwen3.5误差都归因于近邻tie。

完成8×A100、两组四副本、交换GPU的两轮混合输入/输出长度与Poisson/突发对照，共3072请求、219264生成token。自适应策略根据执行耗时拟合与decode余量选择预算，并以TTFT保护推进队首请求；保持默认alternating。饱和闭环goodput约+39.7%，但吞吐−4.7%、SLO达标率仅16.6%；突发goodput−3.7%、TTFT p99约0.85s→1.81s，Poisson基本持平。

重要：跨策略1536对输出中400对不同；抽样16处HF共享历史审计有7处candidate相对baseline regret高出1以上，数值验收未通过，不能把性能数据写成已验收成果。adaptive是显式实验选项，不默认启用；不要放宽阈值或把所有分歧解释成BF16近邻tie。下一步应先根据HF自身参考路径对照定位长序列/缓存数值差异，再决定是否继续策略优化。详情见 [ADAPTIVE_SCHEDULING.md](ADAPTIVE_SCHEDULING.md) 与 [交叉实验报告](benchmarks/adaptive_holdout/REPORT.md)。

最终回归44 passed、1 failed；保留的失败为上述严格跨batch测试，日志/JUnit及源码快照校验均归档。没有扩展TP/EP，没有默认mixed执行，也没有用这些未验收数据改简历。


补充HF自身参考路径对照：上述16处真实共享历史中，HF的batch1完整、batch2完整与batch1缓存增量前向有11处top1不一致，最大logits差异分别达17.25/19.73；但仍有3处candidate在所有参考下相对baseline regret高出1以上。参考敏感性不能豁免剩余误差，adaptive仍未通过数值验收。证据见benchmarks/adaptive_holdout/hf_self_reference_audit.json。


## 2026-11-02：主线改为P-D分离

用户决定暂停SGLang，聚焦Lumina的P-D分离；三个模型为benchmark载体。已添加Dense KV交接原型、私有页导入与失败回滚、P侧ACK/abort保留和释放、D内存回执重试，以及测试/双卡验证脚本。CPU 28 passed、1 skipped。GPU首次验证被中断，无result.json；当前八张卡被其他Ray/vLLM作业占用，未结束其他作业，双卡正确性仍待验证，不能声称P-D跑通或加速。详见PD_SEPARATION.md；下一步先运行validate_pd_handoff，确认完整logits与token一致后再做GPU数据面。不要先改简历为已完成P-D，也不扩TP=8。
