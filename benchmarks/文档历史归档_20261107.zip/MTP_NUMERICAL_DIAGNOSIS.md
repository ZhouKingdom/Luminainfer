# MTP 批量验证数值诊断（2026-11-06）

本文保留修复前的诊断证据。后续已将一致计算路径接入正式验证与拒绝重放，见 [MTP_NUMERICAL_FIX.md](MTP_NUMERICAL_FIX.md)。

诊断阶段完成了交接 P0 的单请求定位和可重复算子替换工具；**在该阶段结束时，生产 `batched_experimental` 仍有输出失配，不能宣称已修复或已获得无损加速。** 默认仍使用 serial。

## 相同输入与状态下的定位

使用归档 `benchmarks/qwen35_mtp_8gpu_20261106/workload.json` 的 request 2，单卡 A100、lumina 环境、真实 checkpoint MTP、greedy、相同引擎参数。输入没有重建或修改。

普通 decode 与 MTP serial 一致。原批量路径仍在生成索引 3 首次分歧：普通为 token 14995，批量为 1881。两边前三个 token 均为 `[760, 5839, 6463]`。

诊断生成始终提交 serial 的结果。每个窗口在相同 S/conv 快照、已提交 KV 前缀、pending token 和草稿下，分别执行强制 token 历史的逐 token decode 和批量前向；即使草稿被拒绝，也计算固定窗口的其余行用于数值比较。比较完成后恢复 S/conv、target hidden 和 context，再执行真正的 serial 提交。不能将这些带 hook、CPU 拷贝和多次前向的耗时当性能数据。

前三个窗口分别从 cached position 36、38、39 开始，草稿为 5839、1881、303。

- embedding 和第 0 层 input RMSNorm 输出完全一致。
- 最早差异均为 `layers.0.linear_attn.in_proj_qkv`；max_abs=0.25，三个窗口分别有 5451、5861、5748 / 20480 个 BF16 元素不同。
- 相同历史的最终 logits max_abs 分别为 0.125、0.125、0.140625。
- 第二个窗口，serial 的 token 14995 logit=30.25、1881=30.125；batch 两者均为 30.125，argmax 取较小 token ID 1881。`topk` 对相同值的排序不保证等于 argmax，诊断分别记录两者。
- 所有窗口的已提交 KV 前缀保持逐元素相同；新窗口的 KV 和 S/conv 则随计算路径出现差异。

证据：[request2.json](benchmarks/qwen35_mtp_diagnosis_20261106/request2.json)。它是本轮最早的未替换路径记录，完整保存输入历史、草稿、槽位、页表、各模块输出误差、最终 S/conv、有效 KV 与 top5。

## 算子替换对照

替换仅在诊断程序中临时生效，异常时恢复各模块的原 `forward`；没有修改引擎默认路径。

| 替换组合 | request 2 的 16-token 输出与普通 decode 一致 |
|---|---|
| 所有线性投影逐 token 形状 | 否 |
| 投影 + 逐 token linear-attention decode | 否 |
| 投影 + 逐 token paged full-attention decode | 否 |
| 投影 + linear decode + paged full decode | 否 |
| 上述三者 + RMSNorm 逐 token 形状 | 是（另跑归档完整 64-token 预算） |

前三类算子均替换后，最早剩余差异分别移到第 6 层 input norm、第 25 层 input norm、第 13 层 post-attention norm。每个位置仅有一个 BF16 元素不同，max_abs 分别为 0.00048828125、0.000244140625、0.0009765625；在这些位置之前的 decoder 输出完全一致。

再将 Qwen3.5 RMSNorm 也按逐 token 形状计算后，前三个固定窗口的所有已观察模块、完整 logits、48 层最终 S/conv 和新窗口 KV 均逐元素相同。证据：[request2_ablations.json](benchmarks/qwen35_mtp_diagnosis_20261106/request2_ablations.json)、[request2_all_norm.json](benchmarks/qwen35_mtp_diagnosis_20261106/request2_all_norm.json)。

这证明该输入的分歧至少涉及投影和 norm 的形状敏感数值路径；不能把它全归因于 DeltaNet 递归公式，也不能据此证明其他输入不存在状态或接受/拒绝问题。三类替换的组合失败不证明其中每一类都不可省略，尚未完成全部组合的最小必要集合排查。

## 四类已知失败样本的后续验证

单个已加载引擎依次运行模式，遵守归档完整输出预算和 EOS；不是随机独立测试集。原路径的首次分歧与八卡归档完全相同。

| request | 输出预算/实际输出数 | 原批量首次分歧索引 | 四类替换后与基线一致 |
|---|---:|---:|---|
| 2（natural） | 64 / 64 | 3 | 是 |
| 39（math） | 128 / 128 | 86 | 是 |
| 76（code） | 64 / 64 | 11 | 是 |
| 127（long_context） | 128 / 128 | 70 | 是 |

完整证据：[four_cases.json](benchmarks/qwen35_mtp_diagnosis_20261106/four_cases.json)，对应的 33 个 Python 源文件快照位于 [four_cases.source/](benchmarks/qwen35_mtp_diagnosis_20261106/four_cases.source/)。`measurement_complete=true`、`trace_preserved_serial=true`、`resources_reclaimed=true`，原批量路径的 `batched_numerical_validation_passed=false`。request 2 的三个固定窗口中，所有已观察模块、完整 logits、S/conv 和有效窗口 KV 逐元素相同。

结束后检查八张 GPU 均仅占 4 MiB、无计算进程；本轮没有遗留 GPU 任务。没有测试吞吐，不从该记录推断加速或全量通过。

## 复现与验证

```bash
cd /home/jhzhou/sft_prj/Lumina
# 先确认 GPU 0 空闲；同一张卡不要并行加载两个 27B 实例。
CUDA_VISIBLE_DEVICES=0 /home/data/jhzhou/conda_envs/lumina/bin/python \
  -m benchmarks.diagnose_mtp_verification \
  --interventions projection recurrence attention norm --tokens 128 \
  --check-ids 39 76 127 --output benchmarks/qwen35_mtp_diagnosis_NEW/four_cases.json
```

输出路径必须不存在。工具保存源码 SHA256、源码快照、归档 workload SHA256、每个窗口的精确 token/slots/pages 和输出；不会覆盖历史报告。`measurement_complete` 表示诊断完成，`batched_numerical_validation_passed` 单独表示生产批量路径是否通过。替换组合只属于诊断结果。本文的原始记录与源码快照对应修复前；当前工具默认比较已修复的生产验证路径，`batch_path` 会记录这一点，重建历史实验应使用其归档源码。

本轮回归：交接指定的 MTP、speculative、GatedDeltaNet、状态调度和策略测试 **71 passed**，实际运行 CUDA；新增诊断回滚/异常/作用域/argmax tie 测试及原报告保护 **5 passed**。这是相关测试集结果，不是全仓全绿。

```bash
/home/data/jhzhou/conda_envs/lumina/bin/python -m pytest \
  tests/test_mtp_diagnostic.py tests/test_mtp_replica_report.py -q
CUDA_VISIBLE_DEVICES=1 /home/data/jhzhou/conda_envs/lumina/bin/python -m pytest \
  tests/test_qwen35_mtp.py tests/test_speculative.py tests/test_gated_delta.py \
  tests/test_scheduler_state.py tests/test_scheduler_policy.py -q
```

两次早期替换实验误同时加载 GPU 0，初始化分别报 CUBLAS allocation 和 OOM；均已退出，没有产生可用于数值验收的结果。后续记录全部使用一个引擎依次执行模式，独立 GPU 1 仅运行小型回归。

## 下一步

将该工具作为算子优化的固定数值对照，先找最小必要替换组合，再设计与 decode 数值路径一致且真正批量的 projection/norm/attention/recurrent 实现。逐 token 重复调用能建立数值参考，却不减少相应矩阵计算或 kernel 调用；本轮没有测性能，也没有将这种替换加入公共 API。

任何候选生产修复都仍须保留普通 decode 对照，通过多类别、完整 128 输入两轮验证，再测性能。历史 184/256 和 HF 严格 logits 失败记录继续有效。
