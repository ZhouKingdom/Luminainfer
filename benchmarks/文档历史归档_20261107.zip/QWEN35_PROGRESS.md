# Qwen3.5 项目进度总结

更新日期：2026-11-07。范围仅限 Lumina 的 **Qwen3.5-27B 文本推理、Gated DeltaNet、张量并行和 MTP**。本文汇总当前状态，历史原始报告继续保留，不能把旧报告中的功能限制当作当前限制。

## 1. 当前结论

已经完成单卡文本推理到真正 TP1/2/4/8 的扩展；普通推理和真实 checkpoint MTP-1 均能多卡运行。普通 decode 支持原生 CUDA Graph，MTP 目标验证也已支持多卡、多请求 Graph，以及调度器驱动的连续补位。

当前相关 CUDA 回归为 **162 passed、0 skipped**。最新真实模型测试中，**96/96 次连续 MTP 生成与相同 TP、默认数值后端的普通解码逐 token 一致**。这属于已测输入与配置上的行为验收，不等于 HF 严格 logits、任意调度形状或完整模型质量验收。

性能上，普通推理已经测到 TP8、C128 满载解码窗口约 **3208 output token/s**；包含 prefill、排队的端到端约 **959 output token/s**。最新 MTP Graph 的性能测试是另一组 C4 小负载，不能与 C128 的数字混比。

## 2. 功能完成情况

| 部分 | 当前状态 | 验收范围与限制 |
|---|---|---|
| 模型适配 | 完成 Qwen3.5-27B 文本权重加载、norm、partial RoPE、attention gate | 不包含视觉输入；其他 Qwen3.5 规格未独立验收 |
| 混合注意力 | 48 层 Gated DeltaNet、16 层 full attention | BF16 权重/激活，FP32 递归状态 |
| Prefill | 分块 prefill、长输入 chunk 算法与 Triton scan | 仍有逐序列处理及主机调度开销 |
| Decode | Triton 原地更新递归状态、paged KV | S/conv 按请求分槽，结束释放，抢占后重算 |
| 普通张量并行 | 真正 TP=1/2/4/8，EP=1 | 一个模型跨卡切分，不是多个独立副本 |
| 普通 decode Graph | 已实现混合状态与 NCCL 捕获/重放 | 按实际 batch 捕获，未捕获大小回退 eager；该路径非 FP8 KV |
| 真实 MTP-1 | 加载全部 15 组 checkpoint 参数 | 共享目标 embedding/head，私有草稿 KV；不是 prompt lookup 替代品 |
| 独立接受与提交 | 每个请求独立判断接受长度 | 不对所有请求取 min；按各自边界提交 S/conv、hidden 和 KV 元数据 |
| 多卡 MTP | TP=1/2/4/8 已接入 | 目标与草稿 decoder 都做 TP，rank 0 广播预测决策 |
| MTP 验证 Graph | 多卡、多请求、混合 1/2 行窗口 | 显式 `verification_cuda_graph=True`；最多缓存16种布局，超出回退 eager |
| MTP 连续补位 | 已实现，批量接口默认启用 | 完成请求释放槽后，等待请求可在后续 prefill 轮接入 |
| 在线投机步进 | `add_request()` + `step_speculative()` | 可在两次 step 之间加入请求；返回完成结果和 token 流 |
| 故障与容量处理 | 页/工作区不足时普通 decode 回退；可恢复错误跨 rank 回滚 | NCCL 故障或进程退出仍属于引擎级失败 |

MTP 当前要求 **greedy、MTP-1、显式 `max_num_seqs=1–8`**。真实模型已测 C1/C2/C4，最新连续补位测试为8条请求、最大并发4；不宣称 C8 或更大 MTP 并发已经验收。

## 3. 主要实现与已解决问题

### 3.1 混合状态与多卡切分

- GDN 按 key/value 头切分，Q/K/V 和卷积参数分别切分后组成局部布局；S/conv 只保存局部头。
- Full attention 按完整 query/gate 头切分，MLP 使用列/行并行，行投影后 all-reduce。
- 27B 有4个 KV 头，TP8 时每两个 rank 复制同一个全局 KV 头；MTP 私有 KV 同样按局部头数分配。
- Embedding、LM head、MTP fc 和必要 norm 暂时复制，尚不是所有参数都切分的最省显存实现。
- 各 rank 共同确定状态槽及 KV 页容量；混合模型禁用仅 KV 的前缀复用，因为它不能恢复 S/conv。

修复过 TP2 大状态池的32位地址溢出：slot 乘 stride 前改为64位，并加入超过 `2^31` 元素地址跨度的测试。失败试跑未作为有效吞吐证据。

### 3.2 投机验证的数值路径

早期验证窗口改变 GEMM、norm、递归和 attention 的执行形状，导致 greedy 输出偏离普通 decode。默认 `decode_equivalent` 路径已统一这些算子的逐 token 算术。

多卡接入后进一步发现：**仅固定 GEMM 形状还不够，BF16 NCCL 归约也受张量大小影响**。隔离实验中，相同局部分量的 `[2,5120]` 整体归约与两次 `[1,5120]` 归约，有3299/10240个元素不同，最大差0.0625。验证路径现同时固定单 token 的行并行归约形状。

### 3.3 接受、提交与回滚

验证先保存各输入步对应的中间 S/conv，再按每个请求的接受边界提交，常规 MTP-1 拒绝后无需整模型重放。未提交的 KV/hidden 后缀由逻辑边界隐藏，拒绝页由调度器回收。

多卡命令传递完整请求历史、状态槽、页表和采样约束；同步 EOS 配置和预测决策。准备、提交阶段的可恢复错误会触发全 rank 回滚；测试覆盖单 rank 的工作区、草稿、提交与 Graph 缓冲分配故障。

### 3.4 Graph 与连续补位

验证 Graph 按实际窗口布局缓存，例如 `(2,2,2)`、`(2,1)`、`(1,)`。每次重放更新 token、position、状态槽、物理页和有效长度，不通过复制请求槽来填充 batch。接受决策与状态提交仍在 Graph 外，草稿层也仍为 eager。

`step_speculative()` 接入普通调度器，分块 prefill 与投机轮交替。已修复部分 prefill 持页导致唯一 decoder 跨页时的低容量死锁；还补齐异常引用环回收与 NCCL 销毁前同步，分布式测试在全部子进程退出后才标记完成。

## 4. 最新性能结果与口径

### 4.1 普通推理容量测试

环境为单机8×A100-SXM4-80GB，BF16，固定128输入/128输出，greedy、ignore EOS，原生引擎接口。加载、JIT、Graph 捕获不计入测量，有限值检查计入。

| TP | C1 解码窗口 tok/s | C128 满载解码窗口 tok/s | C128 端到端 output tok/s |
|---:|---:|---:|---:|
| 1 | 22.95 | 未达到128活跃请求 | 437.76 |
| 2 | 31.54 | 1778.73 | 784.18 |
| 4 | 38.82 | 2650.69 | 907.26 |
| 8 | 40.98 | 3207.78 | 959.32 |

TP1 该配置只有49个状态槽，128入队请求会排队。**解码窗口仅统计所有请求完成 prefill 且均未结束的步骤；端到端包含 prefill 和排队。** 单请求几十 token/s 与高并发总吞吐几千 token/s 是不同指标。

该阶段共1288次生成、164864个输出 token；各 TP 的 Graph/eager 配对各161/161一致。不同 TP 数的 BF16 归约、不同 batch/调度可能改变输出，不能承诺跨配置逐位相同。

证据：[普通 TP 报告](benchmarks/qwen35_tp_20261107/REPORT.md)、[实现说明](QWEN35_TP.md)。其中旧“MTP仅TP1”的表述属于该报告冻结时的阶段状态。

### 4.2 连续 MTP 与验证 Graph

这是独立的 **C4 小负载**：8条输入长36/25/106/128/64/96/255/256，输出预算8/48/16/32/12/24/9/17，每阶段166个输出 token。E2E 包含 prefill、调度、草稿、验证和全 rank 有限值检查。

| TP | 普通 eager E2E | 连续 MTP eager E2E | MTP Graph 冷启动 E2E | 连续 MTP Graph 预热后 E2E |
|---:|---:|---:|---:|---:|
| 2 | 10.05 | 9.46 | 10.13 | 23.05 |
| 4 | 10.11 | 8.63 | 13.01 | 26.68 |
| 8 | 8.89 | 8.18 | 9.50 | 26.26 |

单位均为 output tok/s；预热后数字合并两轮耗时计算，捕获成本单列在冷启动阶段。该结果证明本负载下 Graph+连续 MTP 组合路径相对 eager 的收益，**不证明投机算法本身的独立收益，也不代表 C128 MTP 容量**。

共160次正式生成、3320个输出 token；其中96次连续 MTP 全部与对应普通输出逐 token 一致。轨迹确认第5条请求在最初4条全部结束前已开始生成。固定 cohort 对照使用匹配的普通控制；跨调度差异原样保留。

测量为共享主机上的非隔离实验，早期小模型测试曾在退出时保留空闲 CUDA 上下文，后已修复并清理；不据此给出严格强扩展效率或服务 SLA。

证据：[最新验收报告](benchmarks/qwen35_mtp_continuous_graph_20261107/REPORT.md)、[Graph/连续补位说明](MTP_CONTINUOUS_GRAPH.md)。

## 5. 数值与质量验收边界

| 验收项 | 当前结论 |
|---|---|
| Lumina 内部：已测普通 decode 与投机输出 | 同 TP、对应数值后端和测试配置下严格比较通过 |
| Graph 与 eager、中间状态和有效 KV | 已有精确对照，覆盖动态槽、页边界和故障恢复 |
| 跨 TP、跨任意 prefill 打包/调度形状 | 不保证逐位相同；已保留实际差异 |
| HF 基础行为检查 | 历史单卡测试中，两种 HF attention 后端各64/64 next-token argmax 一致 |
| HF 严格 raw logits | **尚未通过**，最新多卡/MTP工作没有补做完整 HF 严格验收 |
| 更广泛任务准确率、超长上下文和线上质量 | 尚未完成系统验收 |

可选 `qwen35_linear_backend="batch_invariant"` 已参考本地 SGLang 固定归约路径实现。单卡16输入×两轮中，与自身普通 decode 32/32一致；同后端 Graph 无草稿控制下观察到约32.21%的投机提升。但新旧后端8/32条完整输出序列不同，即4个输入各重复两轮，不是25%的 token 计算错误。

其中一个输入已定位到不同 GEMM 归约/舍入打破 logits 平局；其余差异及质量影响不能统一认证为“无害误差”。该后端仍非默认，多卡 MTP、HF 和质量未独立验收。

证据：[HF 对齐记录](ALIGNMENT.md)、[可选后端与数值诊断](SGLANG_MTP_EXECUTION.md)。

历史 prefill 优化另已将 Triton scan 默认 warps 从4改为8，保持 IEEE FP32；特定1024输入→1输出负载从0.917s降到0.437s，完整 logits 不变。这不是当前多卡吞吐结论，详见 [prefill 优化记录](PREFILL_OPTIMIZATION.md)。

## 6. 使用入口与环境

权重：`/home/data/jhzhou/huggingface/Qwen3.5-27B`。

环境：`/home/data/jhzhou/conda_envs/lumina/bin/python`，PyTorch 2.8.0+cu128、Triton 3.4.0、Transformers 5.20.1。最近一轮测试结束时8张卡均已释放、无遗留计算进程；开始新实验仍需重新检查占用。

多卡 MTP 示例，启动前设置足够空闲 GPU，如 `CUDA_VISIBLE_DEVICES=0,1,2,3`：

```python
from zjhvllm import LLM, SamplingParams


def main():
    llm = LLM(
        '/home/data/jhzhou/huggingface/Qwen3.5-27B',
        tensor_parallel_size=4,
        enable_mtp=True,
        max_num_seqs=4,
        max_model_len=4096,
        max_num_batched_tokens=512,
        verification_cuda_graph=True,
        enforce_eager=True,
        distributed_port=2490,
    )
    try:
        results = llm.generate_speculative_batch(
            ['解释线性注意力。', '写一个二分查找函数。'],
            SamplingParams(greedy=True, max_tokens=128),
        )
        print(results)
    finally:
        llm.exit()


if __name__ == '__main__':
    main()
```

`verification_cuda_graph` 独立控制验证 Graph；`enforce_eager` 控制普通 decode Graph。普通 `generate()` 保留非投机行为。普通 C128 容量配置应使用 `enable_mtp=False`，不能套用当前 MTP 的1–8请求限制和性能结果。

## 7. 下一步工作

1. **先定位剩余性能瓶颈。** 分别剖析 prefill、草稿层、Graph 外准备/提交、NCCL 主机开销、采样与调度，避免把组合路径收益全部归因于 MTP。
2. **扩大质量与数值验收。** 增加自然文本和长上下文，保持严格同配置比较；补做多卡、MTP及可选后端的 HF/任务质量验收，不修改旧失败阈值掩盖问题。
3. **扩大 MTP 容量测试。** 先独立验收 C8、长短请求混合及尾延迟，再评估提高当前1–8请求上限；记录实际活跃 batch、冷启动和稳态，不把入队数当并发数。
4. **优化显存与算子。** 评估词表参数分片、减少 checkpoint 复制，以及保持数值契约的批量投影/归约优化。
5. **后续功能。** 随机拒绝采样、多步草稿、取消 API 和 HTTP 服务自动选择 MTP 仍需单独实现、验收；视觉输入不在当前完成范围。

## 8. 核心代码与复现证据

| 文件/目录 | 内容 |
|---|---|
| [qwen3_5.py](zjhvllm/models/qwen3_5.py) | 混合模型、TP投影、norm/RoPE与数值路径 |
| [qwen3_5_mtp.py](zjhvllm/models/qwen3_5_mtp.py) | 真实 MTP decoder、请求私有草稿 KV |
| [gated_delta.py](zjhvllm/layers/gated_delta.py) | Triton scan、decode和中间状态写入 |
| [model_runner.py](zjhvllm/engine/model_runner.py) | 状态/KV分配、分布式执行、验证与回滚 |
| [verification_graph.py](zjhvllm/engine/verification_graph.py) | 多请求目标验证 Graph |
| [llm_engine.py](zjhvllm/engine/llm_engine.py) | 普通/投机步进、连续生成接口 |
| [scheduler.py](zjhvllm/engine/scheduler.py) | 分块prefill、补位、抢占和资源回收 |
| [最新实验目录](benchmarks/qwen35_mtp_continuous_graph_20261107) | 原始输出、轨迹、162项回归、分布式正常退出与SHA256 |
| [详细交接文档](QWEN35_HANDOFF.md) | 更完整的实现与历史定位记录 |

最新计算路径与计时源码快照已核对；计时后仅增强了退出回收/同步并更新说明文字。前向、接受与调度 AST 保持一致，退出增强已另做 TP2/4/8 故障恢复与正常退出验证。实验原始失败和快照不覆盖。
