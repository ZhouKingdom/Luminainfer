# Lumina 主线：P-D 分离与服务尾延迟

日期：2026-11-02。主线已选定，当前处于交接协议原型阶段，不代表已完成高性能P-D服务。

## 核心问题

Prefill 与 decode 共用GPU时，长prompt可能打断正在生成的请求。研究将两阶段部署到不同worker后，状态传输、排队和资源分配的额外开销能否换来更好的ITL与SLO goodput。三个模型作为验证载体，不再各自延伸为独立的功能主线。

| 验证载体 | 作用 | P-D状态 |
|---|---|---|
| Qwen3 Dense | 首先验证KV迁移、交接协议、P/D配比和负载变化；0.6B作低成本正确性测试 | 代码原型已实现；双卡验证待运行 |
| Qwen3 MoE | 测试稀疏激活、专家负载对两阶段执行时间的影响 | 尚未验证；已有TP/EP不是P-D支持证明 |
| Qwen3.5混合模型 | 测试KV之外的递归/卷积状态对迁移成本和一致性的影响 | v1明确拒绝；须先解决已有数值验收问题 |

模型多样性用于解释设计在何时有效、何时失效，不把模型支持数量当成核心成果。

## 第一阶段：交接协议原型（已实现）

接口在 `zjhvllm/engine/handoff.py`、`LLMEngine` 和 `Scheduler.admit_prefilled`：

1. P处理完整prompt，产生首个输出token。快照只包含有效prompt token的KV，不复制最后一页未初始化的填充区。
2. P保留原缓存并暂停执行。当前只允许一个待确认交接，协调器必须ACK或abort；没有后台自动迁移。
3. D校验本机checkpoint路径/config、KV布局、dtype、长度与版本，分配自己的私有页，再把KV恢复到不同的物理页号。
4. 恢复成功后才进入decode队列；恢复失败回滚页分配。prompt恰好结束于页边界时，待生成token的新页由正常decode路径分配，避免重复分配和错页。
5. D返回成功确认，P才释放原缓存；abort则保留P的原请求继续执行。D用内存回执表识别相同transfer_id的重试。

v1支持未分片、原生dtype的KV-only执行；不传输FP8 scale、TP/EP分片、Gated DeltaNet状态。传输为可信本机进程间pickle/CPU中转，**不宣称NVLink直传、零拷贝、RDMA或性能加速**。

这是缓存交接接口与串行测试协调器，不是完整在线服务。故障后重试/进程重启、回执表有界保留、多个在途传输、压力下D侧回迁/重算路由和超时恢复仍未实现；当前签名也不支持跨机路径差异或在线换权重。时间戳仅适用于同机单调时钟。

## 验证情况

CPU回归：28 passed、1 GPU测试skipped，覆盖有效长度打包、物理页重定位、整页边界、导入失败回滚、容量拒绝、不兼容载荷拒绝、采样历史/seed、回执重试、ACK/abort释放。

双卡检查程序 `benchmarks/validate_pd_handoff.py` 已写好：Qwen3-0.6B，64/128/256/257/513输入token、16输出token，另有固定seed的随机采样场景。比较单worker基线与P-D的完整输出token和逐步logits hash；D端不允许在验证中重新prefill，且故意占用目标页以验证重定位。

**双卡验证尚未通过/尚无结果**：首次启动被中断；随后发现八卡已由其他Ray/vLLM作业占用，未终止这些进程。没有把未执行的GPU验证记成通过。CPU中转、逐步hash采集和串行执行不适合用来报告服务吞吐/尾延迟。

```bash
conda activate lumina
cd /home/jhzhou/sft_prj/Lumina
CUDA_VISIBLE_DEVICES='' python -m pytest tests/test_pd_handoff.py tests/test_scheduler_state.py tests/test_scheduler_policy.py tests/test_service_metrics.py -q
# 两张空闲GPU，默认每张至少约12GiB可用；启动前自动检查。
python -m benchmarks.validate_pd_handoff --gpus 0 1
```

## 后续里程碑与验收门槛

1. 双卡原型通过：逐步logits/输出一致、目标页重定位正确，ACK/失败/取消资源可回收。
2. 数据面：检查GPU互联拓扑，实现GPU间传输、传输完成事件与计算解耦，测有效字节数/传输耗时/额外显存。不先预设某种互联一定可用。
3. 控制面：独立P/D队列、请求路由、目标资源预留、背压、超时/取消与在途状态管理，避免D因压力自行退回prefill而破坏隔离。
4. 公平对照：相同总GPU数量、模型精度、输入/输出分布和SLO，比较混合部署与1P:1D、2P:6D、4P:4D等配比。注明模型副本数、KV预算及传输显存；计入传输、排队、失败与提交滞后。
5. 扩展模型矩阵：先Dense，再MoE，最后带完整S/conv载荷的混合模型；分开报告正确性与性能验收，不能把Dense结果外推到全部架构。

基准覆盖短/长prompt、短/长输出、混合长度、Poisson和突发到达。比较TTFT、平均TPOT、ITL分布、吞吐、goodput、P/D利用率及传输占比；P-D不保证所有负载更快。单机实验不宣称跨机RDMA收益。

历史算子优化、八副本扩展和自适应调度实验保留为背景证据；尚未通过验收的策略不进入默认路径。当前简历不写“已实现高性能P-D分离”。
