# MTP 批量验证数值修复（2026-11-06）

后续优化（2026-11-07）已用中间状态直接提交替代常规 MTP-1 拒绝重放，并接入每请求独立的多请求接口，见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。本文保留此前数值修复与性能基线，76.69 tok/s 属于该阶段。

`verification_mode="batched_experimental"` 已接入正式的 decode 一致计算路径，验证和拒绝重放使用同一规则。API 和默认 serial 模式保持兼容。

## 改动

- `Context.decode_equivalent` 仅在验证窗口和重放期间启用，结束或异常时随 context 清空。
- Qwen3.5 的线性投影和 RMSNorm 在窗口内保持与普通单请求 decode 相同的逐 token 形状，包括最终 LM head。权重名称、形状及加载规则不变。
- GatedDeltaNet 按 token 顺序调用现有原地 decode 路径，统一 conv、FP32 S 更新、归一化和 gate 的计算顺序。
- full attention 先写入窗口 KV，再按每行自身的有效前缀调用 decode 内核，避免读到未来草稿。BF16 和既有 FP8 KV 路径均保留；FP8 复用普通 decode 的反量化和 FlashAttention 调用。
- 拒绝或预算截断时，恢复原快照并使用同一 decode 一致规则重放保留输入。

窗口仍只做一次目标模型遍历，但内部投影、norm、递归和 attention 按 token 计算。**减少目标模型调用次数不代表同比减少矩阵计算或 kernel 调用次数，本修复不承诺加速。** 目前不把该模式设为默认。

## 单请求证据

[four_cases.json](benchmarks/qwen35_mtp_fixed_20261106/four_cases.json) 使用正式修复代码，不带诊断临时替换。

| 归档 request | 实际输出 token | 修复后与普通 decode 逐 token 一致 |
|---|---:|---|
| 2，natural | 64 | 是 |
| 39，math | 128 | 是 |
| 76，code | 64 | 是 |
| 127，long_context | 128 | 是 |

request 2 的三个固定窗口中，各已观察模块、完整 logits、48 层最终 S/conv 和有效窗口 KV 均逐元素相同。诊断生成始终提交 serial 结果，避免比较已分叉的输入历史；最终输出和页/槽回收均通过。

修复前记录保留在 [MTP_NUMERICAL_DIAGNOSIS.md](MTP_NUMERICAL_DIAGNOSIS.md) 和 `benchmarks/qwen35_mtp_diagnosis_20261106/`，没有覆盖历史失败。

## 完整归档验收

目录：[qwen35_mtp_fixed_8gpu_20261106/](benchmarks/qwen35_mtp_fixed_8gpu_20261106/)。输入直接读取旧归档，`workload.json` 字节完全相同，没有根据当前源码重建 code/doc 输入。

```bash
/home/data/jhzhou/conda_envs/lumina/bin/python -m benchmarks.bench_mtp_replicas \
  --workload benchmarks/qwen35_mtp_8gpu_20261106/workload.json \
  --gpus 0 1 2 3 4 5 6 7 --repeats 2 \
  --output benchmarks/qwen35_mtp_fixed_8gpu_NEW
python -m benchmarks.report_mtp_replicas benchmarks/qwen35_mtp_fixed_8gpu_NEW
```

128 个不同输入 × 两轮 × baseline/serial/batched 三模式，共 768 次；每卡独立单请求副本，TP=1，第二轮换卡并反转模式顺序。结果以该目录的 `validation.json` 和 `REPORT.md` 为准。

已完成全部 768 次生成，72,834 输出 token。数值验收 `numerical_validation_passed=true`，资源回收 768/768，三模式各自两轮换卡输出均为 128/128 一致；普通 decode 与旧归档也为 256/256 一致。

| 模式 | 对普通 decode 逐 token 一致 | 八卡 output tok/s | E2E p99 |
|---|---:|---:|---:|
| 普通 decode | 256/256（自身配对） | 87.58 | 12.357 s |
| MTP serial | 256/256 | 87.23 | 12.455 s |
| 修复后 batched | 256/256 | 76.69 | 14.955 s |

该负载下修复后批量路径吞吐比普通 decode 低约 12.4%，草稿接受率 88.90%。目标模型调用 14,760 次，基线 24,588 次，但内部逐 token 算子没有同比减少，额外窗口计算和拒绝重放仍有成本。**数值问题已修复，此版本没有端到端加速。** 性能优化须以这份正确性参考为约束，不能恢复原来失配的低耗时路径。

最终实验和回归结束后，八张 GPU 均仅占 4 MiB，无计算进程。

## 回归覆盖

除原有 MTP、speculative、GatedDeltaNet、状态/策略测试与诊断/报告保护外，新增 [test_verification_decode_equivalent.py](tests/test_verification_decode_equivalent.py)：

- 真正混合 linear/full-attention 模型的完整 hidden、logits、S/conv 和有效 KV 逐元素比较。
- 255/256/257 缓存边界、非连续物理页、状态槽 2 与其他槽隔离。
- 2/5/33-token 窗口、未来 token 屏蔽。
- BF16 和 FP8 KV/scales。
- 实际 `ModelRunner.verify_greedy` 的全接受、拒绝重放、输出预算截断，与 serial 比较有效状态和 target hidden。

最终上述相关测试集 **84 passed，0 skipped，6.85 s**，实际使用 CUDA。这不是全仓测试。

这些检查不替代 HF 严格 logits 验收；既有 HF 阈值和失败记录保持原样。这里修复的是相同引擎中批量验证相对普通 decode 的数值一致性。
