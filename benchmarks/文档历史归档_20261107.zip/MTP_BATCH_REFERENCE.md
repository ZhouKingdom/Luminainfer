# 多请求投机验证：SGLang / vLLM 源码参考

2026-11-07又核查并移植了SGLang的批量投影/固定归约执行思路，见 [SGLANG_MTP_EXECUTION.md](SGLANG_MTP_EXECUTION.md)。本文主要讨论此前的接受长度与状态所有权，不能覆盖后续执行后端的实现和验收结论。

后续实现（2026-11-07）：中间状态提交、每请求独立GPU接受判定、draft KV/target hidden、固定cohort的多请求接口已接入，见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。本文保留最初的源码核查与移植设计，下面“尚未实现”的描述属于核查阶段。

核查日期：2026-11-06。本文记录实际读取的版本，不能把旧版本的模型覆盖范围套到当前上游。

- SGLang：本地 `/home/jhzhou/sft_prj/sglang`，提交 `e2982985110fb432fd8ddba5f0147a5004fd03ab`。
- vLLM：本地 `verl` 环境安装版 **0.11.0**，源码根目录 `/home/data/jhzhou/conda_envs/verl/lib/python3.12/site-packages/vllm/`。只借鉴它的通用 speculative/GDN 架构，不据此宣称该版本支持 Qwen3.5。
- 同时核查官方 GitHub 固定版本和 vLLM 最新 rejection sampler 文档。下文的精确行号以本地固定版本为准。

## 结论

两边的相关实现都保存每请求接受长度向量，不以 batch 内最小值统一截断。固定形状缓冲、CUDA Graph padding 和每请求独立有效长度可以同时存在。

Lumina 当前只支持单请求 MTP，因此此前数值分歧和当前吞吐下降不是跨请求取 min 导致的。多请求扩展需要同时解决接受判定、状态版本、draft KV 和调度元数据，不能仅把接受计数改成数组或去掉 `max_num_seqs=1`。

## vLLM 0.11.0：逐请求 kernel、填充输出、逐请求缓存前沿

源码：

- `v1/sample/rejection_sampler.py:135`：输入 `num_draft_tokens[B]`、`cu_num_draft_tokens[B]`，输出预分配为 `[B, max_spec_len+1]`，无效位置填 `PLACEHOLDER_TOKEN_ID`。
- 同文件 `:437`：`rejection_greedy_sample_kernel` 使用 `req_idx = tl.program_id(0)`。每个 program 获取该请求草稿的起止偏移，沿本请求草稿推进；遇到第一次不匹配后停止写入后缀，全部匹配则追加 bonus。没有跨请求最小值归约。
- 同文件 `:109`：`parse_output()` 为每行过滤 placeholder，返回长度不同的 token 列表。
- `v1/core/sched/scheduler.py:884`：调度器按 `req_id` 更新，`num_accepted = len(generated_token_ids)-1`，`num_rejected = num_draft_tokens-num_accepted`，只从该请求 `num_computed_tokens` 中扣去拒绝部分。后续停止条件另行处理。
- `v1/worker/gpu_model_runner.py:705`：hybrid 模型按每行第一个 `-1` 的位置求有效输出数，存入 `num_accepted_tokens_cpu[i]`。此处数量包含 correction/bonus，与只计正确草稿的统计口径不同。
- `model_executor/layers/fla/ops/fused_recurrent.py:102`：每请求读取 `num_accepted_tokens[i_n]-1`，通过 `ssm_state_indices` 选择上轮已接受边界的初始 S；`:139` 起为窗口的各步保存状态。Conv 路径也消费该每请求计数，见 `model_executor/layers/mamba/ops/causal_conv1d.py:723`。

核心是按请求使用不同状态版本，而不是要求所有请求在同一 token 位置继续。

官方固定版：[rejection sampler](https://github.com/vllm-project/vllm/blob/v0.11.0/vllm/v1/sample/rejection_sampler.py)、[scheduler](https://github.com/vllm-project/vllm/blob/v0.11.0/vllm/v1/core/sched/scheduler.py)。最新官方接口参考：[rejection sampler](https://docs.vllm.ai/en/latest/api/vllm/v1/sample/rejection_sampler/)。

## SGLang：accept_lens + accept_index，提交每请求选中的中间状态

本地关键代码：

| 文件与行号 | 行为 |
|---|---|
| `python/sglang/srt/speculative/eagle_utils.py:691` | 得到每请求 `num_correct_drafts` 和 `accept_index`，随后 `:926` 计算 `accept_lens = num_correct_drafts + 1` |
| `python/sglang/srt/speculative/eagle_worker_common.py:728` | 批量采样返回 `predict, accept_lens, accept_index` |
| 同文件 `:768` | 逐元素 `new_seq_lens = batch.seq_lens + accept_lens`；CUDA 路径使用等价融合 kernel |
| `python/sglang/kernels/ops/speculative/eagle.py:120` | 每行读取自己的 `accept_lens[row]`，选择对应最后有效 token，`:154` 写 `new_seq_lens[row] = length + accepted` |
| `python/sglang/srt/speculative/eagle_worker_v2.py:1163` | `num_correct_drafts = accept_lens - 1`，每请求选择自己的 hidden 行，构建下一次 draft extend |
| `python/sglang/srt/speculative/spec_utils.py:1101` | 每请求由 `accept_index[req, accept_lens[req]-1]` 定位真实已接受状态步；线性链简化为步号 `accept_lens-1` |
| 同文件 `:1164` | `commit_mamba_states_after_verify()` 按请求提交 conv/SSM 状态 |
| `python/sglang/srt/layers/attention/linear/gdn_backend.py:1237` | TARGET_VERIFY 使用 `intermediate_ssm` 与 `intermediate_conv_window`，并绑定请求对应的中间状态索引 |
| `python/sglang/kernels/ops/mamba/mamba_state_scatter_triton.py:312` | 用每请求 `step_indices` 将选中的状态 scatter 到各自持久化槽；conv 有对应的滑窗 scatter |

普通中间状态实现的思路是：验证期间保留窗口各步状态，判定后按请求选择并提交，不为拒绝重新执行整个目标模型。

该提交版本也有 ReplaySSM 专门分支，通过每请求循环缓存、游标推进和 fold 等机制管理状态，conv 仍需要对应边界处理。不能将所有后端都描述成“保存 K 份完整 S”；对 Lumina 首次移植而言，完整中间状态方案更容易建立正确性参考，再评估紧凑缓存方案。

官方固定提交入口：[eagle_worker_v2.py](https://github.com/sgl-project/sglang/blob/e2982985110fb432fd8ddba5f0147a5004fd03ab/python/sglang/srt/speculative/eagle_worker_v2.py)。其余文件按同一提交定位；本轮对这些细节以本地源码读取为证。

## Lumina 的对应设计

将下面作为移植设计，而不是已实现功能：

```text
req_ids[B]                     请求身份，不能用可变 batch 行号替代
state_slots[B]                 各请求持久状态槽
draft_lengths[B]               各请求本轮实际草稿数
num_correct_drafts[B]          连续接受的草稿数
commit_lengths[B]              EOS/预算裁剪后的实际提交输入数
output_lengths[B]              实际输出数；当前 pending-token 不变量下等于 commit_lengths
target_hidden / draft_KV       各请求独立的 frontier 和所有权
```

无提前结束时，请求 i 接受 `a_i` 个草稿，输出接受前缀及一个 correction/bonus，提交 `a_i+1` 个输入。注意提交的输入是“原 pending token + 已接受草稿”，**本轮刚输出的 correction/bonus 仍是下一轮 pending token**，不能把它计入已计算的状态。EOS/预算须先裁剪输出，再选择真实提交边界。

例如 MTP-1 的两个请求，正确草稿数 `[1,0]` 对应通常输出/提交数 `[2,1]`。可在同一个验证前向中得到两个请求的结果，但 A 提交步1的状态，B 提交步0的状态；下轮逻辑位置不同，使用各自 positions 和 context lengths。

流程应为：

1. 为每请求独立预留私有 KV 验证窗口，建立扁平 token 输入与序列边界；逻辑有效长度不由 padding 决定。
2. 目标前向保留各步 S/conv 中间结果，持久已提交状态在接受前不被不可恢复地覆盖。
3. GPU 上逐请求判定接受前缀；同一序列内在首个拒绝处停止，不做跨请求 `min`。
4. 根据 EOS/预算裁剪后的提交长度，为每请求选择自己的状态步，提交 S/conv、KV 有效长度和 token/target hidden 前沿；释放可回收的拒绝后缀页。保留页内的无效字节由逻辑长度隐藏。
5. 按请求实际已提交 target hidden/token 配对延伸 draft KV，避免拒绝后缀混入草稿缓存；下一轮按可变长度打包或固定形状加 mask。

优先级建议：

- 先在当前 C1、MTP-1 上引入中间状态提交，消除拒绝时完整模型重放，并保留现有数值参考和故障回滚语义。
- 然后将 draft KV、长度、target hidden 和提交事务改为每请求管理，支持同一 batch 中 `[接受,拒绝]` 混合结果。
- 再做真实 C2/C4 的验证前向；测试乱序槽、不同草稿长度、EOS/预算、页边界、退出/抢占/异常，以及一个请求拒绝不污染另一个请求。
- 最后再优化真正批量 GEMM、norm、attention 和 CUDA Graph。借鉴状态管理不能自动消除 BF16 的批形状数值差异；现有严格对照继续保留。

完整中间 S 的暂存开销随请求数、窗口步数线性增长。27B 每个状态边界的全层 S 约144 MiB，另有约3 MiB conv；必须把 scratch 和故障恢复预算纳入 KV 分配，不能无上限复制。

本轮只做源码核查与设计记录，没有把 Lumina 标记为已支持多请求 MTP，也没有更改已验收的生产数值路径。
