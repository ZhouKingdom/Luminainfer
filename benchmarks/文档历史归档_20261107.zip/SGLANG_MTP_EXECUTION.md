# 参考 SGLang 的批量投影验证后端（2026-11-07）

本轮按本地 SGLang 固定提交 `e2982985110fb432fd8ddba5f0147a5004fd03ab` 核查目标验证的计算路径，随后实现可选 `qwen35_linear_backend="batch_invariant"`。不依赖 SGLang runtime、不安装 DeepGEMM，也不修改共享 PyTorch/Triton 环境。

## 上游实际做法

1. `models/qwen3_5.py:_forward_input_proj/forward` 对窗口全部 hidden rows 一起做投影，再调用 GDN 后端。它没有把整个线性层拆成一行一次的 Python 前向。QKV/Z、B/A 还有合并投影选项。
2. `layers/attention/linear/gdn_backend.py:forward_extend` 的 TARGET_VERIFY 分支使用窗口 conv update，并将全部投影后的 Q/K/V 传给专用递归验证 kernel。
3. `linear/kernels/gdn_triton.py:target_verify` 调用递归 kernel，`disable_state_update=True`，暂存每步状态；接受后逐请求提交。这部分状态所有权已在 Lumina 前一阶段实现。
4. `srt/batch_invariant_ops/batch_invariant_ops.py` 提供固定 tiling、K 累加顺序的 GEMM，以及 mean/RMSNorm 等确定性算子。其 Triton fallback 的 tile 配置不随 M 改变；DeepGEMM 分支也显式切换确定性算法。这是可选确定性路径，不能说 SGLang 默认所有后端都与单请求 cuBLAS 逐位一致。

固定提交源码：[模型](https://github.com/sgl-project/sglang/blob/e2982985110fb432fd8ddba5f0147a5004fd03ab/python/sglang/srt/models/qwen3_5.py)、[GDN](https://github.com/sgl-project/sglang/blob/e2982985110fb432fd8ddba5f0147a5004fd03ab/python/sglang/srt/layers/attention/linear/gdn_backend.py)、[batch-invariant 算子](https://github.com/sgl-project/sglang/blob/e2982985110fb432fd8ddba5f0147a5004fd03ab/python/sglang/srt/batch_invariant_ops/batch_invariant_ops.py)。本轮依据本地源码读取，不宣称已跑通完整 SGLang 服务对照。

## Lumina 的移植

`invariant_linear.py` 是面向 A100 BF16 小窗口的独立 Triton 实现：固定16×64×64 tile，FP32累加，K分片只由权重形状决定，以固定顺序合并FP32分片。M=1与M=2使用同一数值算法，同时在一个tile中共享权重读取。不照搬上游面向大batch/其他硬件的调优配置。

GDN先为整个验证窗口计算 QKV/Z/B/A，递归阶段继续沿请求的因果顺序推进各步暂存状态，最后批量计算输出投影。MLP/full-attention/LM head的标准投影也使用相同后端。小于256个输出通道的门控投影仍逐行调用原cuBLAS；RMSNorm保留原逐行参考，不改归约顺序。

范围是1–32行的BF16投影。更大验证窗口在 `decode_equivalent` 上下文逐行使用同一个新后端，避免混回旧cuBLAS；较长prefill继续原批量GEMM。因此这不是对所有prefill形状的全模型batch-invariance保证。未覆盖FP16、量化权重、TP、EP或新的HF logits验收。

```python
llm = LLM(model_path, enable_mtp=True, max_num_seqs=1,
          qwen35_linear_backend="batch_invariant",
          verification_cuda_graph=True, enforce_eager=True,
          max_model_len=4096, gpu_memory_utilization=.85)
try:
    output = llm.generate_speculative(
        prompt, SamplingParams(greedy=True, max_tokens=128),
        verification_mode="batched_experimental")
finally:
    llm.exit()
```

默认仍是 `decode_equivalent`。新后端建立自己的普通解码参考，不能保证与旧cuBLAS的输出完全相同；旧后端对照及失配记录必须保留。不能把“与新后端普通解码一致”写成“与旧归档无损兼容”。Graph与后端均在捕获时固定，不支持在已捕获的引擎里在线切换算子；下述切换只用于受控benchmark。

## 测试

最终相关CUDA回归 **135 passed、0 skipped**：`benchmarks/qwen35_sglang_invariant_20261107/regression_final.log`。覆盖真实投影尺寸、248320×5120的LM head、非连续行、不同M/行换序、bias与FP32数值参考；混合模型新旧后端分别比较普通decode与窗口的hidden/logits/S/conv/KV、Graph、大窗口回退、不同接受长度、EOS/预算和提交异常恢复。

初次测试有4个33行窗口失败，原因是超出32行后混回旧cuBLAS；现已修复为逐行调用同一新后端。原失败日志 `kernel_tests.log` 保留，没有放宽比较条件。

## 真实27B试跑

`paired_c1/`：四个历史失败输入、32输出预算、两轮反转模式顺序、同一驻留引擎比较旧普通decode、新普通decode、新eager投机、新Graph投机及新Graph无草稿控制。各新模式与新普通decode一致；与旧cuBLAS存在差异，因此benchmark保存 `legacy_mismatches` 并以非零状态结束，未宣称旧基线兼容。

初步两轮Graph投机约20.01 tok/s，无草稿Graph控制约16.27 tok/s。它们使用同一新后端、相同输入及Graph，才能用来观察投机的额外贡献；不能与前一阶段八副本总吞吐跨运行混算。新eager普通decode反而更慢，当前小kernel还需要Graph来摊薄Python/启动开销。

扩大验收使用16个混合输入、原64/128输出预算、两轮，分为四个独立TP1进程；结果在 `full_shard{0,1,2,3}/result.json`。最终[汇总](benchmarks/qwen35_sglang_invariant_20261107/summary.json)：新后端各模式均32/32与自身普通decode逐token一致，两轮基线相同，160次测量全部回收资源；135项相关CUDA测试通过、公开构造参数smoke通过。所有runtime与测试源码快照SHA256已与当前文件核对。

| 分片 | Graph无草稿控制 tok/s | Graph投机 tok/s | 同后端投机提升 |
|---|---:|---:|---:|
| 0 | 19.780 | 26.233 | 32.62% |
| 1 | 19.993 | 27.064 | 35.37% |
| 2 | 18.892 | 23.801 | 25.98% |
| 3 | 20.205 | 27.390 | 35.56% |

各分片是C1，同引擎、同输入、同输出、同后端、同Graph，先预热再计时，第二轮反转模式顺序。总token除以各进程阶段耗时总和为26.052 vs19.704 tok/s，配对提升 **32.21%**；这是按进程耗时汇总的速率，不能称为四卡屏障吞吐或1→4扩展效率。Graph候选实际重放1410次、控制组2686次，草稿接受1258/1410（89.22%），两个模式的2718个输出token全部一致。其余准备/提交开销仍包含在计时中。

相对旧cuBLAS，4个输入（2、6、39、119）两轮共8/32条输出不同，旧基线兼容验收为 **false**；相应分片保留非零退出，原始记录未过滤。旧后端自身与最初归档32/32完全一致，说明默认路径没有被改写成新数值基线。新后端的正确性结论仅是“与同后端普通decode一致”，不覆盖HF/模型质量或旧后端位级兼容。

四个相关源码文件及上游许可证已在 `sglang_reference/` 冻结，`manifest.json` 给出提交与SHA256。当前SGLang相关文件工作树干净，引用的代码与所记提交一致。

复现：

```bash
python -m benchmarks.bench_mtp_state_commit \
  --linear-backend batch_invariant --compare-legacy \
  --compare-graph --graph-control --tokens 128 --repeats 2 \
  --output benchmarks/mtp_invariant_paired_new
```

完成时八张GPU均仅占4 MiB，无计算进程，实验资源已释放。

当前默认契约不变。新后端的HF数值误差、更多输入上的模型质量、C2/C4真实模型性能及普通decode原生Graph仍需各自验收，不能据小集提速默认开启。

## 新旧输出为何不同：同状态诊断

[诊断记录](benchmarks/qwen35_sglang_invariant_20261107/backend_diagnosis.json)针对最早分歧输入id=2：共用36-token prefill与第0个输出token，恢复同一S/conv checkpoint，对相同pending token与相同KV前缀分别运行旧/新普通decode。不执行MTP、接受判定或CUDA Graph。

首个不同模块为 `model.layers.0.linear_attn.in_proj_qkv`，输入逐元素相同；10240个输出有17个不同，max_abs=0.03125、RMSE约0.000725。对这17个不同通道使用相同BF16输入/权重计算FP64点积，新路径16/17与FP64参考正确舍入到BF16的结果相同，旧路径0/17；这是针对所选不同通道的局部检查，不代表整模型质量或所有算子精度排序。

最终logits的新旧max_abs=0.140625、RMSE约0.020744。旧路径token5839与6007均为28.75，`argmax`取5839；新路径两者分别为28.625和28.75，选择6007。注意 `topk` 的并列顺序不等于 `argmax` 的并列处理，诊断分别保存两者。

因此，这一例已直接定位为不同GEMM归约/舍入导致的数值差异，经模型传播后打破候选平局；不是接受长度、状态提交或Graph引起。其余3个失配输入尚未逐层做此诊断，不能据此把全部差异和模型质量影响都认证为“无害误差”。8/32统计的是完整输出序列不相同，实际是4输入×两轮，并非25%的token计算错误；新HF/质量验收仍未完成。
