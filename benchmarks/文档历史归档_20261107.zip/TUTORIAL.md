# zjh-vllm 从零到懂：小白手把手教程

> 目标读者：已经写过**最简版** LLM 推理（能加载权重、手写 transformer 前向、greedy 自回归生成一个 token），想**完全搞懂**这个项目的每一个机制。
>
> 读法建议：第 1、2 节先建立全局观（一张图 + 一张演进地图），第 3 节是核心（逐个机制讲「为什么 + 怎么做 + 代码在哪」），第 4、5 节用来定位代码和 trace 调用链。**每个小节都先回答「最简版为什么慢/为什么不够」，再讲这个项目怎么解决**——这样知识是长在你已有的基础上，而不是硬背。

---

## 1. 一句话 + 一张图：这个项目在做什么

**一句话**：把「一次只为一个请求、每个新 token 都重算整个序列」的最简版，改造成「一次同时服务几百个请求、每个 token 只算增量、显存按需分块、大模型切到多卡」的工业级推理引擎。

一个 token 从进来到出去的完整旅程：

```
                 ┌─────────────────────────────────────────────────────────────┐
   用户请求 ───► │  Scheduler（调度器）                                         │
 (prompt token)  │  决定这一步做 prefill 还是 decode、挑哪些序列、切多少 token  │
                 └──────────────────────────┬──────────────────────────────────┘
                                            │ seqs（要算的序列）+ is_prefill
                                            ▼
                 ┌─────────────────────────────────────────────────────────────┐
                 │  ModelRunner（模型执行）                                    │
                 │  词嵌入 → N 层 Decoder(attention + MLP/MoE) → 归一化 → lm_head │
                 │  其中 attention 读写「分页 KV cache」，TP/EP 跨卡通信        │
                 └──────────────────────────┬──────────────────────────────────┘
                                            │ logits [batch, vocab]
                                            ▼
                 ┌─────────────────────────────────────────────────────────────┐
                 │  Sampler（Triton 采样器）                                   │
                 │  温度/重复惩罚 → top_k/top_p 过滤 → greedy 或 Gumbel-max 采样 │
                 └──────────────────────────┬──────────────────────────────────┘
                                            │ 新 token id
                                            ▼
                 ┌─────────────────────────────────────────────────────────────┐
                 │  Scheduler.postprocess                                    │
                 │  把新 token 挂到序列上、判断是否结束、更新前缀缓存哈希        │
                 └─────────────────────────────────────────────────────────────┘
                     └──► 又回到 Scheduler，循环，直到所有序列生成完
```

**关键认知**：这是一个**循环**。`LLMEngine.generate()`（`engine/llm_engine.py`）就是套了一个 `while not finished: step()` 的循环，每一轮 `step()` 走完上面整条链路，产出一批 token。你写的最简版里那个「生成一个 token 的 for 循环」，在这里被拆成了「调度 + 执行 + 采样 + 后处理」四段，核心价值全在**调度**和**执行**这两段。

---

## 2. 演进地图：从最简版长出了什么

把你已有的最简版当成 v0，这个项目是 vN。每一层演进都是为了解决一个具体问题：

| 版本 | 你做了什么 | 解决的问题 | 对应的代码 |
|---|---|---|---|
| **v0 最简版** | 手写 transformer 前向，每次生成一个 token 都重新算整个序列 | （基线） | — |
| **v1 KV Cache** | 把每层的 K/V 缓存起来，新 token 只算增量 | **别重算历史** | `layers/attention.py` |
| **v2 Continuous Batching** | 多个请求拼成一批，共享一次前向 | **别让 GPU 空转** | `engine/scheduler.py` |
| **v3 Paged Attention + 前缀缓存** | KV 按固定块分配，块表映射，哈希复用前缀 | **别浪费显存、共享相同前缀** | `engine/block_manager.py`, `layers/paged_attention.py`（自研 decode kernel） |
| **v4 张量并行 TP** | 权重按层切到多卡，NCCL 通信 | **单卡放不下大模型** | `layers/linear.py` |
| **v5 手写 Triton 采样器** | top_k/top_p/采样用 Triton 内核 | **采样别拖后腿** | `layers/sampler.py` |
| **v6 MoE + 专家并行 EP** | 稀疏专家 + all-to-all 分布多卡 | **跑 30B 稀疏模型** | `layers/moe.py`, `layers/ep_moe.py` |
| **v7 FP8 KV 量化** | KV 存 8-bit，显存减半 | **KV 太吃显存** | `layers/attention.py` |
| **v8 CUDA Graph** | decode 阶段 kernel 打包成图 | **消除 launch 开销** | `engine/model_runner.py` |
| **v9 OpenAI 服务层** | 异步引擎 + HTTP/SSE | **对外提供服务** | `engine/async_llm_engine.py`, `server.py` |

**你不需要一次全懂**。下面第 3 节就是按这个顺序，逐个讲透。

---

## 3. 核心机制逐个拆

### 3.1 KV Cache：最简版最大的性能瓶颈

**最简版的问题**：生成第 t 个 token 时，你要把 `[t0, t1, ..., t]` 整个序列喂进模型，attention 对前面 t 个 token 都算了 `QK^T`。随着序列变长，每生成一个 token 的成本是 O(n²)（n = 当前长度）。生成 1000 个 token，总共要算 O(n³) 级别的 attention 计算量。

**KV Cache 的想法**：attention 里，**历史 token 的 K 和 V 不会变**（它们只由「该 token 自己」和「它之前的 token」决定，不受后面新 token 影响）。所以算过一次之后，把每层每个历史 token 的 K、V 存起来，新 token 只需要：
1. 算自己的 Q、K、V；
2. 把自己的 K、V **追加**到缓存；
3. Q 和缓存的**所有** K 做注意力（新的 V 参与加权）。

每生成一个 token 的 attention 成本从 O(n²) 降到 O(n)（只算新 token 和历史 K 的点积）。**这是 LLM 推理从「玩具」到「可用」的第一次飞跃。**

**这个项目怎么存**：在 `layers/attention.py` 的 `Attention.forward` 里：

```python
# 每步先把自己的 K/V 写进缓存（decode 时 slot_mapping 指向当前 token 的位置）
store_kvcache(k, v, k_cache, v_cache, context.slot_mapping)
# prefill 时用 flash_attn_varlen_func 一次算完整个 prompt
# decode 时用自研 paged_attention_decode（bf16 路径，见 3.13）或 flash_attn_with_kvcache（fp8 路径），
# 只算新 token 对缓存 KV 的注意力
```

缓存张量在哪分配？`engine/model_runner.py` 的 `allocate_kv_cache()`，形状是：

```
[2, num_layers, num_blocks, block_size, num_kv_heads, head_dim]
 ↑          ↑            ↑           ↑            ↑           ↑
 K/V     第几层      第几个块   块里几个token  几个KV头    每个头维度
```

**为什么 KV cache 会爆显存（你之前问过的「28万 vs 4万」）**：

一个 token 在**所有层**占的 KV 字节数 = `num_layers × num_kv_heads × head_dim × 2(K和V) × dtype字节`。

以 Qwen3-32B 为例：64 层 × 8 KV 头 × 128 维 × 2 × 2 字节(bf16) = **256 KB/token**。

256 条并发 × 平均 ~1100 token ≈ 28 万 token，需要 ~72GB，单张 80GB 卡放不下（还要放权重和激活），所以 bench.py 用 `tensor_parallel_size=4` 把 KV 也分摊到 4 张卡。这就是「28 万 vs 单卡 4 万」的来源——**KV cache 是 LLM 推理最吃显存的东西，比权重还敏感**（因为权重是固定的，KV 随并发×长度线性增长）。

> 补充：GQA（Grouped Query Attention）能省 KV 显存。Qwen3-32B 有 64 个 Q 头但只有 8 个 KV 头，多个 Q 头共享同一组 K/V（`num_heads // num_kv_heads = 8` 个 Q 头共享 1 组 KV）。这就是为什么公式里是 `num_kv_heads` 而不是 `num_heads`。

---

### 3.2 一次前向里，attention 到底算了什么

这是理解后续所有机制的地基，讲细一点。`models/qwen3.py` 的 `Qwen3Attention.forward`：

```python
qkv = self.qkv_proj(hidden_states)              # 一个矩阵乘，同时算出 Q、K、V
q, k, v = qkv.split([q_size, kv_size, kv_size]) # 按维度切开
q, k = self.rotary_emb(positions, q, k)         # RoPE 旋转位置编码
o = self.attn(q, k, v)                          # 注意力（读/写 KV cache 发生在这里）
output = self.o_proj(o.flatten(1, -1))          # 输出投影
```

要点：

- **QKV 是一次矩阵乘算出来的**（`QKVParallelLinear` 把 q_proj/k_proj/v_proj 三个权重拼成一个大矩阵）。你的最简版可能分开算三个 `nn.Linear`，这里合并了——省 kernel launch。
- **RoPE**（`layers/rotary_embedding.py`）：把 Q/K 按位置旋转。核心是 `apply_rotary_emb`：把向量后半维当「虚部」，乘上位置相关的 cos/sin。**它不改变向量长度，只是旋转方向**，让模型能感知 token 的相对位置。`cos_sin_cache` 预先把所有位置的 cos/sin 算好，forward 时直接查表。
- **attention 的两种形态**（关键！）：
  - **prefill**：`flash_attn_varlen_func`，输入是一整段 prompt，一次性算完整段的自注意力（带因果 mask，每个 token 只看自己和前面）。**计算密集**（compute-bound）。
  - **decode**：每个序列只有 1 个新 token，它对缓存里的所有历史 KV 做注意力。bf16 路径用自研的 `paged_attention_decode`（见 3.13），fp8 路径用 `flash_attn_with_kvcache`。**带宽密集**（memory-bound，因为要读大量 KV）。

这个 prefill/decode 的区分贯穿整个项目——**几乎每个优化（调度、CUDA Graph、KV 缓存）都要分这两种情况处理**。

---

### 3.3 Continuous Batching：为什么一次只跑一个请求是浪费

**最简版的问题**：你一次只服务一个请求。生成一个 token 的 decode 阶段，GPU 大部分时间在**读权重和 KV**（memory-bound），算力是闲着的。同时服务多个请求时，如果串行处理，GPU 利用率极低。

**Continuous Batching 的想法**：把**处于不同生成阶段**的多个请求拼成一个 batch，一次前向同时算它们的下一个 token。这样 GPU 一次读权重就能服务几十上百个请求，算力利用率和吞吐都大幅提升。

「Continuous」的关键在于：请求**不是**一次性全都进来再一起生成（那是 static batching，会互相等最慢的），而是**动态加入、动态退出**——有请求生成了 EOS 就退出，立刻有新的 waiting 请求补进来。

**这个项目怎么实现**：`engine/scheduler.py`。核心数据结构是两个队列：

```python
self.waiting = deque()   # 还没开始（或被抢占）的请求
self.running = deque()   # 正在生成中的请求
```

`Scheduler.schedule()` 每一轮决定「这一步算什么」，返回 `(scheduled_seqs, is_prefill)`。

---

### 3.4 调度器：prefill 和 decode 的分工

这是整个引擎的「大脑」，值得反复读。`engine/scheduler.py` 的 `schedule()` 逻辑（关键代码，含**交替旗标**）：

```python
# 阶段 0：running 和 waiting 都非空时，用 _prefill_turn 决定本轮做 prefill 还是 decode
if self.waiting and self.running and self._prefill_turn:
    seqs = self._schedule_prefills()      # 本轮轮到 prefill
    if seqs:
        self._prefill_turn = False        # 下次轮到 decode
        return seqs, True

# 阶段 1：优先 decode（running 队列每个序列各生成 1 个 token）
if self.running:
    seqs = self._schedule_decodes()
    if seqs:
        self._prefill_turn = True         # 下次轮到 prefill
        return seqs, False

# 阶段 2：prefill（waiting 队列拿新请求）
if self.waiting:
    seqs = self._schedule_prefills()
    if seqs:
        self._prefill_turn = False
        return seqs, True
```

**为什么 decode 优先，但又不能「绝对优先」**：

- **decode 优先的理由**：已经在 running 的请求已投入成本（KV 占着显存、算了一半），如果让新来的长 prefill 把它们饿死，延迟会很差。
- **但不能绝对优先**：如果只要 running 非空就永远 decode，那新请求的 prefill 会被无限期推迟（尤其持续有请求进来时）。所以用 `_prefill_turn` 交替旗标——每做完一轮 decode 置 `True`（下次轮到 prefill），每做完一轮 prefill 置 `False`（下次轮到 decode）。这样 running 和 waiting 都非空时，**prefill 和 decode 轮流执行**，谁都不饿死谁。

> 记忆点：**decode 优先是「基调」，交替旗标是「防饿死」的补丁**——没有交替，单纯 decode 优先会导致新请求永远进不来。

**Chunked Prefill（分块预填充）**：`_schedule_prefills` 里，一个超长 prompt 不会一次性算完，而是**切成几块**，每轮算 `min(剩余 token, 本轮预算)`。为什么？因为一个 8000 token 的 prompt 一次性 prefill 会：
1. 占满 `max_num_batched_tokens` 预算，让其他请求这轮没法调度；
2. 长时间阻塞 decode，让 running 请求的首 token 延迟爆炸。

切块之后，长 prompt 的 prefill 可以**穿插**在 decode 之间，延迟更平稳。这就是 `max_num_batched_tokens` 的意义——**每轮能塞进 GPU 的 token 总数上限**。

**抢占（Preemption）**：`_schedule_decodes` 里，如果显存块不够给新 token，就 `self.preempt(victim)` 把 running 队尾的序列踢回 waiting（释放它的 KV 块）。队尾是「最晚调度、影响最小」的序列（LIFO 思想）。**代价**：被抢占的序列 KV 被丢，恢复时要重新 prefill——这就是 RESUME_PREP 里写的 tradeoff。

---

### 3.5 Paged Attention + block table + 前缀缓存

**最简版的问题（显存碎片 + 无法共享）**：如果你为每个序列按「最大可能长度」预分配一整块连续 KV，那大部分是浪费的（大多数请求实际没到最大长度），而且无法复用。

**Paged Attention 的想法**（借用操作系统的「虚拟内存分页」）：

1. 把 KV cache 切成**固定大小的物理块**（`block_size`，默认 256 token/块）。
2. 每个序列维护一个 **block_table**（逻辑块 → 物理块 id 的映射），按需分配块，用完释放。
3. attention 时通过 block_table 定位物理块，而不是假设连续内存。

看 `engine/block_manager.py`：

```python
class BlockManager:
    self.free_block_ids = deque(range(num_blocks))  # 空闲物理块池
    self.used_block_ids = set()                      # 已占用
    self.hash_to_block_id = {}                       # 前缀缓存哈希 → 块 id
```

`Sequence.block_table`（`engine/sequence.py`）就是那个「逻辑→物理」的映射列表。`prepare_block_tables`（`model_runner.py`）把它整理成 `[num_seqs, max_blocks]` 的 int32 张量（-1 表示无块），喂给 flash-attn 的 `block_table` 参数。

**前缀缓存（Prefix Caching）**：多个请求经常有相同的开头（比如同样的 system prompt）。`BlockManager.compute_hash` 用 xxhash 对每个块的 token 序列算指纹，`hash_to_block_id` 记录「指纹 → 物理块」。新序列进来时，`can_allocate` 逐块比对哈希，命中的块**直接复用**（不重新算 KV）。命中后二次校验 `block.token_ids == 当前 token` 防哈希碰撞（`engine/block_manager.py:47` 和 `:64-67`）。

**代码走读：命中怎么复用、引用计数怎么涨**（`engine/block_manager.py`）：

```python
# 1. can_allocate：逐块比对哈希链，算出能复用几个前缀块
def can_allocate(self, seq):
    h = -1
    num_cached_blocks = 0
    for i in range(seq.num_blocks - 1):          # 只对「完整块」做（最后一块可能不满）
        token_ids = seq.block(i)
        h = self.compute_hash(token_ids, h)       # 哈希链：上一块的 hash 当 prefix 传入
        block_id = self.hash_to_block_id.get(h, -1)
        if block_id == -1 or self.blocks[block_id].token_ids != token_ids:
            break                                  # 第一个未命中就停（前缀必须连续）
        num_cached_blocks += 1
    return num_cached_blocks

# 2. allocate：命中块 ref_count++（共享），新块从空闲池分配
def allocate(self, seq, num_cached_blocks):
    for i in range(num_cached_blocks):
        block_id = self.hash_to_block_id[compute_hash(seq.block(i), ...)]
        self.blocks[block_id].ref_count += 1       # 多个序列共享同一物理块
        seq.block_table.append(block_id)
    for i in range(num_cached_blocks, seq.num_blocks):
        seq.block_table.append(self._allocate_block())   # 新块，从 free_block_ids 弹一个
```

两个关键细节：

- **哈希是链式的**：`compute_hash(token_ids, prefix)` 把**上一块的 hash** 作为 `prefix` 拼进本块再算。所以「第 2 块的 hash」依赖「第 1 块的 hash」，相同前缀 → 相同 hash 链。这保证了前缀缓存只能复用**从头连续**的块，不会出现「中间相同、开头不同」被误判命中。
- **引用计数共享**：命中块 `ref_count += 1`，多个序列共享同一物理块。对应 §3.12 讲的：只有 `ref_count` 降到 0 才真正释放。

**KV cache 到 flash-attn 的索引**（你之前问过的 block_table 怎么索引）：token t 落在 `block_table[t // block_size]` 这个物理块的第 `t % block_size` 个位置。`prepare_prefill`/`prepare_decode` 里算的 `slot_mapping` 就是「每个 token 应该写到哪个物理槽位」（`slot = block_id * block_size + 块内偏移`）。

> decode 的 attention kernel 是**手写的**（不调 flash-attn 的 decode 接口），并且做了 GQA shared-KV 等优化把性能追平 flash-attn——完整的「为什么手写 + 怎么调快 + split-K 为什么回退」见 **3.13**。

---

### 3.6 张量并行 TP：单卡放不下怎么办

**问题**：Qwen3-32B 权重 bf16 就要 ~64GB，单卡 80GB 装不下（还得留 KV 和激活）。而且 4 张卡放着不用也浪费。

**TP 的想法**：把**每一层的权重**按维度切开，分到多张卡上，每卡算一部分，再通过 NCCL 通信汇总。看 `layers/linear.py`，两种核心切法：

- **ColumnParallelLinear**（列并行）：按**输出维度**切。每张卡持有 `output_size/tp_size` 行权重，算出来的结果是完整输入 × 部分输出。**输入完整、输出局部，不需要通信**。用于 QKV 投影、gate_up 投影。
- **RowParallelLinear**（行并行）：按**输入维度**切。每张卡持有 `input_size/tp_size` 列，算完是**部分和**，需要 `dist.all_reduce` 汇总。用于 o_proj、down_proj。

为什么这样配对？因为 column 的输出正好是下一层 row 的输入，**column 不通信、row all_reduce 一次**，中间激活不用跨卡搬运。

**切分规则**（这是理解 TP 的关键，你问过「column/row 为什么」）：

```
列并行（QKV、gate_up）：输出维度切分，每卡算一部分 head/专家 —— 输入完整，输出局部，不通信
行并行（o_proj、down）：输入维度切分，每卡输入是上层部分输出 —— 算完要 all_reduce
```

**权重怎么切**：`weight_loader`（每个线性层的 `LinearBase` 里）。加载原始完整权重时，按 `tp_rank` 用 `narrow` 切出自己那一份（`layers/linear.py` 各 `weight_loader` 方法）。

**KV cache 也按头切**：`allocate_kv_cache` 里 `num_kv_heads = hf_config.num_key_value_heads // tp_size`，每卡只存自己的 KV 头。**注意**（你之前确认过的）：每张卡都存**完整序列长度**的 KV，只是 KV 头少了（TP 切的是「头」这个维度，不是「序列长度」）。

**TP 怎么跑起来**：`engine/llm_engine.py` 用 `multiprocessing(spawn)` 起 `world_size` 个进程，每个进程一个 `ModelRunner`，rank 0 通过共享内存（`SharedMemory` + `Event`）给其他 rank 发指令。`utils/tp.py` 的 `set_tp/get_tp_size/get_tp_rank` 提供全局 TP 状态（这是后来为了支持 EP 才解耦出来的，见 3.7）。

**代码走读：主从模式 + 共享内存通信协议**（`engine/model_runner.py`）：

```python
# 每个进程先初始化 NCCL（用于张量通信），再按 rank 分工
dist.init_process_group("nccl", "tcp://localhost:2333", world_size=world_size, rank=rank)

# rank 0（主进程）：把「这一步要调哪个方法、参数是什么」序列化写进共享内存，set event 唤醒所有 worker
def write_shm(self, method_name, *args):
    data = pickle.dumps([method_name, *args])
    n = len(data)
    self.shm.buf[0:4] = n.to_bytes(4, "little")    # 先写 4 字节长度
    self.shm.buf[4:n+4] = data                     # 再写数据
    for event in self.event:
        event.set()                                # 唤醒所有 worker

# 其他 rank（worker）：阻塞等 event，读到指令后执行
def read_shm(self):
    self.event.wait()                              # 等 rank 0 set event
    n = int.from_bytes(self.shm.buf[0:4], "little")
    method_name, *args = pickle.loads(self.shm.buf[4:n+4])
    self.event.clear()
    return method_name, args
```

三个关键点：

- **主从模式**：rank 0 是「大脑」（跑调度、采样、决定每一步算什么），其他 rank 是「worker」（只执行分给它的那部分前向）。rank 0 通过 `call("run", seqs, is_prefill)` 广播指令，所有 rank（含 rank 0）各自执行。
- **两条通信通道分工**：**NCCL** 传「张量」（TP 的 all_reduce、EP 的 all-to-all 都走 NCCL）；**SharedMemory + Event** 传「控制流」（这一步调 run 还是 exit、参数是什么）。控制流用 pickle 序列化更简单，张量用 NCCL 更高效。
- **长度前缀协议**：`write_shm` 先写 4 字节长度再写数据，`read_shm` 先读长度再读数据——这是最简单的「变长消息」序列化，解决 pickle 流边界问题。

---

### 3.7 MoE + 专家并行 EP

**MoE（Mixture of Experts）是什么**：普通的 MLP 是「所有 token 都过同一个 FFN」。MoE 有**很多个专家 FFN**（Qwen3-30B-A3B 有 128 个），每个 token 由 **router** 选出 top-k 个专家（这里是 top-8），只过这几个专家的 FFN，结果按路由权重加权求和。好处：**总参数量巨大（30B）但每个 token 只激活一小部分（3B）**，用「稀疏激活」换「容量」。

看 `layers/moe.py` 的 `MoE.forward`：

```python
routing_logits = self.gate(x)                    # router：Linear(hidden, num_experts)
topk_weights, topk_ids = torch.topk(routing_logits, k)   # 选 top-k 专家
# 单卡：本地遍历专家，每个 token 过它选中的专家 FFN
```

**EP（Expert Parallelism）为什么需要**：30B 参数单卡放不下。但 TP 有个限制——Qwen3-30B-A3B 的 `num_key_value_heads=4`，TP 最多切 4（因为 KV 头要能被 TP 整除）。要上 8 卡，就得用**另一种并行**：把 **128 个专家分布到 8 张卡**（每卡 16 个），attention 等非 MoE 层保持完整。

**EP 的数据流**（`layers/moe.py` 的 `_forward_ep`，这是项目最有技术含量的一段）。先看完整代码，再看三个关键技巧：

```python
def _forward_ep(self, x, topk_weights, topk_ids):
    T, k, hidden = x.shape[0], self.num_experts_per_tok, self.hidden_size
    L = self.num_local_experts                       # 每卡专家数 = num_experts // world_size

    # ① 展开成 [T*k] 的 token-专家组合（每个 token 复制 k 份，因为它要发到 k 个专家）
    x_rep = x.repeat_interleave(k, dim=0)            # [T*k, hidden]
    w_flat = topk_weights.reshape(-1)                # [T*k]
    expert_flat = topk_ids.reshape(-1)               # [T*k] 全局专家 id

    # ② 全局专家 id → (目标 rank, 本地专家 id)：商是 rank，余是本地 index
    local_expert = expert_flat % L
    target_rank = expert_flat // L

    # ③ 按目标 rank 稳定排序，让发到同一卡的 token 连续
    order = torch.argsort(target_rank, stable=True)
    x_sorted = x_rep[order].contiguous()
    local_expert_sorted = local_expert[order].contiguous().to(torch.int32)

    # ④ 算发送量，all_gather 交换得到「各卡发给我多少」（接收量）
    input_split = [int((target_rank == r).sum()) for r in range(world_size)]
    # all_gather(input_split) → output_split[s] = 卡 s 发给我的数量

    # ⑤ all-to-all dispatch：把 token 和本地专家 id 发到专家所在卡
    dist.all_to_all_single(recv_x, x_sorted, output_split_sizes=output_split, input_split_sizes=input_split)
    dist.all_to_all_single(recv_exp, local_expert_sorted, ...)

    # ⑥ 本地计算：收到的 token 用它命中的本地专家算 FFN
    recv_out = torch.empty_like(recv_x)
    for local_id in range(L):
        mask = recv_exp == local_id
        if mask.any():
            recv_out[mask] = self.experts[local_id](recv_x[mask])

    # ⑦ all-to-all combine（dispatch 的对称逆变换），把结果送回原卡
    dist.all_to_all_single(back_x, recv_out, output_split_sizes=input_split, input_split_sizes=output_split)

    # ⑧ scatter 回原位，加权求和
    out_full[order] = back_x                          # 逆 permute
    return (out_full.reshape(T, k, hidden) * w_flat.reshape(T, k, 1)).sum(dim=1)
```

三个关键技巧（面试问 EP 就讲这三个）：

- **`% L` 和 `// L` 分解专家 id**：全局专家 id 的「商」是目标 rank、「余」是本地 index。因为每卡恰好 L 个专家，这是把「全局 → 本地」一步算出的最简写法。
- **先 argsort 再 all-to-all**：`argsort(target_rank, stable=True)` 让发到同一卡的 token 连续排列，all-to-all 要求「按目标 rank 分组的连续块」，排序就是为这个。
- **input_split vs output_split 是「发送量 vs 接收量」**：每个 rank 只知道「自己发多少」，通过一次 `all_gather` 交换，才得到「各卡发给自己多少」——这是 all-to-all 的经典前置步骤，因为接收 buffer 大小要提前分配。

**对称逆变换**：combine 的 `output_split_sizes=input_split, input_split_sizes=output_split` 正好是 dispatch 的反向，保证「发出去的 token 结果原路返回」；`out_full[order] = back_x` 是 ③ 排序的逆 permute，把结果放回 token 原来的顺序。

**关键难点——TP/EP 维度解耦**：TP 切的是「头/隐藏维」，EP 切的是「专家维」，这是两个正交的维度。但 `dist.get_world_size()` 只有**一个**数，而 EP 模式下 world_size=8（8 卡）但非 MoE 层要 replicated（tp=1）。所以项目引入了 `utils/tp.py`：`set_tp(size, rank)` 单独记录 TP 维度，`get_tp_size/get_tp_rank` 替代 `dist.get_world_size/get_rank`，让「非 MoE 层」知道自己是 replicated 的（tp=1），而 MoE 层用 `dist` 的 world_size=8 做 all-to-all。这就是 `layers/linear.py` 里为什么用 `get_tp_rank` 而不是 `dist.get_rank`。

**权重加载的 EP 过滤**：`utils/loader.py` 的 `load_model` 带 `expert_start/expert_end`，只加载 `[start, end)` 范围的专家，并把全局专家 id 重映射成本地 index（`experts.5` → 本地 `experts.0`）。注意它用 `original_name` 读 safetensors、用重映射后的 `weight_name` 找参数——这是踩过的坑（EP 权重加载）。

---

### 3.8 FP8 KV 量化：显存减半

**问题**：KV cache 太吃显存（3.1 算过，256KB/token）。bf16 存 KV 要 2 字节，能不能用 1 字节存？

**FP8 的想法**：用 8-bit 浮点（e4m3：1 符号位 + 4 指数位 + 3 尾数位）存 K/V，每个 token 再存一个 **scale**（该 token 所有元素的最大绝对值），反量化时 `x_bf16 = x_fp8 * scale`。

看 `layers/attention.py` 的 `store_kvcache_fp8`：

```python
scale_k = key.float().abs().amax(dim=(1,2))      # 每 token 的 scale = max(|x|)
key_fp8 = (key / scale_k).to(torch.float8_e4m3fn) # 量化
k_scale[sm] = scale_k                             # 存 scale
```

**为什么显存能减半**：K/V 从 2 字节 → 1 字节。scale 存 fp32（4 字节）但**每 token 只有一个 scale**，而每 token 有 `num_kv_heads × head_dim = 8 × 128 = 1024` 个元素，所以 scale 开销 `4/1024 ≈ 0.4%`，可忽略。

**代价（tradeoff）**：e4m3 只有 3 位尾数，精度损失 ~3%。读取时要把 fp8 反量化回 bf16 再喂 attention（flash-attn 2.x 不支持 fp8 KV），这个 `gather_dequant`（`attention.py`）会做一次额外的显存拷贝——**自研的 `paged_attention_decode`（3.13）已经让 bf16 decode 路径脱离 flash-attn，但 fp8 decode 路径仍走 `gather_dequant` + flash_attn_varlen**（自研 kernel 暂只支持 bf16，不支持 fp8 KV），这是下一步可消除的技术债。

---

### 3.9 CUDA Graph：消除 kernel launch 开销

**问题**：decode 阶段每步只算 1 个 token，但要 launch 几百个 kernel（每个矩阵乘、每个 norm、每个 attention 都是 kernel）。CPU 逐个 launch 的**开销**相对计算量占比很大，成为瓶颈。

**CUDA Graph 的想法**：把一整套 kernel 序列**录制**成一张图，之后一次 `replay()` 就能全部执行，省掉逐个 launch 的 CPU 开销。

看 `engine/model_runner.py` 的 `capture_cudagraph`：按 batch size 分桶（1/2/4/8/16/...），每个桶录制一张图。decode 时 `run_model` 选一个 `>= 当前 batch` 的图，把输入写进固定的 `graph_vars` 张量，`graph.replay()`。

**为什么按 batch 分桶**：CUDA Graph 要求**固定形状**，而 decode 的 batch size 每次都变。所以按 batch size 分桶，当前 batch 用「能装下它的最小桶」。

**为什么只 decode 用**：prefill 的序列长度变化太大，不好录制（这是 tradeoff，prefill 走 eager）。

---

### 3.10 采样器：top_k/top_p 和可复现采样

**问题**：拿到 logits `[batch, vocab]` 后，怎么高效地采样出 token？vocab 通常几万~十几万，如果每个序列都做「排序 + softmax + 采样」，开销不小。

**这个项目用 3 个 Triton 内核**（`layers/sampler.py`），全程无 Python 循环、无大中间张量：

1. `_logits_process_kernel`：温度缩放 + repetition penalty（重复惩罚：历史出现过的 token，logit>0 则除以 penalty，<0 则乘以 penalty）。
2. `_topk_topp_kernel`：top_k 和 top_p 过滤。
3. `_sample_kernel`：greedy（argmax）或 Gumbel-max 采样。

**top_k 的巧妙之处——二分阈值**：不用对整个 vocab 排序（O(V log V)），而是二分查找「第 k 大的 logit」这个阈值（14 次迭代），每次迭代数一遍 `>= mid` 的个数，最后把 `logit < 阈值` 的置 `-inf`。复杂度 O(V)。

**Gumbel-max 技巧**：想从 softmax(logits) 分布采样，等价于 `argmax_i(logit_i + Gumbel_i)`，其中 `Gumbel = -log(-log(U(0,1)))`。这样**不用显式计算 softmax**，直接加噪声取最大。配合 **Philox** 随机数生成器（`tl.rand(seed, offs)`），给定 seed 就能**可复现**地采样——这是测试确定性、对比不同实现的关键。

---

---

### 3.11 面试追问速查：每个机制「一针见血」的问题

> 面试官不会问「你用 KV cache 了吗」，会问「KV cache 为什么省算力」「GQA 省多少显存」。下面是每个机制 1~2 个高频追问 + 一句话答案，帮你把上面学到的讲出口。

- **KV cache**：为什么 KV 随序列线性增长、权重固定？→ 每个 token 都有独立的 K/V 要存，而权重全 token 共享。GQA 让 8 个 Q 头共享 1 组 KV，KV 显存降 8 倍。
- **prefill vs decode**：为什么一个 compute-bound、一个 memory-bound？→ prefill 一次算 n 个 token 的 attention（O(n²)），算力吃满；decode 每步只算 1 个 token，瓶颈是读权重和 KV 的带宽。
- **continuous batching**：和 static batching 差在哪？→ static 要等整批都完成才换下一批（长尾拖慢）；continuous 动态进出，有请求结束立刻补新请求。
- **chunked prefill**：`max_num_batched_tokens` 是什么？→ 每轮能塞进 GPU 的 token 总数上限；超长 prompt 切块，避免占满预算、阻塞 decode。
- **paged attention**：`block_size` 怎么选？→ 太大则短序列碎片化浪费，太小则 block_table 开销大、attention 索引多；256 是经验值。
- **自研 decode attention**：GQA 为什么让 v1 慢 8 倍、怎么追平？→ 8 个 Q 头共享 1 组 KV，v1 的 grid 按 `num_heads` 展开，每个 Q 头各读一遍同一 KV，带宽放大 8x；改成按 `num_kv_heads` 展开、一个 program 读一遍 KV 喂 8 个 Q 头（GQA shared-KV），就把 KV 读取降到 1x。再切 64 tile 走 tensor core 消寄存器 spill，最终 batch≥32 追平 flash-attn。
- **前缀缓存**：hash 碰撞怎么办？→ xxhash 命中后再二次校验 `block.token_ids == 当前 token`，不一致视为未命中。
- **TP**：为什么 column 不通信、row 要 all_reduce？→ column 输入完整、输出局部（各卡结果互不依赖）；row 输入是上层的部分输出，算完是部分和，必须 all_reduce。
- **EP**：TP 和 EP 怎么解耦？→ TP 切「头/隐藏维」、EP 切「专家维」，正交；`utils/tp.py` 单独记 TP size/rank，非 MoE 层 replicated、MoE 层用 dist world_size 做 all-to-all。
- **FP8**：per-token scale 是什么？→ 每个 token 一个 `scale = max(|x|)`，`x_fp8 = x/scale`；scale 开销 4/1024≈0.4% 可忽略。
- **CUDA Graph**：为什么只 decode 用？→ decode 形状固定（batch 分桶）、kernel 多、launch 开销占比大；prefill 序列长度变化大，不好录制。
- **采样**：top_k 为什么 O(vocab)？→ 二分找第 k 大阈值（14 次迭代）不排序；Gumbel-max 用 `argmax(logit + Gumbel)` 等价 softmax 采样，免显式 softmax。

---

### 3.12 Sequence 的一生：状态机 + KV 块引用计数

一个请求从提交到完成，`Sequence` 对象（`engine/sequence.py`）经历了什么？这是把调度器、块管理器串起来看「状态」的钥匙。

**状态机**（`SequenceStatus`）：

```
WAITING ──(prefill 分配块、算完 prompt)──► RUNNING ──(生成 EOS 或达 max_tokens)──► FINISHED
   ▲                                          │
   └──────────────(显存不足被抢占)──────────────┘
```

- **WAITING**：刚提交（`add_request`），或被抢占后回到等待队列。
- **RUNNING**：prefill 完成，正在逐 token decode。
- **FINISHED**：生成 EOS 或达到 `max_tokens`，释放 KV 块。

**关键字段**（`Sequence.__init__`）：

| 字段 | 含义 |
|---|---|
| `token_ids` | 完整序列（prompt + 已生成的 completion） |
| `num_prompt_tokens` | prompt 长度（不变，用于区分 prefill 和 decode 的边界） |
| `num_tokens` | 当前总长度（随 `append_token` 增长） |
| `num_cached_tokens` | 已写入 KV cache 的 token 数 |
| `num_scheduled_tokens` | 本轮调度要处理的 token 数 |
| `block_table` | 逻辑块 → 物理块 id 的映射列表 |

**生命周期**（对照 §5 的调用链）：

1. `add_request`：`Sequence(prompt, sp)` 创建，状态 WAITING，进 scheduler 的 waiting 队列。
2. prefill 阶段：`block_manager.allocate` 分配物理块、填 `block_table`、算 `num_cached_tokens`；prompt 全部算完 → RUNNING。
3. decode 阶段：每轮 `append_token` 一个 token，`num_tokens += 1`、`num_cached_tokens += 1`；跨块边界时 `may_append` 再分配新块。
4. 结束：EOS 或达 `max_tokens` → FINISHED，`deallocate` 释放块、`block_table` 清空。

**KV 块的引用计数（前缀缓存共享安全的关键）**：

`BlockManager` 里每个物理块有 `ref_count`。多个序列**共享同一个前缀块**时，该块的 `ref_count > 1`（`allocate` 命中缓存块时 `ref_count += 1`）。`deallocate` 时 `ref_count -= 1`，**只有降到 0 才真正放回空闲池**。这就是前缀缓存为什么安全——只要还有序列引用这块，它就不会被释放覆盖。

---

### 3.13 手写 paged decode attention：从 8.84x 追到 1.05x

§3.5 讲的是「块怎么分配、怎么索引」。这一节讲「decode 的 attention kernel 怎么手写、怎么调快」——这是项目里最能体现「算子级理解」的一段。

**为什么手写**：decode 阶段每个序列只有 1 个 Q token，对分页 KV 做 attention。社区方案是调 `flash_attn_with_kvcache`，但项目想做到与 flash-attn 解耦（尤其 FP8 KV 时 flash-attn 2.x 不支持，得先 `gather_dequant` 反量化、多一次显存拷贝）。于是手写 Triton 内核 `layers/paged_attention.py` 的 `paged_attention_decode`，接进 `attention.py` 的 bf16 decode 路径。

**decode attention 的本质是 GEMV，不是 GEMM**：每个序列只有 1 个 Q token，`q` 是 `[head_dim]` 向量，`score = q · K^T` 是「矩阵乘向量」。这决定了后面所有优化的方向。

**v1：正确性优先，慢在 GQA 和寄存器 spill**。第一版 grid 是 `(num_seqs, num_heads)`——每个 (序列, Q头) 一个 program。两个问题：

- 对 GQA（Qwen3-32B 是 64 Q 头 / 8 KV 头，8 个 Q 头共享 1 组 KV），这 8 个 Q 头**各自读一遍同一 KV**，KV 带宽被放大 8 倍。decode 是 memory-bound，带宽就是命。
- 用整页 `block_size=256` 做单 tile，把 `[256, head_dim]` 的 score/p·V 中间量撑爆寄存器（spill）。

结果 v1 在 batch=256 时比 flash-attn 慢 **8.84x**。

**v2：两处对症优化**：

1. **GQA shared-KV**：grid 改成 `(num_seqs, num_kv_heads)`，一个 program 只读一遍 KV，喂给共享它的 8 个 Q 头。KV 读取量降 8x。
2. **小 tile + tensor core**：切成 `BLOCK_N=64`，Q 补零到 `QBLOCK=16` 行走 `tl.dot`（tensor core），score 和 p·V 都吃 MMA，不再 spill。

结果（32B GQA 配置，ratio = 自研/flash，越小越好）：

| case | v1 | v2 |
|---|---|---|
| batch 256 / ctx 4096 | 8.84x | **1.05x** |
| batch 128 / ctx 1024 | 4.87x | **1.12x** |
| batch 32 / ctx 4096 | 3.42x | **0.85x**（反超）|

**诚实记录一个 negative result——split-K**：小 batch 长 context 时只有 `num_kv_heads=8` 个 program，108 SM 吃不满，本想用 split-K（把序列按 token 切成多段并行，最后 reduce 重归一化）。但 decode 是 memory-bound，切段**不减 KV 读取量**，partial 缓冲区写入 + reduce kernel 启动的开销把并行度收益抵消了——只在 batch=8/ctx=4096 一个格子有收益，却让 batch=8/ctx=1024 从 1.40x 退化到 2.58x。所以回退，留注释记录（`paged_attention.py` 的 module docstring）。

**剩余差距的诚实解释**：batch ≥ 32（真实连续批处理区间）已追平（0.85–1.12x）。剩下 batch=1 长 context 约 3–6x，是因为只有 8 个 program 喂 108 SM，是**并行度问题**，不是算法问题。面试被问就答这句——比假装「已完全追平」可信得多。

**代码走读**（`layers/paged_attention.py`）：

- grid `(num_seqs, num_kv_heads)`：`seq = program_id(0)`、`kv_head = program_id(1)`。
- `q_head = kv_head * NUM_Q_PER_KV + qh_offs`，`q_valid = qh_offs < NUM_Q_PER_KV`：补零到 16 行的 Q，只保留共享这个 KV 头的那 8 个 Q 头（补零行不参与 softmax、不写回）。
- 内层循环按 `BLOCK_N=64` 切 token，`page_idx = tok_idx // block_size`、`tok_in_page = tok_idx % block_size` 做 paged 寻址，`block_id = block_table[seq, page_idx]` 拿物理块。
- online softmax：跨 tile 更新 running max `m_i` 和 running sum `l_i`，`p = exp(score - m_new)`，`acc = acc * alpha + p @ V`。

**为什么这是「理解」不是「调库」**：这里每一步都对应一个可讲的诊断——「GQA 让我重复读 KV 8 次」→ 改 grid；「256 tile 让寄存器 spill」→ 切 64 + tensor core；「split-K 不减带宽」→ 回退。面试官要看的不是「你用了 Triton」，而是「你**知道慢在哪**、改了之后**为什么快**」。

**复现**：正确性跑 `pytest tests/test_paged_attention.py -q`（与 flash-attn 对齐，覆盖 GQA 2 头和 8 头两种配置）；性能跑 `python benchmarks/bench_paged_attention.py`（32B GQA 配置扫 batch × ctx）。

---

## 4. 代码结构导航：每个文件一句话

```
zjhvllm/
  llm.py                    # LLM 入口（就是 LLMEngine，只是个别名）
  config.py                 # 所有配置（TP/EP/block_size/fp8/...）
  sampling_params.py        # 采样参数（temperature/top_k/top_p/...）

  engine/                   # 调度与执行（引擎核心）
    scheduler.py            # 大脑：prefill/decode 调度、抢占、postprocess
    block_manager.py        # 分页 KV + 前缀缓存（哈希复用）
    model_runner.py         # 模型执行：KV 分配、TP/EP、CUDA Graph、slot_mapping
    llm_engine.py           # 同步引擎：add_request/step/generate 主循环
    async_llm_engine.py     # 异步引擎：后台 step 线程 + 流式队列
    sequence.py             # Sequence：一个请求的状态（token/块表/时间戳）

  layers/                   # 模型算子
    attention.py            # attention + KV cache 读写 + FP8 量化
    paged_attention.py      # 自研 Triton decode paged attention（GQA shared-KV + tensor core）
    linear.py               # TP 并行线性层（Column/Row/QKV/Merged）
    moe.py                  # 单卡 MoE + EP all-to-all 路由
    ep_moe.py               # EP MoE（合成权重，测试用）
    sampler.py              # Triton 采样内核
    rotary_embedding.py     # RoPE 位置编码
    embed_head.py           # 词嵌入 + LM head（TP 版本）
    layernorm.py            # RMSNorm
    activation.py           # SiluAndMul（SwiGLU）

  models/                   # 模型结构
    qwen3.py                # Qwen3 dense 模型
    qwen3_moe.py            # Qwen3 MoE 模型（复用 qwen3 的 attention，换 MoE）
    registry.py             # model_type → 模型类 的注册表

  utils/
    loader.py               # 权重加载（含 EP 专家过滤/重映射）
    tp.py                   # TP 全局 size/rank（与 dist 解耦）
    context.py              # 每步前向的上下文（is_prefill/block_table/slot_mapping）

tests/                      # 23 项正确性测试
server.py                   # OpenAI 兼容服务
bench.py / example.py       # 压测 / 示例
benchmarks/                 # 与 vLLM 对比：吞吐 + 延迟 + 真实负载 trace + 并发扫描（workload.py 共享 workload）
```

**最关键的两个文件**：`engine/scheduler.py`（想懂「引擎怎么调度」）和 `engine/model_runner.py`（想懂「模型怎么执行、KV 怎么分配」）。先把这两个读透，其他都是配角。

---

## 5. 完整调用链：从 generate() 到 GPU kernel

trace 一次 `llm.generate()` 到底发生了什么（这是把前面所有机制串起来的钥匙）：

```
LLM.generate(prompts, sampling_params)                 # llm.py → llm_engine.py
  ├─ for each prompt: add_request()                     # 编码 → Sequence → scheduler.add
  │     seq.arrival_time = now                          # 延迟统计用
  └─ while not is_finished():
        step()                                          # llm_engine.py
          ├─ scheduler.schedule()                       # 决定 prefill/decode、挑 seqs
          │     ├─ _schedule_prefills() 或 _schedule_decodes()
          │     └─ block_manager 分配/释放块
          ├─ model_runner.call("run", seqs, is_prefill) # 传给 rank0，再 shm 广播给子进程
          │     ├─ prepare_prefill/decode()              # 算 input_ids/positions/slot_mapping/block_table
          │     ├─ run_model()                           # 走 CUDA graph 或 eager
          │     │     └─ model(input_ids, positions)     # qwen3.py 前向
          │     │           ├─ embed_tokens             # embed_head.py
          │     │           ├─ N× DecoderLayer          # qwen3.py
          │     │           │    ├─ Qwen3Attention      # qkv_proj→RoPE→attn→o_proj
          │     │           │    │    └─ Attention      # attention.py: 读/写 KV cache
          │     │           │    └─ MLP 或 MoE          # linear.py / moe.py
          │     │           └─ norm → lm_head           # embed_head.py
          │     └─ sampler(logits, ...)                 # sampler.py 3 个内核
          ├─ torch.cuda.synchronize()                   # 等 GPU 完成（延迟时间戳准确）
          ├─ scheduler.postprocess()                    # 挂 token、判结束、更新哈希
          │     seq.token_times.append(now)             # ITL 统计
          └─ 返回 (outputs, num_tokens, stream)
```

---

## 6. 怎么读懂 + 调试：从哪入手

1. **先跑通最小路径**：`example.py`（0.6B，`enforce_eager=True` 关掉 CUDA Graph，单卡关掉 TP），它只有「加载 → 生成」两步。在 `llm_engine.py` 的 `step()` 里加 print，看每一轮 schedule 了谁、prefill 还是 decode。

2. **理解一个序列的一生**：在 `sequence.py` 和 `scheduler.py` 里跟踪一个 `Sequence` 从 `WAITING → RUNNING → FINISHED`，看它的 `block_table` 怎么增长、`num_cached_tokens` 怎么变。

3. **理解 KV cache**：在 `attention.py` 的 `forward` 里打印 `context.is_prefill`、`context.slot_mapping`、`k_cache.shape`，对比 prefill 和 decode 时的差异。

4. **理解并行**：单卡先跑通，再开 `tensor_parallel_size=2`，在 `linear.py` 的 `RowParallelLinear.forward` 里看 `all_reduce` 何时触发。

5. **验证你的理解**：改一个小东西，看测试会不会挂。`tests/test_logits.py` 对比 HuggingFace 的 logits，`tests/test_generate.py` 测贪心/批处理/前缀缓存，`tests/test_moe.py`、`tests/test_ep_moe.py` 测 MoE/EP——这些测试本身是最好的「规格说明书」。

6. **带着问题读**：每个机制都问自己——「如果没有它，会发生什么？」（没有 KV cache → O(n³) 重算；没有 continuous batching → GPU 空转；没有 paged attention → 显存碎片；没有 TP → 单卡装不下；没有 EP → 8 卡用不了 MoE）。

---

## 7. 面试时怎么讲这个项目

一句话定位：**通过从零实现掌握推理引擎底层，而非黑盒调用 API**。

**开场三句话**（讲清「做了什么 + 有多难 + 结果如何」）：

1. **EP 专家并行**：解耦了 TP/EP 两个正交的并行维度（这是最难、最有含金量的部分，见 3.7）。
2. **手写 paged decode attention**：GQA shared-KV + tensor core，把自研 kernel 从 8.84x 追到 1.05x（见 3.13）。
3. **手写 Triton 采样**：top_k 二分阈值 + Gumbel-max + Philox 可复现，O(vocab) 免排序（见 3.10）。

（FP8 KV cache 与 23 项正确性测试也是强点，放在被追问时展开。）

**量化指标速查**（被问「跑出来效果怎么样」时，脱口而出的数字）：

| 指标 | 数字 | 约束（一定要主动带出来） |
|---|---|---|
| 吞吐 vs vLLM | 87–98% | Qwen3-32B，4×A100 TP=4，随 workload |
| 前缀缓存收益 | +53% 吞吐 / TTFT p99 -71% | 等长共享前缀 vs 无缓存（abl） |
| paged attention | 8.84x → 1.05x | 自研 kernel vs flash-attn，GQA shared-KV + tensor core，batch≥32 |
| 真实负载尾延迟 | TTFT p99 281ms（32B）/ 39ms（0.6B） | 真实 Poisson 负载，2000 样本 |
| KV 显存 | 533 → 1062 blocks | FP8 e4m3 + per-token scale |

> 关键：**数字必须带场景约束**（硬件 / 负载 / 到达模式）。裸说「吞吐 98%」会被追问「什么负载测的」，主动带出「4×A100 TP=4、固定随机负载」反而显专业。完整数字与 tradeoff 见 [RESUME_PREP.md](RESUME_PREP.md)。

**怎么主动引导到亮点**（被问「讲讲这个项目」时）：

1. 先一句话定位 + 三个亮点（EP / Triton 采样 / 正确性）。
2. 等面试官挑一个追问，重点展开那个（通常是 EP，因为最难）。
3. 主动带 tradeoff（「EP 的 all-to-all 通信开销还没量化」「FP8 只测了 logits 对齐没测 PPL」），显严谨。
4. 结尾落到量化结果（前缀缓存 +53%、真实负载 p99 281ms），收在「可衡量的成果」上。

**最容易加分的三个深挖点**（面试官往下问就答这三处）：

- EP 的 `% L` / `// L` 分解 + input/output split（见 3.7）
- paged attention 的 GQA shared-KV 诊断 + split-K negative result（见 3.13）
- 前缀缓存的**哈希链** + **ref_count 引用计数**（见 3.5 + 3.12）

更完整的面试准备（tradeoff 表、逐条高频问答）见 [RESUME_PREP.md](RESUME_PREP.md)。

## Qwen3.5 prefill 实测：warp 配置与寄存器溢出

Qwen3.5 的 48 个 Gated DeltaNet 层使用固定的 S 与卷积状态。prefill 先在 chunk 内并行求解，再按顺序传递 chunk 间状态；Triton 把后半段合并为一个扫描 kernel。
但“融合成一个 kernel”不自动等于快：这次 nsys 发现原扫描仍占 85.4% 的 GPU kernel 时间。按 Dv=16 切块、保持 IEEE FP32，仅把每 program 的 warp 数从 4 调到 8，就显著减少了编译器报告的 spill。

原因是 warp 数会改变每个线程分担的数据和编译器的寄存器布局。局部状态、矩阵乘法片段和中间值同时存活时，寄存器不足会产生额外访存。更多 warp 也可能降低并发，因此需要实测；本例不是“warp 越多越好”的通用规则。

在 A100 80GB、Qwen3.5-27B、单请求 1024 prompt tokens→1 completion token、eager 模式下，同一加载模型的 3 次计时中位数从 0.917s 降到 0.437s（约 2.10×）。计时含调度、状态 reset、prefill、采样及校验用的 logits CPU 拷贝；优化前后完整 logits 精确一致。

另一个更激进的 tf32x3 实验虽然算子误差很小，却改变了整模型首 token，因此未作为默认路径。这个例子说明：算子单测、状态续算测试和真实模型回归必须一起做，不能只报一个 kernel 加速数字。

完整数据、nsys 命令、失败实验与适用边界见 [PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md)。既有 HF raw logits 差异见 [ALIGNMENT.md](ALIGNMENT.md)；当前还不支持 Qwen3.5 TP、CUDA Graph、MTP 或视觉输入。

## 用八卡验证容量，而不混淆模型并行与副本扩展

本轮只做独立单卡副本实验：每张 A100 运行一份 Qwen3.5-27B，没有把一个模型切到八卡。每副本固定 8 个在途请求，结束一条补一条，1/2/4/8 副本分别完成 128/256/512/1024 条请求；这是容量的弱扩展，不是单请求八卡加速。

固定 128 输入 / 64 输出的合成文本中，聚合吞吐为 82.7 / 163.9 / 324.0 / 649.6 output tok/s，八卡容量约为单卡 7.85×。计算时使用所有副本的共同起点和最后完成时刻；不能直接相加局部吞吐，否则快副本提前结束会使总量显得过高。

八副本总并发 64 时，1024 请求的 TTFT/TPOT p99 为 1.10s/95.7ms；提高总并发到 128 后，吞吐达到 1157.5 output tok/s，但 TTFT/TPOT p99 变成 2.17s/102.8ms，ITL p99 约 879ms。后者揭示：已有 decode 会被新请求的 prefill 打断，较好的平均 TPOT 也可能掩盖个别 token 的长停顿。

本实验预设 SLO 是 TTFT≤2s 且 TPOT≤100ms，总并发 64 与 128 的达标率分别是 100% 和 93.75%。SLO goodput 统计真正同时满足两项门槛的请求，而不只看总 tok/s；它不是生产服务保证。

聚合 Poisson 8 req/s、轮询分发的 1024 请求实验，TTFT p99 为 216ms，TPOT p99 约 102ms，SLO 达标率 93.46%。TTFT 使用计划到达时间，实际延迟提交的 p99 约 84ms 也算入延迟。该负载到达速率限制了吞吐，不能称为吞吐峰值；也不能把这组较低 TTFT 与闭环高并发的 1157.5 tok/s 拼成一组指标。

全部 6 个主实验场景合计 3968 请求、253952 个生成 token。每个八副本场景均有 1024 请求，较小副本档位的 p99 只作 exploratory；只有单次实验，未估计重复试验置信区间。没有 HTTP、网络或真实生产 trace，不应包装成线上 SLA。

原始数据、实现快照、环境与复现命令见 [八卡实验报告](benchmarks/service_8gpu/REPORT.md)。


## 调度路径优化：CPU 元数据缓存（2026-11-01）

默认复用 CPU 侧序列边界/状态槽，消除 48 层 Gated DeltaNet 对 GPU 标量的重复读取；原 alternating 调度与模型算术不变。4 副本、每卡并发 16、同一 1024 请求闭环复测，吞吐 573.7→602.1 output tok/s，ITL p99 879→688ms，预设 2s TTFT/100ms TPOT 门槛的 SLO goodput 7.284→9.408 req/s。nsys 单个 8 请求 prefill 的流同步 1154→2 次；27B 完整 logits 最大差异 0，1024/1024 输出 hash 一致。

这是单次固定长度合成负载，门槛附近的小变化会放大 goodput 的增益，不应宣称生产 SLA。bounded 预算策略虽降低 ITL，但闭环 goodput 明显下降，仅保留显式选项；混合执行因数值验收失败已撤回并归档。用户明确不需要 TP=8，勿扩展模型并行。复现和完整限制见 [SCHEDULING_OPTIMIZATION.md](SCHEDULING_OPTIMIZATION.md) 与 [实验报告](benchmarks/SCHEDULING_REPORT.md)。


## Qwen3.5 投机验证与混合状态事务（2026-11-06）

投机解码在混合注意力模型上需要回滚三类状态：full attention 的 KV 逻辑长度、Gated DeltaNet 的 FP32 递归矩阵 S、causal convolution 的历史。只截断 token 或 KV 页表会让下一轮使用错误的递归状态。

本轮增加按请求快照全部线性层状态的事务，以及私有 KV 页的验证窗口。K 个草稿用 K+1 个目标预测验证；拒绝时恢复状态并重放保留输入。每轮 N 个输出对应 N 个已计算输入，最后一个输出留作下一轮待计算 token，因此继续保持 `num_tokens = num_cached_tokens + 1`。异常退出同样恢复状态并清除推理上下文。

接口默认采用 `serial` 参考模式，复用普通 decode 的张量形状与内核，没有投机加速收益。显式 `batched_experimental` 才执行批量目标前向；当前自然文本仍有严格 token 分歧，不能称为通用无损投机解码。

用户随后明确使用 MTP：现已加载 checkpoint 全部 15 组 MTP 权重，额外约 4.25 亿参数，共享主模型 embedding 和 LM head。`LLM(..., enable_mtp=True, max_num_seqs=1)` 后 `generate_speculative()` 默认使用 MTP-1。MTP 在位置 t 接收归一化的 token[t+1] embedding 与主模型最终 norm 后 hidden[t]，经 embedding-first 拼接、fc、一个 full-attention 层与最终 norm，预测后续 token。独立草稿 KV 仅扩展已提交配对；目标拒绝不会把无效 target 后缀写入草稿历史。prompt lookup 仅保留为显式对照。

最终相关回归 71 项通过；27B 真实 MTP 的三种输入生成 32 token，串行对照全部一致，草稿接受分别为 13/17、15/15、15/15；批量实验 2/3 一致，自然文本在第 8 个 token 分歧。MTP 写入私有 KV 后的故障恢复通过。前阶段可控草稿的 12 组串行对照、3 组真实故障恢复及批量 2/12 失败记录继续保留。实现、复现和后续定位顺序见 [SPECULATIVE_DECODING.md](SPECULATIVE_DECODING.md)。

## 混合负载基线与实验性自适应调度（2026-11-01）

后续 Qwen3.5 MTP 八卡扩大对照见 [MTP_SCALE.md](MTP_SCALE.md)：128 个不同输入×两轮×三模式，共 768 次生成、72,834 输出 token。MTP 串行参考 256/256 一致，批量实验 184/256 一致；所有资源回收且换卡后输出逐 token 复现。批量原始吞吐 115.74 vs 基线 88.21 output tok/s，因 72 条输出分歧未通过数值验收。每卡活跃并发1、总并发8，不是高并发 MTP 或 TP8 测试。

旧Qwen3-0.6B批次一致性失败已定位：prefill相同，首次decode首层QKV GEMM输入相同、输出差0.001953125；第8个生成位置因单条路径候选同分而分叉。原严格断言保留，新增固定batch形状的请求重排隔离测试通过。不是把所有Qwen3.5误差都归因于近邻tie。

完成8×A100、两组四副本、交换GPU的两轮混合输入/输出长度与Poisson/突发对照，共3072请求、219264生成token。自适应策略根据执行耗时拟合与decode余量选择预算，并以TTFT保护推进队首请求；保持默认alternating。饱和闭环goodput约+39.7%，但吞吐−4.7%、SLO达标率仅16.6%；突发goodput−3.7%、TTFT p99约0.85s→1.81s，Poisson基本持平。

重要：跨策略1536对输出中400对不同；抽样16处HF共享历史审计有7处candidate相对baseline regret高出1以上，数值验收未通过，不能把性能数据写成已验收成果。adaptive是显式实验选项，不默认启用；不要放宽阈值或把所有分歧解释成BF16近邻tie。下一步应先根据HF自身参考路径对照定位长序列/缓存数值差异，再决定是否继续策略优化。详情见 [ADAPTIVE_SCHEDULING.md](ADAPTIVE_SCHEDULING.md) 与 [交叉实验报告](benchmarks/adaptive_holdout/REPORT.md)。

最终回归44 passed、1 failed；保留的失败为上述严格跨batch测试，日志/JUnit及源码快照校验均归档。没有扩展TP/EP，没有默认mixed执行，也没有用这些未验收数据改简历。


补充HF自身参考路径对照：上述16处真实共享历史中，HF的batch1完整、batch2完整与batch1缓存增量前向有11处top1不一致，最大logits差异分别达17.25/19.73；但仍有3处candidate在所有参考下相对baseline regret高出1以上。参考敏感性不能豁免剩余误差，adaptive仍未通过数值验收。证据见benchmarks/adaptive_holdout/hf_self_reference_audit.json。
