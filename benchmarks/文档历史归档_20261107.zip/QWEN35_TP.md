# Qwen3.5-27B 多卡普通推理与吞吐口径

本轮实现真正的张量并行（TP），一个模型由2/4/8张GPU共同执行；不再只是多个单卡副本。新增混合模型原生decode CUDA Graph。后续已接入多卡 MTP-1（TP1/2/4/8），使用与独立验收见 [MTP_TP.md](MTP_TP.md)；本文件的容量数据仍是普通推理。

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 python your_script.py
```

```python
from zjhvllm import LLM, SamplingParams

llm = LLM('/home/data/jhzhou/huggingface/Qwen3.5-27B',
          tensor_parallel_size=4, max_num_seqs=128,
          max_model_len=2048, max_num_batched_tokens=2048,
          enforce_eager=False, gpu_memory_utilization=.85,
          distributed_port=2420)
try:
    outputs = llm.generate(prompts, SamplingParams(greedy=True, max_tokens=128))
finally:
    llm.exit()
```

TP支持1/2/4/8、EP=1、文本输入。`CUDA_VISIBLE_DEVICES`中必须有足够空闲GPU。实际可同时运行的请求还受状态槽、KV页与显存限制，`max_num_seqs`不是保证全部同时活跃的承诺。

## 切分方式

- MLP gate/up做列切分、down做行切分与all-reduce。
- Full attention按完整query/gate头切分，输出做行切分与all-reduce；KV头数不足TP时复制相应KV头。27B有4个KV头，TP8每两rank共享同一个全局KV头。
- GDN按key/value头切分。QKV和conv分别对原Q/K/V三个片段切分后拼成各rank的局部布局，Z/B/A及A_log/dt_bias同步切分；递归S/conv只保留局部头，输出投影后all-reduce。
- Embedding、LM head和必要norm暂时复制。这是有效TP实现，但还不是所有参数都切分的最省显存方案。
- 各rank取共同可用的最小状态槽数和KV页数，避免rank0调度出的槽在其他rank越界。进程共享内存名称带独立端口，允许不同TP组同时运行。

Checkpoint参数名保持原样，loader通过参数自带的分片规则加载；未转换/重写原始权重文件。BF16 TP归约与TP1的浮点顺序不同，不能保证任意请求跨TP数输出逐位相同，也未宣称新的HF严格logits验收通过。

## 原生混合decode Graph

当 `enforce_eager=False`、Qwen3.5、普通推理、非FP8 KV时启用。对实际batch大小捕获，不能给混合递归状态随意padding：重复状态槽会发生写入竞争。未捕获的batch大小回退eager，最大捕获batch128。

Graph在请求入队前捕获，使用独立合法状态槽、跳过临时KV写入，并在捕获后清空warmup S/conv。运行时更新input/position/物理KV slot/page table/有效长度和真实状态槽。各rank同时捕获NCCL all-reduce，输出仍由rank0采样。MTP目标验证Graph是独立功能，后续已扩展多卡多请求和连续补位，见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)，不能混作本路径。

## 正确性与发现的缺陷

相关CUDA测试 **144 passed、0 skipped**，见 `benchmarks/qwen35_tp_20261107/regression_production.log`。新增覆盖TP2/4/8权重切分、KV复制、原生Graph的动态槽/255–257页边界、未捕获batch回退及超过2^31元素的状态地址。

TP2/4/8真实多进程FP32小混合模型，与未分片参考比较4步、两请求及递归状态，各配置logits最大绝对差均不超过3.58e-7。它验证分片与通信，不替代27B的HF/模型质量验收。

最初C128试跑发现TP2状态池超过有符号32位元素索引范围，造成错误写入及非有限logits。已在读取/输出slot乘stride前转int64，并以约9GB地址跨度回归。原试跑日志与无效声明见 `PILOT_INVALIDATION.md`；不得引用其中C128吞吐为有效结果。原生Graph单测另发现假runner的target_hidden未发布，也已修复且保留原失败日志。

正式benchmark每一步检查logits全为有限值，先做同引擎Graph/eager严格输出对照，再计时。源码、完整输出、资源回收、rank局部参数/状态/KV形状均随记录保存。

## 为什么先前只有几十token/s

之前主要是每卡一个活跃请求（C1）的生成速度，或者八个独立TP1副本的合计，既不是TP8，也不是高并发系统容量。

例如128个请求各20 token/s，合计才是2560 token/s；这是说明指标关系的算例，不是实测值。单个请求的自回归生成速度与服务所有请求的总输出吞吐应分开报告。输入prefill吞吐也不能加入分子，冒充生成token吞吐。

本轮报告两种口径：

- **端到端输出吞吐**：所有实际输出token / 从入队到全部完成的wall time，包含prefill、排队和解码。
- **完整batch解码窗口吞吐**：所有请求均已prefill、均未结束时，输出token / 对应decode步骤总耗时。窗口之外的prefill和队列不在此分母；不等于端到端吞吐或HTTP SLA。

固定128输入/128输出、greedy、ignore EOS的容量负载，复用归档输入并补齐/截断到相同长度；不是开放域质量评测。计时排除模型加载、JIT和Graph捕获，有限值检查开销包含在内。每配置两轮，第二轮反转并发顺序，同配置重复输出逐token比较。连续批处理仍可使实际活跃batch小于入队数，报告中保留实际最大/平均decode batch，不能把未达到的C128算为完整batch128。

正式[报告](benchmarks/qwen35_tp_20261107/REPORT.md)、[汇总](benchmarks/qwen35_tp_20261107/summary.json)：24个测量阶段、1288次生成、164864个输出token；资源全部回收，各配置两轮输出完全相同。四个TP配置各161个Graph/eager配对请求全部一致，每一步logits有限。

| TP | C1解码 tok/s | C128完整batch解码 tok/s | C128端到端output tok/s | 每rank参数GiB |
|---:|---:|---:|---:|---:|
| 1 | 22.95 | 未达到128活跃 | 437.76 | 50.10 |
| 2 | 31.54 | 1778.73 | 784.18 | 27.42 |
| 4 | 38.82 | 2650.69 | 907.26 | 16.08 |
| 8 | 40.98 | 3207.78 | 959.32 | 10.45 |

TP1当前分配49个状态槽，128请求会排队，不能把最大batch49的数据称为C128满载窗口。TP2/4/8均实际达到128同时活跃。所有吞吐仅计输出token；表中C1列与C128列是不同并发下的指标，不代表每个请求都能产生几千token/s。

TP1/2/4使用互不重叠GPU组并行测量，TP8随后单独测量；这不是隔离其他负载的严格强扩展效率实验。结果仍受共享CPU/系统环境影响。prefill仍逐序列处理、采样和调度在Graph外、Embedding/LM head复制，当前端到端未达到几千tok/s，不能用解码窗口数字冒充。正式源码快照保存后只更新了两处过时说明文字，执行代码不变。

真实27B对TP1的完整生成比较：C1和C32，TP2/4/8各66/66一致；C128则分别134/256、136/256、132/256一致。后者TP1只分配49个槽，prefill/decode batch形状与多卡不同，混合了浮点归约和调度形状差异，不能直接当同历史logits误差。全部差异已保存，不将这组容量测试包装为任意TP/任意batch的位级一致性保证。

全部实验结束时八卡均仅占4 MiB，无计算进程。

复现：

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3 python -m benchmarks.bench_qwen35_tp \
  --tp 4 --concurrency 1 32 128 --input-tokens 128 --output-tokens 128 \
  --repeats 2 --check-eager --port 2420 --output benchmarks/qwen35_tp_new
```
