# Qwen3.5 MTP-1 八卡扩大对照

**以下保留修复前实验。** 最新正式修复已在相同精确 token 输入、两轮三模式下通过：批量输出 256/256 一致、全部 768 次资源回收正常。修复后吞吐 76.69 vs 基线 87.58 output tok/s，没有加速收益。见 [修复说明](MTP_NUMERICAL_FIX.md) 和 [最新报告](benchmarks/qwen35_mtp_fixed_8gpu_20261106/REPORT.md)。

本轮将单卡三个样例扩大到 8×A100-SXM4-80GB、128 个不同输入、两轮三模式配对。
原始目录：[qwen35_mtp_8gpu_20261106](benchmarks/qwen35_mtp_8gpu_20261106/)。
完成状态以 [status.json](benchmarks/qwen35_mtp_8gpu_20261106/status.json) 为准，统计见 [summary.json](benchmarks/qwen35_mtp_8gpu_20261106/summary.json)。

## 已完成结果

768 次生成全部结束，合计 **72,834 输出 token**，768/768 次资源回收通过，结束后核查八卡均仅占 4 MiB、无计算进程。
完整表格与各类分歧见 [REPORT.md](benchmarks/qwen35_mtp_8gpu_20261106/REPORT.md)。

| 模式 | 严格 token 一致 | 八卡 output tok/s | TTFT p99 | 请求平均 TPOT p99 | E2E p99 | MTP 接受率 |
|---|---:|---:|---:|---:|---:|---:|
| 普通 decode | 两轮间 128/128 一致 | 88.21 | 1477.40 ms | 90.35 ms | 12.221 s | — |
| MTP 串行参考 | 256/256 | 87.85 | 1473.31 ms | 91.41 ms | 12.384 s | 88.90% |
| MTP 批量实验 | 184/256 | 115.74 | 1473.98 ms | 74.52 ms | 9.941 s | 89.21% |

批量实验的 72 个分歧为自然语言 30/68、数学 6/60、代码 10/64、长上下文 26/64。
每条输入第二轮均轮换 GPU，三种模式各自的两轮输出全部一致，分歧稳定复现。
批量原始吞吐比基线高约 31.2%，但严格输出失败率为 28.1%，**不能验收为有效加速**。
串行参考目标前向 24,588 次，与普通 decode 相同；它验证 MTP 和状态推进，不作为加速实现。

结论：MTP 草稿接受率约 89%，状态回收与跨卡复现通过；当前优先级是批量目标验证的数值一致性，之后再扩展每卡多请求并发。
测量完成不等于数值验收通过，机器可读判定见 [validation.json](benchmarks/qwen35_mtp_8gpu_20261106/validation.json)。

## 范围与可解释性

- 8 个独立单卡 27B BF16 副本，TP=EP=1，eager，MTP-1；每卡一个活跃请求，总活跃并发 8。
- 模式：普通 decode、MTP 串行参考、MTP 批量实验。串行参考不节省目标前向，不能宣称投机加速。
- 三模式复用同一已加载引擎，基线也驻留 MTP 权重，避免重新加载和显存布局差异；普通 decode 不执行 MTP 草稿。
- 每个输入跑两轮、每轮三种模式，共 768 次测量生成；三种模式的少量预热另外执行，不计入样本数。
- 第二轮轮换物理 GPU 分配、反转 baseline/batched 顺序。各 GPU 在同一屏障时间启动，按预计成本平衡输入分片。
- 原生引擎 closed-loop，每个请求完成后才补下一个，没有 HTTP、网络或外部排队延迟。不是高并发 C128 测试，也不是 1→8 扩展效率测量。

## 输入

固定随机种子 20261106，128 个不同 token 序列，chat template 关闭 thinking；greedy，正常遵守 EOS，输出上限 64/128 各 64 条。
完整 token 输入、来源和长度固定在 [workload.json](benchmarks/qwen35_mtp_8gpu_20261106/workload.json)，SHA256 与源码快照在 manifest 中。

| 类型 | 不同输入数 | 实际输入长度 | 来源 |
|---|---:|---:|---|
| 自然语言 | 34 | 20–36 | 本地 RAG 项目的 QA 问题，仅输入问题，不输入参考答案 |
| 数学 | 30 | 53–818 | 本地 AIME-2025 问题去重，只提取题干，不输入答案或解答 |
| 代码 | 32 | 107–990 | 本地 Lumina 不同函数的上下文与待续写前缀 |
| 长上下文 | 32 | 282–2076 | 项目技术文档不同偏移的片段及总结问题 |

这是可复现的本地混合测试集，不代表开放域自然语言、完整数学能力或公共代码 benchmark 的任务准确率。
长上下文是技术文档片段，不将其标为独立公共数据集。测试只验证普通 decode 与候选路径的输出一致性，不评判问题回答是否正确。

## 验证与指标

保留每次生成的完整 token、TTFT、平均 TPOT、E2E、输出批次间隔、目标前向次数、MTP 接受数、拒绝重放数和资源回收结果。
同 `(repeat, request_id)` 做严格 token 对照，另比较两轮 baseline 的跨 GPU 一致性。失配候选的性能数据只作为诊断，不验收为有效加速。

吞吐 = 模式总输出 token / 两轮模式 wall time 之和；每轮 wall time 从统一启动屏障到最晚请求完成，包含尾部副本空转。
平均 TPOT = `(最后输出时间 - 首输出时间) / (输出数 - 1)`，TTFT 和 E2E 按原生请求提交时刻计。
一次投机迭代可能同时交付两个 token，记录的是输出批次间隔，不将同批 token 的零间隔当成 ITL 改善。
每模式 256 个请求，p99 只是本轮经验分位数，不代表生产 SLA；输入类别及 EOS 输出长度差异都会影响分位数。

运行前检查共享 GPU 占用。进程 PID/独立进程组保存到 `processes.json`；退出时仅清理本次创建的进程组，避免父进程退出留下 CUDA 子进程。

```bash
conda activate lumina
python -m pytest tests/test_mtp_replica_report.py -q
# 必须使用新的输出目录；八张 GPU 需空闲。
python -m benchmarks.bench_mtp_replicas \
  --gpus 0 1 2 3 4 5 6 7 --repeats 2 \
  --output benchmarks/qwen35_mtp_8gpu_new
```

MTP 权重、状态配对和已知单卡批量分歧见 [SPECULATIVE_DECODING.md](SPECULATIVE_DECODING.md)。
