# MTP 中间状态提交与每请求接受长度（2026-11-07）

后续已有单请求验证Graph优化及新的105项回归、完整归档验收，见 [MTP_VERIFICATION_GRAPH.md](MTP_VERIFICATION_GRAPH.md)。本文吞吐表描述此前eager阶段，不能作为显式开启Graph后的当前速度。

在 [数值修复](MTP_NUMERICAL_FIX.md) 的正确性参考上，按 [SGLang/vLLM 源码设计](MTP_BATCH_REFERENCE.md) 实现了两项功能：验证窗口保存各步 S/conv 并直接提交接受边界；多请求分别管理接受长度、草稿 KV 和 target hidden。

## 中间状态提交

`gated_delta_decode()` 新增可选的输出状态缓存与输出槽。默认仍原地更新；验证期间，第一步读取请求的已提交状态，后续步骤读取前一步暂存状态，计算后直接写入本步暂存槽，不额外复制整份 S 来推进下一步。递归公式、归约形状与精度设置保持不变。

`HybridStateHistory` 保存窗口中每个输入处理后的 S/conv，整个前向期间持久化递归状态不前移。接受判定、EOS 和预算裁剪完成后，提交 `commit_length-1` 对应的状态。当前 MTP-1 的拒绝情况直接选步0，全接受选步1；不再重跑目标模型。

前向异常不会发布暂存状态；提交中途异常则由原 `HybridCheckpoint` 恢复。KV 窗口仍使用私有页，无效后缀由逻辑长度隐藏、完整拒绝页回收。target hidden 只发布真实提交输入对应的行，correction/bonus 继续保持 pending。

配置：

- `verification_state_commit=True` 为默认；设为 False 可显式保留旧 restore/replay 参考路径。
- `verification_state_budget_mb=512` 是每个配置请求的暂存预算，总预算乘以 `max_num_seqs`。
- MTP-1 的暂存区在 KV 池分配前按状态槽数预留并重复使用。27B 每个状态边界约147 MiB，其中 S 约144 MiB；每请求两步暂存约294 MiB。异常恢复 checkpoint 还会占用约147 MiB/活跃请求，须保留 GPU 余量，默认实验使用 `.85` 利用率。
- 通用 prompt lookup 的大窗口超过暂存预算时，C1 保留原重放参考路径；多请求接口容量不足时撤销私有页并回退普通调度，不做无限制分配。

## 每请求独立验证

新增接口：

```python
llm = LLM(model_path, enable_mtp=True, max_num_seqs=4,
          max_model_len=4096, max_num_batched_tokens=256,
          enforce_eager=True, gpu_memory_utilization=.85)
try:
    outputs = llm.generate_speculative_batch(
        prompts, SamplingParams(greedy=True, max_tokens=128))
finally:
    llm.exit()
```

当前限定单卡 TP=EP=1、MTP-1、未修改的 greedy，`max_num_seqs` 须显式选1–8。新增 `speculative_step_batch(seq_ids, drafts)` 供已充分 prefill 的运行请求使用；`generate_speculative()` 和原单请求接口仍兼容。

- `MTPAttention` 为每状态槽维护独立 KV bank 和逻辑长度，槽复用/重算时清空该槽长度。草稿计算异常恢复当前请求长度，批量目标失败恢复本轮所有请求草稿长度。
- `target_hidden` 在多请求引擎中按槽保存；prefill、decode 与验证分别按实际序列边界写入。
- 每个 GPU 接受 program 对应一个请求，沿该请求草稿在首次拒绝处停止；输出和正确草稿数分别保存。不存在跨请求 min。不同长度窗口以 cu_seqlens 定位。
- 一次目标模型遍历中，GDN 与 full attention 使用各请求自己的槽、位置和有效前缀。每个请求独立选择暂存状态步，独立推进 token/KV 前沿。
- 私有页先全部预留再前向；其中一个请求预留失败时回收本批新增页。目标或提交失败恢复本批全部递归状态。
- 普通容量回退若触发抢占/重算，会重新进入普通调度，待状态恢复到单 pending token 前沿才继续投机。

为了保持数值参考，启用 MTP 的 B>1 引擎在普通 decode 时也沿用单 token 算子形状。**多请求的配对基线是同样启用 MTP、相同 cohort/prefill 调度和算子规则的普通生成**，不是另一个未启用 MTP、使用大 GEMM 的吞吐基线。Prefill 的批形状差异仍可能使 C1/C2 的普通生成输出不同；这不等于跨请求接受判断发生污染，也不宣称跨任意批形状逐元素一致。

同步 `generate_speculative_batch()` 按固定 cohort 处理：请求在批内独立结束，但不立即用新输入补满退出槽。常规 `generate()/step()` 的连续批处理继续保留；本接口不能被描述成已完成连续投机补位、TP 或 CUDA Graph。

## 测试与证据

本轮小集：`benchmarks/qwen35_mtp_state_commit_20261107/pilot_c{1,2,4}/`。真实本地27B、归档四类输入、输出上限32，C1/C2/C4各自模式与配对普通decode一致，优化路径重放为0，资源回收正常。它是试运行，不作为完整性能验收。

新增/扩展回归覆盖：GPU接受32个草稿与另一个请求0接受的混合情况、不同草稿长度、EOS/预算、BF16/FP8、非连续页/乱序槽、每请求 S/conv/target hidden、提交中途故障后全批回滚、页预留部分失败、全批 draft length 回滚、槽复用。测试文件为 `test_mtp_batch.py` 和 `test_verification_decode_equivalent.py`，另保留原 MTP/调度/算子测试。

最终相关回归 **97 passed、0 skipped**，实际运行 CUDA，完整日志：[regression_final.log](benchmarks/qwen35_mtp_state_commit_20261107/regression_final.log)。这是相关测试集，不是全仓测试。

完整归档回归目录：`benchmarks/qwen35_mtp_state_commit_8gpu_20261107/`，相同128输入×两轮×三模式。更大的 C2/C4 配对测试使用 `benchmarks/bench_mtp_state_commit.py`；该工具保存源码、固定输入、每请求输出、接受/重放统计和资源回收信息，并反转第二轮模式顺序。

这里实现的是中间状态提交和多请求独立前沿。投影/norm 仍保留数值修复中的逐 token 形状；尚未把它替换为高吞吐批量 GEMM，性能结论必须来自同配置实测。

## 最终验收

汇总：[summary.json](benchmarks/qwen35_mtp_state_commit_20261107/summary.json)。全部主要测试源码快照已与当前 runtime SHA256 核对。完成后八卡均仅占4 MiB，无计算进程。

### C1 完整归档集

[完整报告](benchmarks/qwen35_mtp_state_commit_8gpu_20261107/REPORT.md)、[验收](benchmarks/qwen35_mtp_state_commit_8gpu_20261107/validation.json)：精确复用128输入，两轮三模式、768次生成、72,834输出token；batch和serial各256/256与普通decode一致，全部768次回收资源，三模式各自换卡输出128/128复现。普通decode与最初归档也256/256一致。

| 模式 | 八卡 output tok/s | 目标前向（含prefill） | 重放token |
|---|---:|---:|---:|
| 普通decode | 87.41 | 24,588 | 0 |
| MTP serial | 85.84 | 24,588 | 0 |
| 中间状态提交 | 77.83 | 13,352 | 0 |

此前重放版本目标前向14,760次，当前减少1,408次。两份八卡报告来自不同轮次，不把吞吐差值当成严格A/B收益；同引擎A/B如下。

### 同引擎配对与多请求

C1：四个已知失败输入的完整64/128输出预算，两轮反转模式顺序，三模式共享已加载引擎、KV池和常驻暂存空间。C2/C4：各16输入（四类各4），按长短混合顺序形成固定cohort，两轮反转模式顺序。表中吞吐为各模式总输出除以两轮总耗时。

| 配置与模式 | 对同配置baseline逐token一致 | 单卡 output tok/s | 重放token |
|---|---:|---:|---:|
| C1 普通decode | 8/8（自身配对） | 10.972 | 0 |
| C1 旧重放 | 8/8 | 9.614 | 38 |
| C1 中间状态提交 | 8/8 | 9.908 | 0 |
| C2 普通decode | 32/32（自身配对） | 10.818 | 0 |
| C2 独立接受/提交 | 32/32 | 10.811 | 0 |
| C4 普通decode | 32/32（自身配对） | 11.728 | 0 |
| C4 独立接受/提交 | 32/32 | 11.610 | 0 |

原始证据：[C1](benchmarks/qwen35_mtp_state_commit_20261107/paired_c1/result.json)、[C2](benchmarks/qwen35_mtp_state_commit_20261107/paired_c2/result.json)、[C4](benchmarks/qwen35_mtp_state_commit_20261107/paired_c4/result.json)。每个模式的请求/槽/页均完整回收，两轮baseline自身也完全一致。

该C1小集相对旧重放吞吐增加 **3.06%**，仍低于普通decode。C2/C4与各自baseline基本持平或略低，没有明确的端到端加速。不同C使用不同输入规模/分组且baseline限定为MTP引擎的逐token算子，不能用此表推断1→4扩展效率，不能冒充与普通高吞吐批量GEMM引擎的公平竞争结果。

本轮只验证默认alternating调度、C1/C2/C4、同步固定cohort；没有验收C8、高并发服务、连续投机补位、跨任意prefill形状严格一致性或新的HF logits门槛。
