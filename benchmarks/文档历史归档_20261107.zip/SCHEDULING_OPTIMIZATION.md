# 调度执行路径优化（2026-11-01）

已默认启用 `cache_schedule_metadata=True`，保持原 alternating 调度及模型算术。`ModelRunner` 在准备 prefill 时保留已经位于 CPU 的序列边界和状态槽号；48 层 Gated DeltaNet 复用这些列表，避免逐层对 CUDA 标量调用 `int()` 引起同步。

4×A100 80GB、4 个 Qwen3.5-27B 单卡副本，每卡并发 16，1024 请求，128 输入/64 输出 token：

| 指标 | 原版本 | 仅 CPU 元数据缓存 |
|---|---:|---:|
| output tok/s | 573.7 | 602.1（+5.0%） |
| TTFT p99 | 1773.5ms | 1413.9ms |
| TPOT p99 | 101.8ms | 98.3ms |
| ITL p99 | 879.0ms | 687.7ms（−21.8%） |
| SLO goodput | 7.284 req/s | 9.408 req/s（+29.2%） |
| SLO 达标率 | 81.25% | 100% |

SLO 预设为 TTFT≤2s 且请求平均 TPOT≤100ms。以上为单次固定长度合成负载，100ms 门槛附近的小变化会放大 goodput 变化；不能当作生产 SLA 或所有负载下的增益。基线与元数据消融使用相同 GPU0–3、manifest 与 seed=17，分时运行。

正确性证据：1024/1024 请求输出 hash 一致；独立 27B 整模型对照完整 logits 最大差异为 0；单层输出、S 和 conv 状态逐位一致。nsys 同一 8 请求 prefill 的 `cudaStreamSynchronize` 为 1154→2 次，`cudaMemcpyAsync` 为 1550→398 次；两组保留相同的输出采集。

另实现显式 `scheduling_policy="bounded", active_prefill_tokens=512`，仅在已有 decode 请求时限制单轮 prefill token 数。主 A/B 中它将 ITL p99 降至 425ms，但闭环 goodput 降到 3.599 req/s，因此不默认启用。混合 prefill/decode 前向因未通过数值验收已撤出生产代码，失败记录保留。

## 复现

在 Lumina 目录和 lumina conda 环境中运行；下面两条依次执行，每条加载 4 份 27B 权重：

```bash
python -m benchmarks.bench_replica_service --gpus 0 1 2 3 --replicas 4 --policy alternating --disable-host-metadata --concurrencies 16 --requests-per-replica 256 --seed 17 --output-dir benchmarks/repro_scheduler_baseline
python -m benchmarks.bench_replica_service --gpus 0 1 2 3 --replicas 4 --policy alternating --concurrencies 16 --requests-per-replica 256 --seed 17 --output-dir benchmarks/repro_scheduler_metadata
```

完整场景、失败实验和限制见 [调度报告](benchmarks/SCHEDULING_REPORT.md)。原始数据及源快照在 `benchmarks/scheduling_ab_{baseline,bounded,metadata_only}/`；两组主实验源快照也存于 `benchmarks/scheduling_ab_source/`。分析程序为 `benchmarks/compare_scheduling.py`，profile 入口为 `benchmarks/profile_schedule_metadata.py`。


最终回归：调度专项 25 项通过；扩展包含 Qwen3 logits/生成共 36 passed、1 failed。失败为 `test_batch_equals_individual`，关闭 CPU 元数据缓存后同样复现且输出完全相同，说明旧路径已有该问题；根因尚未诊断。未修改测试断言，不能宣称完整测试全绿。记录见 `benchmarks/scheduling_verification.json`。
