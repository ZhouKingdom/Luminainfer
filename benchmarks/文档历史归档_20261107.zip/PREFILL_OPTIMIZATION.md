# Qwen3.5 prefill Triton 优化记录

日期：2026-11-01。环境：conda lumina、PyTorch 2.8.0+cu128、Triton 3.4.0、A100-SXM4-80GB。

## 采用的改动

保持 IEEE FP32 dot、chunk_size=64、value tile=16，只把 Triton chunk scan 默认 num_warps 从 4 改为 8。
不改 delta rule、状态精度或分块算法。保留 scan_warps=4 和 scan_backend="torch" 作为可复现基线。

## 定位依据

48 heads、Dk=Dv=128、L=1024 的 nsys CUDA/NVTX profile 显示，旧扫描 kernel 平均约 12.407ms，占被采集 kernel 总时间的 85.4%。
调参比较了 value tile=16/32/64、num_warps=4/8：tile=16、warps=8 最快，输出与最终状态和原 IEEE 配置逐元素一致。
编译器 CompiledKernel.n_spills 从旧配置的 1732 降到 112（这是编译器属性值，不是 nsys 硬件计数器，也不表示溢出完全消失）。

## 算子基准

真实结构维度：48 value heads，128×128 fp32 状态；初始状态非零，投影布局非连续。
每个长度比较输出、最终状态和非整 chunk 分段续算。计时排除 JIT、输入构造和状态 reset；每项预热 2 次，记录 7 次 CUDA event 中位数。
下表为整个 chunk 路径，包括预处理、三角求解、布局整理和 scan；不是只有扫描 kernel。

| tokens | 原 IEEE 4 warps | 新 IEEE 8 warps | 加速 |
|---:|---:|---:|---:|
| 33 | 1.756ms | 0.783ms | 2.24× |
| 65 | 2.167ms | 0.797ms | 2.72× |
| 256 | 3.379ms | 1.107ms | 3.05× |
| 1024 | 12.583ms | 3.326ms | 3.78× |
| 4096 | 49.314ms | 10.302ms | 4.79× |

不同路径在同一次基准中也测量了逐 token 与 torch chunk。短输入的预处理/launch 开销占比较高，并非所有长度都优于 torch chunk；以上均为特定形状与硬件数据，非通用性能保证。

## 整模型结果

Qwen3.5-27B，单卡单请求，**1024 prompt tokens → 1 completion token**，eager 模式，不分块调度（单轮处理全部 prompt）。同一加载模型中比较各路径，每种预热一次，再测 3 次；未计模型加载。
计时包含 scheduler、状态清零、prefill、sampling 和用于校验的最后一行 logits CPU 拷贝。

- 原 IEEE 4 warps：0.917478s 中位数。
- 新 IEEE 8 warps：0.437165s 中位数。
- **约 2.10×，耗时减少 52.4%**。
- 3 次运行中生成 token 一致，**优化前后完整 logits 最大差异为 0**。
- torch chunk：0.479801s；同样输出 token 632，但其 logits 不等同于原 IEEE 路径。

这只证明该单请求首 token 工作负载的收益，不代表 decode 吞吐、多并发或所有文本；本轮没有重新进行全套 HF 对齐，既有严格 raw logits 问题仍见 ALIGNMENT.md。

## 被拒绝的 tf32x3 实验

Tensor Core tf32x3 可令扫描 kernel 降到约 0.854ms，48-head 随机算例对逐 token reference 的最大输出误差约 1.4e-7、状态误差小于 1e-6。
但整模型 1024-token 回归中，原 IEEE 和 HF 输出 token 632，tf32x3 输出 2528；HF top1-top2 gap=3.25，不能按近邻 tie 放过。
因此 **未采用 tf32x3 作为默认精度**，只保留显式 scan_precision="tf32x3" 实验开关及失败数据。算子误差小不等同于整模型行为不变。

## 复现与证据

在 Lumina 目录、可访问 GPU 的会话执行：

```bash
conda activate lumina
python -m benchmarks.bench_delta_prefill --scan-warps 4 --output benchmarks/delta_prefill_baseline.json
python -m benchmarks.bench_delta_prefill --scan-warps 8 --output benchmarks/delta_prefill_ieee8.json
python -m benchmarks.tune_delta_scan
python -m benchmarks.bench_qwen35_prefill --output benchmarks/qwen35_prefill_ieee8.json
python -m pytest tests/test_gated_delta.py tests/test_scheduler_state.py -q
```

完整引擎 nsys 捕获（无需 root 或 ncu 权限）：

```bash
nsys profile --sample=none --cpuctxsw=none --trace=cuda,nvtx \
  --capture-range=cudaProfilerApi --capture-range-end=stop \
  --force-overwrite=true --output=benchmarks/profiles/qwen35_prefill_ieee8 \
  python -m benchmarks.bench_qwen35_prefill --profile --repeats 2 \
  --output benchmarks/qwen35_prefill_ieee8_profiled.json
nsys stats --report cuda_gpu_kern_sum,nvtx_gpu_proj_sum,cuda_api_sum \
  --format csv --output benchmarks/profiles/qwen35_prefill_ieee8 \
  --force-overwrite=true benchmarks/profiles/qwen35_prefill_ieee8.nsys-rep
```

- `benchmarks/delta_prefill_baseline.json`、`delta_prefill_ieee8.json`：算子基线与优化结果。
- `benchmarks/delta_scan_geometry.json`：六组配置、编译器属性、正确性与计时。
- `benchmarks/qwen35_prefill_ieee8.json`：无 profiler 的整模型耗时和精确 logits 对照。
- `benchmarks/qwen35_prefill_reference.json`：包括被拒绝 tf32x3 的 HF 对照。
- `benchmarks/profiles/`：nsys-rep、SQLite 和 CSV 汇总；首轮 `qwen35_prefill` trace 因 tf32x3 token 检查失败提前结束，最终有效对照使用 `qwen35_prefill_ieee8`。

后续应根据最终 trace 的新瓶颈决定方向，不能再沿用旧的“scan 占约九成”结论；可继续研究布局整理、三角求解和逐序列 CPU 同步。

## 最终整引擎 nsys 复测

使用各路径 2 次请求的外层 NVTX range 聚合 GPU kernel 时间（排除其他路径）：

| 配置 | 每请求 scan 累计 | scan 占该请求 kernel 总时间 | BF16 GEMM 占比 |
|---|---:|---:|---:|
| 原 4 warps | 539.350ms | 58.4% | 21.8% |
| 新 8 warps | 47.410ms | 11.1% | 46.7% |

默认优化后的瓶颈已迁移：BF16 GEMM 成为最大类，扫描仍是可优化项，但不再占据原先的大多数时间。该分析来自 nsys CUDA/NVTX trace 和编译器元数据，不依赖 ncu。最终新增及原有回归共 18 项通过，包括 4/8 warps 的输出和状态逐元素一致检查。
