# 自适应 prefill 与正确性/负载基线

## 正确性定位

旧 `test_batch_equals_individual` 的失败来自 Qwen3-0.6B 在不同 batch 形状下的浮点计算差异。逐算子捕获发现：prefill 完全一致；第一次 decode 的首层 `qkv_proj` 输入完全一致，而 GEMM 输出最大差异为 0.001953125。第8个生成位置分歧，batch/single logits 最大差异0.25，单条路径两个最高候选恰好同分；HF 在相同历史下的 top2 gap 为0.125，对 batch/single 候选的 regret 为0/0.125。

完整审计程序与逐步证据为 `benchmarks/audit_batch_consistency.py`、`benchmarks/batch_consistency_audit.json`。不能把不同batch形状视为相同浮点执行路径，也不能要求通用BF16 GEMM保证跨batch逐位一致。没有通过把生产计算逐条拆开来掩盖差异。原严格测试断言保留；新增固定batch形状的两次排列测试，验证请求重排/KV槽位变化后输出保持一致，该测试已通过。这里解释的是这个具体失败，不代表所有数值差异均可归因于近邻tie。

Qwen3.5-27B 的历史严格 HF raw logits 验收未过项仍以 ALIGNMENT.md 为准；新策略的批次/分块变化需单独审计，不继承CPU元数据缓存的逐位一致结论。

## 自适应策略

**当前为未通过完整数值验收的实验策略，不默认启用。** 以下接口仅供实验复现：

```python
LLM(model, scheduling_policy="adaptive", adaptive_tpot_seconds=.1,
    adaptive_ttft_seconds=2., adaptive_min_prefill_tokens=128)
```

默认仍为 `alternating`。`bounded` 的固定512限制继续可选，不是adaptive的隐含上限。策略位于 `zjhvllm/engine/adaptive_prefill.py`：

1. 在原本的交替prefill机会选择预算。CPU侧记录已同步完成的模型执行耗时，用最近64条prefill样本拟合非负、带先验正则的四参数耗时模型：token数、序列数、固定开销、缓存上下文量；decode按近邻batch大小估计。不从CUDA张量读取标量。
2. 按每个活跃请求的已生成token数量和首token以来耗时，计算在平均TPOT目标下还能支付的prefill时间，并预留下一轮decode的预计耗时。
3. 预算候选为128起的倍增配额、队首剩余长度和全局最大预算；取预计可支付的最大值。预测单位token成本较完整batch高出25%以上的碎片被拒绝，避免增加过多前向次数。
4. 活跃decode少于8条时优先补充batch，避免为赚取延迟余量而损害利用率。队首等待时间加预计执行耗时接近TTFT目标的80%时，优先推进prefill，预留20%的预测误差余量，避免无限延后新请求。
5. 没有可支付配额时继续decode；冷启动无decode时保留全局预算。KV/状态槽的资源检查、抢占、完成释放仍走原调度器路径。

这些是软目标。GPU前向不可抢占，预测有误差，过载时TTFT与TPOT可能冲突；不承诺硬实时SLO。逐步决策包含理由、预算、预计耗时、decode余量和队列等待时间，实验原始记录保留所有实际执行步骤。

## 混合长度与交叉实验

主实验seed=29，不使用pilot的seed=17。8张A100同时运行两个四副本策略组；输入长度64/128/512/1024，输出长度32/64/128；closed-loop每卡并发16，Poisson聚合2req/s，burst每2秒8请求（聚合4req/s）。每场景每策略两轮各256请求，第二轮交换GPU分组，最终每场景每策略512请求，全部场景共3072请求。

两种策略共用同一manifest、计划到达和轮询路由，均启用CPU元数据缓存。所有步的计时、token输出、调度理由、源码及SHA256均归档。每种常用分块形状在计时前预热，双方使用相同预热步骤；延迟从计划到达计算，保留实际提交滞后。SLO保持TTFT≤2s且平均TPOT≤100ms，不随结果调整。

```bash
# 在Lumina目录、lumina conda环境中；需要8张空闲A100 80GB。
python -m benchmarks.bench_replica_service --gpus 0 1 2 3 4 5 6 7 --replicas 4 --compare-policies alternating adaptive --concurrencies 16 --requests-per-replica 64 --input-lengths 64 128 512 1024 --output-lengths 32 64 128 --rates 2 --burst-size 8 --burst-interval 2 --repeats 2 --seed 29 --output-dir benchmarks/adaptive_repro
python -m benchmarks.report_adaptive benchmarks/adaptive_repro
# 对策略分歧按输入长度分层，审计最多16处共享历史上的HF候选regret。
CUDA_VISIBLE_DEVICES=1 python -m benchmarks.audit_policy_outputs benchmarks/adaptive_repro
```

主实验和分场景结论见 [实验报告](benchmarks/adaptive_holdout/REPORT.md)，并参考 `comparison.json`、`hf_divergence_audit.json`。两轮重复同一manifest不是两份独立语料；每组512个请求的p99仍是探索性数据，不作统计显著性或生产SLA结论。

早期pilot使用的粗略耗时模型和缺少低batch占用保护的版本使吞吐下降，保留于 `benchmarks/adaptive_pilot_{baseline,candidate}/`，不能用它们替代当前交叉实验。没有扩展TP/EP，也没有默认启用mixed prefill/decode执行。


## 本轮采用结论

交换GPU后，饱和闭环goodput的提升两轮均存在（+37.6%/+41.8%），但汇总吞吐下降4.7%，SLO达标率仅11.3%→16.6%，ITL/TTFT p99没有改善；突发流量goodput下降约3.7%，TTFT p99从0.85s升至1.81s，Poisson基本持平。因此不替换默认策略。

3072请求中生成219264个token；跨策略1536对请求中400对输出不同。分层抽样16处共享历史进行HF完整前向审计，7处candidate相对baseline的regret高出1以上，反方向2处；不能把这些差异全部称为近邻tie，数值验收未通过。完整HF自身路径对照见实验目录的hf_self_reference_audit.json。没有把上述性能结果写成已验收的简历成果。

逐步日志中credit_fit仅1次（128-token配额），1900次选择先运行decode；现阶段收益主要来自调度时序变化，预算模型在这个负载上仍过于保守。原始失败和不利结果均保留。

最终回归44通过、1失败；保留严格的跨batch断言，并以逐算子审计解释该具体失败。源码快照31文件的SHA256已验证；所有指标重算自原始请求记录。相关日志为benchmarks/adaptive_regression.log、adaptive_regression.xml、adaptive_verification.json。


补充HF自身参考路径对照：上述16处真实共享历史中，HF的batch1完整、batch2完整与batch1缓存增量前向有11处top1不一致，最大logits差异分别达17.25/19.73；但仍有3处candidate在所有参考下相对baseline regret高出1以上。参考敏感性不能豁免剩余误差，adaptive仍未通过数值验收。证据见benchmarks/adaptive_holdout/hf_self_reference_audit.json。
