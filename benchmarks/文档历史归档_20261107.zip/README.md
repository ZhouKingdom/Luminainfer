# Lumina：支持 Qwen3.5 混合注意力的轻量推理引擎

最新：多卡MTP验证CUDA Graph与连续补位已实现，`verification_cuda_graph=True`开启验证Graph，`generate_speculative_batch()`默认连续补位，在线入口为`step_speculative()`。162项相关CUDA回归通过。使用与验收见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)。

最新 MTP：已支持 TP1/2/4/8，155项相关回归通过；真实27B的TP2/4/8、C1/C2/C4共48/48次MTP生成与同配置普通解码逐token一致。该阶段使用eager；后续Graph与连续补位见上文。使用与边界见 [MTP_TP.md](MTP_TP.md)。

**接手开发：[Qwen3.5 / MTP 当前交接文档](QWEN35_HANDOFF.md)**（环境、代码地图、已完成工作、八卡失败证据、最小复现与后续优先级）。

最新：Qwen3.5-27B普通文本推理已支持真正TP=2/4/8及原生混合decode Graph，144项相关CUDA回归通过。固定128输入/128输出、C128：TP2/4/8完整batch解码约1779/2651/3208 output tok/s，包含prefill的端到端约784/907/959 tok/s。MTP随后也已接入TP1/2/4/8，见 [MTP_TP.md](MTP_TP.md)。实现、使用方式与指标边界见 [QWEN35_TP.md](QWEN35_TP.md)。

最新可选实验：参考SGLang新增固定归约批量投影后端，16输入×两轮与新后端普通decode为32/32一致；同后端、同Graph的投机相对无草稿控制提升约32.2%，135项相关CUDA回归通过。新后端与旧cuBLAS存在8/32输出差异，默认未改；范围及证据见 [SGLANG_MTP_EXECUTION.md](SGLANG_MTP_EXECUTION.md)。

2026-11-07最新：新增显式开启的单请求 MTP 验证 CUDA Graph，完整128输入×两轮仍256/256一致、105项相关CUDA测试通过。八个独立TP1副本合计150.50 vs普通eager decode 88.52 tok/s（+70.02%）；这是Graph与MTP组合路径的收益；同引擎无草稿Graph控制仍更快，投机自身尚未获益。开启方式、控制组和边界见 [MTP_VERIFICATION_GRAPH.md](MTP_VERIFICATION_GRAPH.md)。

2026-11-07：已实现MTP中间状态提交、每请求独立GPU接受判定与 `generate_speculative_batch()`。C1完整归档256/256一致，C2/C4各32/32配对一致，97项相关回归通过。C1同引擎相对旧重放约快3.1%，多请求尚无明确端到端加速；接口与完整边界见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。

一个从零实现的轻量级 LLM 推理引擎，参考 [vLLM](https://github.com/vllm-project/vllm) 的架构思想，用 PyTorch + Triton 手写核心算子。目标是理解并复现工业级推理引擎的关键技术。

> 支持 Qwen3（dense）、Qwen3-MoE 和 Qwen3.5文本推理；Qwen3.5普通推理支持TP1/2/4/8，通过 `models/registry.py` 按 `model_type` 分发。

## 当前主线与状态

当前主线为 **Qwen3.5 的混合注意力状态正确性与推理优化**：补齐 Gated DeltaNet 的长时间递归、拒绝回滚与槽位隔离，再验证投机解码。现有调度、分页 KV 和多模型支持保留。

P-D 方向暂缓：已有 Dense KV 交接的 CPU 中转原型，完整范围与限制保留在 [PD_SEPARATION.md](PD_SEPARATION.md)。

## 特性

| 能力 | 说明 | 位置 |
|---|---|---|
| 连续批处理 (Continuous Batching) | chunked prefill + 抢占式调度，多请求共享一次前向 | `engine/scheduler.py` |
| Paged Attention | 分块 KV cache，block table 索引，前缀缓存（hash 复用） | `engine/block_manager.py` |
| 张量并行 (TP) | NCCL + 子进程，支持 tp=1..8 | `layers/linear.py` |
| CUDA Graph 解码 | 按 batch 分桶捕获解码图，降低 launch 开销 | `engine/model_runner.py` |
| 手写 Triton 采样器 | temperature/top_k/top_p/repetition_penalty + Gumbel-max + Philox 可复现 | `layers/sampler.py` |
| Flash Attention | varlen（prefill）+ kvcache（decode） | `layers/attention.py` |
| FP8 KV cache | e4m3 量化 + per-token scale，KV 显存减半 | `layers/attention.py` |
| MoE（稀疏专家） | router + top-k 专家选择 + 稀疏激活 FFN | `layers/moe.py` |
| 专家并行（EP） | 专家按卡分布 + all-to-all 路由（router replicated） | `layers/ep_moe.py` |

## Qwen3.5（实验支持）

已实现 TP1/2/4/8 文本推理：full attention 使用 paged KV，Gated DeltaNet 使用独立的
fp32 递归状态和卷积历史；长序列 prefill 已有 chunk 算法及 Triton 扫描，
decode 使用 Triton 融合状态更新，避免完整状态的 gather/scatter 临时张量。
普通推理支持原生混合 decode CUDA Graph；多卡 MTP 已有可选验证 Graph，见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)。

递归模型暂时禁用 KV 前缀复用，因为仅复用 KV 不能恢复线性注意力的 S 和卷积状态。
分块 prefill 保留同一请求的状态；抢占后从完整前缀重新计算。
普通 Qwen3 / Qwen3-MoE 保留原有前缀缓存行为。

新增 checkpoint **MTP-1** 草稿接口，加载全部 15 组 MTP 权重，共享主模型 embedding/LM head，维护独立的草稿 KV；同时保留显式 prompt lookup 对照。
启用方式为 `LLM(..., enable_mtp=True, tensor_parallel_size=4, max_num_seqs=4)`，再调用 `generate_speculative(...)`，默认草稿来源即 MTP。
包含 S、conv 和私有 KV 页事务。
默认 `verification_mode="serial"` 使用普通 decode 路径作正确性参考，**没有投机加速收益**；
`batched_experimental` 已修复投影、norm、递归和 attention 的数值路径差异，正式验证及拒绝重放沿用逐 token decode 算子。84 项相关回归通过。
同一归档 128 输入×两轮对照中，修复后批量输出 **256/256** 与普通 decode 一致；八卡吞吐 76.69 vs 基线 87.58 output tok/s，**数值问题已修复，尚无加速收益**。详见 [数值修复与验收](MTP_NUMERICAL_FIX.md)。

修复前的八卡扩大对照保留：128 个不同输入×两轮×三模式，共 768 次生成、72,834 输出 token，所有请求回收资源。
该历史版本 MTP 串行参考 256/256 一致；批量实验 184/256 一致，约 89.2% 草稿接受率，数值验收失败。
八卡总活跃并发 8（每卡1），具体指标、输入组成与边界见 [MTP_SCALE.md](MTP_SCALE.md)。

无需模型权重的 CPU 调度回归测试：

```bash
python -m pytest tests/test_scheduler_state.py -q
```

接手进度见 [HANDOFF.md](HANDOFF.md)，Qwen3.5 整模型验证结果与限制见 [ALIGNMENT.md](ALIGNMENT.md)，prefill 调优证据见 [PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md)。

## Qwen3.5 八卡容量实测

单机 8×A100 80GB、8 个独立单卡 Qwen3.5-27B 副本（不新增 TP/EP），固定 128-token 输入 / 64-token 输出，eager，引擎原生闭环接口：

| 总并发 | 请求数 | output tok/s | TTFT p99 | TPOT p99 | 预设 SLO 达标率 |
|---:|---:|---:|---:|---:|---:|
| 64 | 1024 | 649.6 | 1.10s | 95.7ms | 100% |
| 128 | 1024 | 1157.5 | 2.17s | 102.8ms | 93.75% |

每卡固定并发 8 时，1→8 副本容量扩展 7.85×（98.2% 效率）。SLO 门槛为 TTFT≤2s 且每请求平均 TPOT≤100ms，不代表生产 SLA。上述为合成文本、单次实验，未包含 HTTP/网络开销；不同场景的吞吐和尾延迟不可拼接。

完整方法、Poisson 到达结果及原始时间戳见 [八卡实验报告](benchmarks/service_8gpu/REPORT.md)。

## 环境

```bash
conda create -n lumina python=3.12
conda activate lumina
# 服务器不通外网时，先走端口转发代理：
export http_proxy=http://127.0.0.1:17988 https_proxy=http://127.0.0.1:17988 all_proxy=http://127.0.0.1:17988 no_proxy=localhost,127.0.0.1
pip install torch==2.8.0 triton transformers flash-attn xxhash
pip install pytest fastapi uvicorn   # 测试 + 服务
```

依赖版本：`torch 2.8.0(+cu128)`、`triton 3.4.0`、`transformers`、`flash-attn 2.8.3.post1`（cxx11abiTRUE）、`xxhash`。

> 注意：torch 2.8.0 用的是 `_GLIBCXX_USE_CXX11_ABI=True`，flash-attn 需选 `cxx11abiTRUE` 的 wheel。

## 快速开始

```bash
# 示例（Qwen3-0.6B）
python example.py

# 压测（Qwen3-32B，需要 TP）
python bench.py
```

模型路径：`~/huggingface/Qwen3-0.6B`（小模型，单卡即可）。`bench.py` 用 32B，需 `tensor_parallel_size=4`（单卡 KV cache 容不下 256 条并发序列，见 `OPTIMIZATION_ROADMAP.md`）。

### FP8 KV cache

```python
from zjhvllm import LLM
llm = LLM(model_path, kv_cache_dtype="fp8")  # 默认 "auto"=bf16
```

KV 用 e4m3 fp8 + per-token scale 存储，`flash-attn 2.x` 不支持 fp8 KV，因此 decode/prefill 读缓存时用 PyTorch 原生反量化 gather 成连续 bf16 再走 flash_attn。实测相同显存预算下 KV 容量翻倍（533 → 1062 blocks）。

### MoE（稀疏专家）

支持 Qwen3-MoE 架构（`model_type="qwen3_moe"`，经 `models/registry.py` 分发）：

- 单卡版：`layers/moe.py` 的 `MoE`（router + top-k 专家选择 + 稀疏激活）。
- 专家并行（EP）：`layers/moe.py` 的 `MoE` 在 `expert_parallel_size>1` 时走 all-to-all 路由（专家按卡分布、router replicated、权重按 rank 过滤加载）。
- 已用真实模型 **Qwen3-30B-A3B**（128 专家 top-8，30B 总参/3B 激活）跑通：TP=4 和 **EP=8**（每卡 16 专家）输出一致。

```python
llm = LLM("path/to/Qwen3-30B-A3B", tensor_parallel_size=4)      # 纯 TP
llm = LLM("path/to/Qwen3-30B-A3B", expert_parallel_size=8)      # 专家并行（num_key_value_heads=4 限制 TP≤4，上 8 卡需 EP）
```

EP 的设计见 [MOE_DESIGN.md](MOE_DESIGN.md)。

## 正确性测试

21 个测试覆盖：logits 与 HuggingFace 逐元素对齐、greedy/批处理/前缀缓存/chunked prefill/确定性、Triton 采样器与 numpy 参考对齐、fp8 KV cache、MoE 层与专家并行（EP）。

```bash
python -m pytest tests/ -v
```

测试设计要点（见 `tests/test_logits.py`、`tests/test_generate.py`）：
- **logits 对齐**：zjhvllm 用 flash-attn、HF 用 SDPA，两者有 ~0.1~0.4 的数值噪声，用 `max_abs_diff < 1.0` 区分「噪声」和「真 bug」。
- **greedy 近邻 tie**：当某步 top1-top2 gap 小于噪声时 argmax 会翻转、级联发散，这是预期行为。测试在分歧点验证 HF 的 top1-top2 gap 来区分近邻 tie 与真 bug。

## OpenAI 兼容服务

```bash
python server.py --model ~/huggingface/Qwen3-0.6B --enforce-eager
# 或 uvicorn server:app --host 0.0.0.0 --port 8000
```

端点：

| 端点 | 说明 |
|---|---|
| `GET /health` | 健康检查 |
| `GET /v1/models` | 模型列表 |
| `POST /v1/completions` | 文本补全（支持 `stream`） |
| `POST /v1/chat/completions` | 对话补全（chat template + `stream`） |

```bash
# 非流式
curl -s http://127.0.0.1:8000/v1/completions -H 'Content-Type: application/json' \
  -d '{"prompt":"The capital of France is","max_tokens":32,"temperature":0}'
# 流式
curl -sN http://127.0.0.1:8000/v1/completions -H 'Content-Type: application/json' \
  -d '{"prompt":"Hi","max_tokens":16,"temperature":0,"stream":true}'
```

架构：`zjhvllm/engine/async_llm_engine.py` 的异步引擎在后台线程跑 continuous batching 的 `step()` 循环，所有引擎访问集中在单线程（避免多线程竞争调度器/KV cache），HTTP 侧通过 thread-safe 队列提交请求、`loop.call_soon_threadsafe` 投递 token 流。

## 目录结构

```
zjhvllm/
  llm.py                 # LLM 入口（LLMEngine 子类）
  config.py              # 配置
  sampling_params.py     # 采样参数
  engine/                # 调度 / 执行
    scheduler.py         # 连续批处理调度
    block_manager.py     # paged KV cache + 前缀缓存
    model_runner.py      # 模型执行 + TP + CUDA graph + KV cache 分配
    llm_engine.py        # 同步引擎（add_request / step / generate）
    async_llm_engine.py  # 异步引擎（后台 step 循环 + 流式）
    sequence.py
  layers/                # attention / 线性 / norm / rope / sampler / 采样
  models/qwen3.py        # Qwen3 模型
tests/                   # 正确性测试
server.py                # OpenAI 兼容服务
bench.py / example.py    # 压测 / 示例
benchmarks/              # 与官方 vLLM 的吞吐对比（见 benchmarks/README.md）
```

## 文档索引

- [TUTORIAL.md](TUTORIAL.md) — 小白手把手教程（从最简版讲透每个机制，建议先读这个）
- [PROJECT.md](PROJECT.md) — 详细技术文档（架构、核心组件、性能、踩坑）
- [RESUME_PREP.md](RESUME_PREP.md) — 简历准备（bullet、量化指标、面试 Q&A）
- [OPTIMIZATION_ROADMAP.md](OPTIMIZATION_ROADMAP.md) — 优化路线图
- [MOE_DESIGN.md](MOE_DESIGN.md) — MoE 与专家并行（EP）设计

## 优化路线图

见 [OPTIMIZATION_ROADMAP.md](OPTIMIZATION_ROADMAP.md)（多模型 + MoE、FP8 KV cache、speculative decoding 等方向及简历建议）。
