# MTP 验证窗口 CUDA Graph（2026-11-07）

后续普通推理已有TP1/2/4/8及原生混合decode Graph，见 [QWEN35_TP.md](QWEN35_TP.md)。本文描述此前单卡MTP验证Graph，下面“没有实现普通decode Graph”等是该阶段边界，不能覆盖最新普通推理能力。

后续已有参考SGLang的新批量投影实验后端，见 [SGLANG_MTP_EXECUTION.md](SGLANG_MTP_EXECUTION.md)：新后端内部投机相对同Graph无草稿控制有收益，但不与旧cuBLAS逐位兼容，默认未改。本文的“投机尚无独立收益”结论描述原逐行投影后端。

新增显式配置 `verification_cuda_graph=True`，在单请求 MTP-1 的两行验证窗口重放现有算子，减少 CPU 调度和 kernel 启动开销。投影、norm、GDN 与 full attention 保持原逐 token 算子及舍入路径；没有恢复此前失配的批量 GEMM。

```python
llm = LLM(model_path, enable_mtp=True, max_num_seqs=1,
          verification_cuda_graph=True, enforce_eager=True,
          max_model_len=4096, gpu_memory_utilization=.85)
try:
    result = llm.generate_speculative(
        prompt, SamplingParams(greedy=True, max_tokens=128),
        verification_mode="batched_experimental")
finally:
    llm.exit()
```

此配置只控制投机验证，与普通 decode 的 `enforce_eager` 分开。默认 False；默认 serial 验证也保持原行为。当前只在有中间状态工作区、单请求两行窗口、非 FP8 KV 时启用。尾部单 token、较长通用窗口、FP8、旧重放参考和多请求 `verify_greedy_batch()` 继续 eager。这里没有实现普通 Qwen3.5 decode、MTP 草稿或 C2/C4 投机的 Graph。

首次符合条件的验证先预热、捕获，再重放；第一次使用包含捕获成本。基准在计时前预热排除这部分成本，短的一次性任务不能直接套用稳态吞吐。Graph 常驻缓存一个窗口，额外保留其私有内存池；不是按请求无限增长的缓存。

## 状态和动态输入

Graph 的 input IDs、positions、物理 KV slots、请求状态槽、每行因果长度和 page table 都有稳定地址，每轮在同一 CUDA stream 更新后再重放。Page table 预留到 `max_model_len` 的页数，因此跨页和换请求不需重新捕获；有效前缀仍由每行长度限制。工作区对象更换时重新捕获。

捕获和预热只写暂存 S/conv 及私有验证 KV，不推进持久递归状态。接受判断、状态提交、target hidden 发布和页/token 元数据事务继续由原验证流程执行。提交中途异常仍恢复 checkpoint。Graph 不重新进入 Python forward，故动态修改模型方法后应关闭该选项或重新创建引擎。

## 诊断和复现

`benchmarks/qwen35_mtp_perf_20261107/` 保留本轮诊断和试跑。`profile_before/` 是预热后真实27B、16输出token的 PyTorch profiler；其算子耗时不能直接当无 profiler 的端到端耗时。`aten::mm` 占 Self CUDA 约69.6%，CPU kernel launch 约27.1%。

`linear_probe.json` 记录直接批量 mm/bmm 与逐行参考不一致的候选；未接入正式代码。`stream_probe.json` 记录保留单行 GEMM 的多stream候选，收益不稳定，亦未接入。`pilot_graph/` 是四个历史失败输入、32-token预算、两轮同引擎反转模式顺序的试跑；输出一致和资源回收均通过，不能替代完整归档验收。

```bash
python -m benchmarks.bench_mtp_state_commit --compare-graph --graph-control \
  --output benchmarks/mtp_graph_paired_new
python -m benchmarks.bench_mtp_replicas --verification-cuda-graph \
  --workload benchmarks/qwen35_mtp_8gpu_20261106/workload.json \
  --output benchmarks/mtp_graph_8gpu_new
python -m benchmarks.report_mtp_replicas benchmarks/mtp_graph_8gpu_new
```

小模型回归同时比较 eager/Graph 和普通 decode，覆盖 BF16/FP8 回退、255/256/257页边界、不同草稿、预算、状态与hidden、Graph完整logits和逐行LM head精确一致，以及提交失败恢复。最终相关 CUDA 回归 **105 passed、0 skipped**，见 [regression_final.log](benchmarks/qwen35_mtp_perf_20261107/regression_final.log)。这是相关测试集，不是全仓测试；也没有新的 HF logits 验收结论。

## 完整归档验收

[报告](benchmarks/qwen35_mtp_graph_8gpu_20261107/REPORT.md)、[验收](benchmarks/qwen35_mtp_graph_8gpu_20261107/validation.json)、[汇总](benchmarks/qwen35_mtp_perf_20261107/summary.json)：相同128输入、两轮换卡并反转模式顺序，三模式共768次生成、72,834输出token。每模式256/256与配对基线一致，三模式跨轮各128/128输出相同，资源768/768回收；普通decode与最初归档也256/256一致。源码快照 SHA256 已与当前 runtime 核对。

| 模式 | 八副本合计 output tok/s | 与普通decode一致 |
|---|---:|---:|
| 普通 eager decode | 88.52 | 256/256 |
| MTP serial | 87.26 | 256/256 |
| MTP + 验证 Graph | 150.50 | 256/256 |

整条优化路径相对当前普通 eager decode 吞吐增加 **70.02%**。基线与候选均驻留 MTP 权重及预热后的 Graph 工作区，计时排除加载、JIT和捕获；每卡C1、八个独立TP1副本，不是TP8。草稿接受率88.90%，与串行参考相同。

这不是“投机算法独立提升70%”的证据：候选同时使用 Graph，普通基线仍为 eager。无草稿 Graph 控制使用相同 checkpoint、暂存状态和提交事务，每步仅验证一个 pending token，不计算 MTP 草稿；它是贡献分离诊断，并非已经实现的普通 decode Graph 产品路径。控制组结果另记于 `paired_graph_control/result.json`，不能和八副本表跨运行混算。

## 无草稿 Graph 控制

[同引擎记录](benchmarks/qwen35_mtp_perf_20261107/paired_graph_control/result.json)：四个历史失败输入、输出上限32、两轮反转模式顺序，各模式8次生成全部与基线一致、两轮基线自身一致、资源全部回收。四种模式与两个Graph在计时前均已预热，吞吐为两轮总输出除以总时间。

| 单卡模式 | output tok/s |
|---|---:|
| 普通 eager decode | 10.026 |
| eager MTP 中间状态提交 | 9.174 |
| MTP + 验证 Graph | 15.426 |
| 无草稿 Graph 验证控制 | 16.387 |

两轮候选实际重放Graph共128次，控制组248次；没有把未执行Graph的回退算作Graph结果。控制组约快6.2%（候选较控制低约5.9%），说明此小集上投机本身仍无独立加速收益。当前两行GEMM各自读权重，接受率高也未换来共享权重读取的批量执行；本轮有效改善主要是CPU调度和kernel启动。后续要检验真正的投机收益，应优化保持数值参考的批量算子，并与同样优化的无草稿路径比较。

完成时八张GPU均仅占4 MiB，无计算进程。历史eager失速、BF16失配及HF严格logits失败仍保留，没有改写为通过。
