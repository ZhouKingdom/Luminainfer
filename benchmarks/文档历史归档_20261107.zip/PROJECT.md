# zjh-vllm 项目文档

一个从零实现的轻量级 LLM 推理引擎（参考 vLLM 架构），用 PyTorch + Triton 手写核心算子。支持 Qwen3（dense）和 Qwen3-MoE（稀疏专家）架构，跑通真实模型 Qwen3-32B 与 Qwen3-30B-A3B。

## 1. 技术栈

| 层 | 技术 |
|---|---|
| 语言/框架 | Python 3.12、PyTorch 2.8.0(+cu128) |
| 高性能算子 | Triton（采样器、KV cache 存储）、Flash Attention |
| 通信 | NCCL（TP all_reduce / EP all-to-all） |
| 模型 | Qwen3（dense）、Qwen3-MoE（稀疏专家） |
| 服务 | FastAPI + 异步引擎（OpenAI 兼容） |

## 2. 架构总览

```
zjhvllm/
  llm.py                 # LLM 入口（LLMEngine 子类）
  config.py              # 配置（含 tensor_parallel_size / expert_parallel_size / kv_cache_dtype）
  sampling_params.py
  engine/
    scheduler.py         # 连续批处理调度（prefill/decode 交替、chunked prefill、抢占）
    block_manager.py     # Paged KV cache + 前缀缓存（hash 复用）
    model_runner.py      # 模型执行 + TP/EP + CUDA graph + KV cache 分配
    llm_engine.py        # 同步引擎（add_request / step / generate）
    async_llm_engine.py  # 异步引擎（后台 step 循环 + 流式）
    sequence.py
  layers/
    attention.py         # Flash attention + KV cache 存储（含 FP8 量化）
    linear.py            # TP 线性层（Column/Row/QKV parallel）
    moe.py               # MoE 层（router + top-k + 稀疏激活，单卡 + EP）
    sampler.py           # Triton 采样器（top_k/top_p/repetition_penalty + Gumbel-max）
    layernorm.py / rotary_embedding.py / activation.py / embed_head.py
  models/
    qwen3.py / qwen3_moe.py / registry.py
  utils/
    loader.py            # 权重加载（含专家按 rank 过滤）
    tp.py                # TP 全局 size/rank（解耦自 dist）
    context.py
```

## 3. 核心组件

### 3.1 连续批处理（Continuous Batching）

`scheduler.py`。核心思想：多请求共享一次前向，避免逐请求串行。

- **两阶段调度**：Decode 优先、Prefill 次之。Decode 每步给每条 running 序列推 1 个 token（memory-bound，逐 token 生成），Prefill 一次性算完整 prompt（compute-bound）。
- **Chunked Prefill**：长 prompt 按 `max_num_batched_tokens` 切块，避免长 prompt 阻塞 decode。
- **抢占（Preemption）**：KV cache 块不足时，按 LIFO 抢占 running 队列末尾的序列（影响最小），放回 waiting 队列。

### 3.2 Paged Attention + 前缀缓存

`block_manager.py`。KV cache 按固定大小块（`block_size=256`）分页，序列通过 `block_table` 引用物理块，避免连续显存分配。

- **前缀缓存**：用 xxhash 对每块 token 序列算指纹，命中相同前缀时复用物理块（`can_allocate` 返回可复用块数）。
- **引用计数**：多序列共享同一前缀块时 ref_count 递增，释放时递减。

### 3.3 张量并行（TP）

`linear.py`。模型层按 TP 维度切分：

- `ColumnParallelLinear` / `QKVParallelLinear`：权重按输出维度切分（每卡算一部分 head），无需通信。
- `RowParallelLinear`：权重按输入维度切分，forward 后需 `all_reduce` 汇总。
- `VocabParallelEmbedding` / `ParallelLMHead`：词表按卡切分，embedding 用 `all_reduce`、lm_head 用 `all_gather`。

进程模型：`ModelRunner` 用 `spawn` 起 `world_size-1` 个子进程，rank 0 是主进程（调度器 + tokenizer），通过共享内存 RPC 广播指令，NCCL 做通信。

### 3.4 专家并行（EP）+ MoE

`moe.py` + `utils/tp.py`。MoE 的稀疏激活特性允许专家权重分布在多卡：

- **单卡**（world_size==1）：持有全部专家，本地 loop 遍历 top-k 专家。
- **EP**（world_size>1，TP==1）：每卡只持有 `num_experts/world_size` 个专家，router replicated，token 通过 **all-to-all** 路由到活跃专家所在卡。

all-to-all 数据流：router 算 top-k → token 按目标专家所在 rank 分组 → `all_to_all_single` dispatch → 本地算专家 FFN → `all_to_all_single` combine（对称逆变换）→ scatter 回原始位置加权求和。

关键设计：`utils/tp.py` 把 TP 的 `tp_size/tp_rank` 从 `dist.get_world_size()` 解耦。EP 模式下 tp=1（非 MoE 层 replicated），world_size=EP 大小。这样 attention/embedding 等非 MoE 层 replicated，MoE 专家按卡分布。

### 3.5 CUDA Graph 解码

`model_runner.py:capture_cudagraph`。Decode 阶段每步只算 1 个 token，kernel launch 开销占比高。按 batch 分桶（1/2/4/8/16/…）预捕获 CUDA graph，运行时 replay 消除 launch 开销。Prefill 保持 eager（tensor 形状多变）。

### 3.6 Triton 采样器

`sampler.py`。三个手写 Triton 内核：

1. **温度缩放 + repetition penalty**：按词表分块（tile）并行，`O(vocab)` 复杂度与历史长度无关。
2. **top_k/top_p 过滤**：二分查找阈值（`ITERS=14`），避免对整个词表排序。
3. **采样**：greedy（argmax）或 Gumbel-max（`argmax_i(logit_i + Gumbel_i)`，等价 softmax 采样），Philox 随机数保证可复现。

### 3.7 FP8 KV cache

`attention.py`。KV 用 fp8 e4m3 + per-token scale 存储，显存减半。

- 存储：`store_kvcache_fp8` 量化（scale = max(|x|)），存 fp8 数据 + fp32 scale。
- 读取：`gather_dequant` 反量化成连续 bf16，再走 flash_attn（flash-attn 2.x 不支持 fp8 KV）。
- 注意：A100（Ampere）上 Triton 的 `fp8e4nv` 不可用，用 PyTorch 原生 `torch.float8_e4m3fn` cast。

### 3.8 异步引擎 + OpenAI 服务

`async_llm_engine.py` + `server.py`。后台线程跑 continuous batching 的 `step()` 循环，所有引擎访问集中在单线程（避免竞争调度器/KV cache），HTTP 侧通过 thread-safe 队列提交、`loop.call_soon_threadsafe` 投递 token 流。端点：`/v1/completions`、`/v1/chat/completions`（均支持 stream SSE）。

## 4. 性能数据

### 吞吐（256 条并发序列，随机 prompt，seed 固定）

| 配置 | zjh-vllm | vLLM 0.11.0 | 对比 |
|---|---|---|---|
| Qwen3-0.6B，单卡 | 10368 tok/s | 8159 tok/s | +27% |
| Qwen3-32B，4×A100（TP=4） | 2997 tok/s | 3069 tok/s | -2.4%（97.6%） |

> 对比条件：相同模型、相同 workload（`seed(0)`，256 序列，input/output 各 100~1024 token）、相同 TP、均开 CUDA graph。总生成 token 一致（133966），保证公平。

### 其他

| 指标 | 数值 |
|---|---|
| FP8 KV cache 容量 | 相同显存下 533 → 1062 blocks（≈2x，上下文长度/batch 可翻倍） |
| Qwen3-30B-A3B（MoE，30B 总参/3B 激活） | TP=4 和 EP=8 均跑通，输出一致 |

## 5. 正确性测试

21 个测试（`tests/`），核心思路：

- **logits 对齐**：zjhvllm 前向 logits 与 HF 逐元素对齐。因 flash-attn vs SDPA 有 ~0.1~0.4 数值噪声，用 `max_abs_diff < 1.0` 区分「噪声」和「真 bug」。
- **greedy 近邻 tie**：某步 top1-top2 gap 小于噪声时 argmax 翻转、级联发散（预期行为）。测试在分歧点验证 HF 的 top1-top2 gap 来区分近邻 tie 与真 bug。
- **MoE/EP**：单卡 MoE forward 对齐参考、EP 多卡 all-to-all 输出对齐单卡、专家权重加载（合成 safetensors）。

## 6. 设计权衡与踩坑（关键经验）

1. **TP 与 EP 的维度解耦**：KV cache 的头切分属于 TP 维度（EP 下 replicated），否则 `num_kv_heads // world_size` 会除零。核心是 `utils/tp.py` 的全局 tp_size。
2. **MoE 专家权重加载**：EP 下每卡只加载本地专家，需在 loader 里过滤 + 重映射。读张量用原始名（全局专家 id）、找参数用重映射名（本地 index），二者不可混淆。
3. **并行层权重无初始化**：`LinearBase` 用 `torch.empty`（靠 load_model 填充），合成测试需手动赋随机值。
4. **多进程 spawn 的 main guard**：脚本缺 `if __name__ == "__main__"` 会导致 spawn 递归失败、留下占端口的僵尸进程。
5. **模型 KV 头限制 TP**：Qwen3-30B-A3B 的 `num_key_value_heads=4`，纯 TP 最大 4，上 8 卡必须 EP。

## 7. 已知限制与未来方向

- 仅支持 Qwen3 架构（registry 可扩展）。
- EP + TP 2D 并行未实现（当前 EP 要求 TP==1）。
- MoE 无负载均衡（aux loss）。
- 未实现 speculative decoding、自研 paged attention kernel。

详见 `OPTIMIZATION_ROADMAP.md` 和 `MOE_DESIGN.md`。
