# Qwen3.5-27B MTP 张量并行

后续已实现多卡验证 Graph 与连续补位，见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)。本文件保留 TP 接入阶段的分片说明和原验收记录。

MTP-1 现已接入 TP=1/2/4/8、EP=1 的文本推理。每个 rank 执行分片后的目标模型和 MTP decoder，rank 0 决定草稿及目标预测 token，各请求分别提交自己的接受长度，不取请求间最小值。

```python
from zjhvllm import LLM, SamplingParams

llm = LLM('/home/data/jhzhou/huggingface/Qwen3.5-27B',
          tensor_parallel_size=4, enable_mtp=True, max_num_seqs=4,
          max_model_len=4096, max_num_batched_tokens=512,
          enforce_eager=True, verification_cuda_graph=True, distributed_port=2480)
try:
    params = SamplingParams(greedy=True, max_tokens=128)
    result = llm.generate_speculative(
        '解释张量并行的工作原理。', params,
        verification_mode='batched_experimental')
    results = llm.generate_speculative_batch(
        ['解释张量并行。', '写一个二分查找函数。'], params)
finally:
    llm.exit()
```

启动进程前设置足够 GPU，例如 `CUDA_VISIBLE_DEVICES=0,1,2,3`。普通 `generate()` 仍为非投机接口。

## 实现

- MTP decoder 的 Q/K/V、输出投影和 MLP 复用 Qwen3.5 TP 分片加载，MTP 私有 KV 使用局部 KV 头。27B TP8 时每两 rank 复制同一全局 KV 头。
- MTP fc、norm、主 embedding/head 与目标最终 hidden 暂时复制；不是所有参数都切分的最省显存实现。15 组真实 checkpoint MTP 权重逐 rank 完整检查，未生成假草稿。
- 普通 decode 继续使用只传末 token 的紧凑 IPC；MTP/验证命令传完整请求快照，包含 token 历史、状态槽、页表、缓存边界、EOS 和输出预算。初始化后同步各 rank 的 EOS 配置。
- rank 0 广播草稿和目标预测，所有 rank 使用相同的每请求接受决策。接受长度可以不同，目标 S/conv、target hidden 和私有草稿 KV 均按请求管理。
- 准备阶段先跨 rank 汇总错误再进入前向；提交前再次确认。某 rank 的可恢复准备/提交错误会使所有 rank 恢复相应 S/conv 与草稿逻辑长度，rank 0 抛错，工作 rank 留在命令循环。KV 和 hidden 的未提交后缀由逻辑边界隐藏，目标页表由调度器回收。NCCL 失败或进程退出不属于可恢复 Python 事务。
- 默认数值路径中，验证不仅固定每行 GEMM，还固定行并行 all-reduce 的单 token 张量形状。BF16 NCCL 归约会受张量大小/协议影响，只固定 GEMM 不足以保证同 TP 的 greedy 一致。

## 边界

`max_num_seqs` 仍须显式设为 1–8；本轮真实模型覆盖 C1/C2/C4。只实现 greedy、MTP-1；多请求接口默认连续补位，`continuous=False` 保留固定cohort控制，在线请求使用 `step_speculative()`。随机拒绝采样未实现。

`verification_cuda_graph=True` 已支持各TP的多请求验证Graph，包括混合1/2行窗口；FP8、更宽窗口及超出16种缓存布局时回退eager，详见后续报告。未启用 MTP 的普通多卡 decode Graph 也保留。可选 `batch_invariant` 数值后端的多卡 MTP 未做本轮真实模型验收，正式结果使用默认 `decode_equivalent`。

性能与正确性分别报告：多卡能运行 MTP 不代表已有投机加速；TP接入阶段的四条输入含 990/2076-token 长 prompt、各生成32 token，是正确性负载，E2E 包含分块 prefill。不能与普通推理 C128 满载解码窗口的几千 tok/s 混比。跨 TP 数浮点顺序可以不同，只在相同 TP、相同后端与相同配置下对照普通 greedy。

TP接入阶段155项相关CUDA回归通过；真实TP2/4/8覆盖C1/C2/C4，48/48次MTP生成与相同配置普通解码逐token一致，共84次生成、2688输出token。分布式小模型还验证不同接受长度与单rank故障回滚。

隔离NCCL归约的实验在TP4、相同BF16局部分量下，仅把一次 `[2,5120]` 归约改成两次 `[1,5120]`，10240个输出中3299个不同、最大绝对差0.0625；该实验不运行GEMM，见原始 `nccl_shape_tp4.json`。

测试结果与原始数据见 [本轮报告](benchmarks/qwen35_mtp_tp_20261107/REPORT.md)。旧单卡报告保留原实验范围。
