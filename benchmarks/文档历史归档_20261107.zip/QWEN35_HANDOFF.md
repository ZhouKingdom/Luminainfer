# Lumina 项目交接：Qwen3.5、线性注意力与 MTP

更新时间：2026-11-07。面向接手项目的 AI，按当前代码、原始测试记录和用户最新要求整理。

**最新：多卡多请求 MTP 验证 Graph 与连续补位已实现。** `verification_cuda_graph=True`开启TP1/2/4/8目标验证Graph；`generate_speculative_batch()`默认连续补位，`continuous=False`保留固定cohort控制，在线入口`step_speculative()`。162项相关CUDA回归通过；真实27B的TP2/4/8共96/96次连续MTP与普通解码逐token一致，总160次生成3320输出token，资源回收。C4小负载Graph预热后23.05/26.68/26.26 output tok/s（不是C128容量）。修复了partial prefill持页造成的低容量死锁，并补齐故障异常引用环回收/NCCL退出同步。详见 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md) 及 [正式报告](benchmarks/qwen35_mtp_continuous_graph_20261107/REPORT.md)。

**上一阶段：MTP-1 也已支持真正 TP=1/2/4/8（EP=1）。** 155项相关CUDA回归通过；TP2/4/8分布式混合接受及单rank故障回滚通过。真实27B在每种TP覆盖C1 serial/batched、C2/C4 batched，48/48次MTP生成与相同配置普通decode逐token一致，共84次生成2688输出token，各rank logits有限、资源全部回收。修复了完整请求IPC、草稿局部KV、预测广播、EOS配置同步、分布式提交与回滚，以及验证中BF16 NCCL归约形状导致的输出偏差。该阶段多卡验证eager；后续多卡验证Graph与连续补位见最新 [MTP_CONTINUOUS_GRAPH.md](MTP_CONTINUOUS_GRAPH.md)。使用方式见 [MTP_TP.md](MTP_TP.md)，证据见 [本轮报告](benchmarks/qwen35_mtp_tp_20261107/REPORT.md)。

**最新：普通Qwen3.5-27B推理已扩展真正TP=2/4/8与原生混合decode Graph。** 用户本轮明确要求多卡，覆盖旧“不扩TP8”边界。144项相关CUDA回归、TP2/4/8分布式FP32小模型对照通过；真实27B四种TP各161/161同引擎Graph/eager输出一致，每步logits有限。固定128输入/128输出、C128：TP2/4/8完整batch解码约1779/2651/3208 output tok/s，端到端约784/907/959 tok/s。MTP后续也已接入TP1/2/4/8，见 [MTP_TP.md](MTP_TP.md)。详见 [QWEN35_TP.md](QWEN35_TP.md)，不要把解码窗口当E2E或将此前八副本当TP8。

**此前可选实验：SGLang固定归约批量投影后端已实现。** 设置 `qwen35_linear_backend="batch_invariant"` 并开启验证Graph，窗口先批量投影、因果递归后批量输出投影。135项相关CUDA回归通过；16混合输入×两轮，新后端各模式32/32与自身普通decode一致，Graph投机比同后端Graph无草稿控制约快32.21%。新旧后端有8/32输出差异，默认仍是旧 `decode_equivalent`；旧后端与原归档32/32一致。详见 [SGLANG_MTP_EXECUTION.md](SGLANG_MTP_EXECUTION.md)，不要将同后端无损误称为旧基线兼容。

**上一阶段：单请求MTP验证CUDA Graph已接入，显式设置 `verification_cuda_graph=True`。** 复用原逐token算子，完整128输入×两轮仍256/256一致，768/768资源回收，105项相关CUDA回归通过。八个独立TP1副本合计150.50 vs普通eager decode 88.52 tok/s（+70.02%）；收益属于Graph与MTP组合，不能单独归因于投机。无草稿Graph控制16.387 vs Graph投机15.426 tok/s，此小集仍无投机独立收益。默认关闭，当前只覆盖单请求两行目标验证，不包括普通decode、MTP草稿、多请求或FP8的Graph。见 [MTP_VERIFICATION_GRAPH.md](MTP_VERIFICATION_GRAPH.md)。

**2026-11-07上一阶段：中间状态提交与每请求独立MTP已实现。** 常规MTP-1拒绝后不再整模型重放；C1归档128输入×两轮仍256/256一致、768/768回收，普通decode与旧归档256/256一致。新增 `generate_speculative_batch()`：C2/C4各16个混合输入×两轮，各32/32与同配置baseline一致。97项相关CUDA测试通过，无skip；GPU已释放。C1同引擎相对旧重放约快3.06%，但仍低于普通decode；C2/C4与自身baseline基本持平。接口是同步固定cohort，不是连续投机补位；完整证据和限制见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。以下旧阶段数字保留为历史。
这是一份当前状态快照；[HANDOFF.md](HANDOFF.md) 保留 Claude/Codex 历史，里面旧阶段的“尚未实现 MTP”“主线转 P-D”等表述不能覆盖本文。

2026-11-06阶段：**批量验证数值问题已修复并接入正式代码**。相同归档128输入×两轮，batch 和 serial 均256/256与普通decode逐token一致；普通decode与旧归档也256/256一致，768/768资源回收。84项相关测试通过（实际CUDA、无skip），八卡已释放。修复统一了投影、RMSNorm、递归和full attention的逐token计算路径，验证与拒绝重放均生效；八卡吞吐76.69 vs基线87.58 output tok/s，**没有加速收益，默认仍为serial**。见 [MTP_NUMERICAL_FIX.md](MTP_NUMERICAL_FIX.md)；[诊断历史](MTP_NUMERICAL_DIAGNOSIS.md) 和原184/256失败记录继续保留。

## 1. 先读这几条

1. 项目已经支持 **Qwen3.5-27B 普通TP1/2/4/8文本推理**，不是等待从零适配。48 层 Gated DeltaNet、16 层 full attention、分块 prefill、递归状态管理、Triton scan/decode 都已接入。
2. 已经使用 checkpoint **真实 MTP-1 权重**，不是仅用 prompt lookup 冒充 MTP。15 组 MTP 参数完整加载，共享主模型 embedding/LM head，独立管理草稿 KV。
3. 批量目标验证与普通decode的数值一致性已修复：最新归档集256/256通过；旧版本184/256为历史失败，不能混作当前结果。
4. C1窗口使用中间状态提交、重放0；原eager阶段77.83低于基线87.41 output tok/s。最新显式验证Graph路径150.50高于eager基线88.52，但无草稿Graph控制仍更快；C2/C4独立接受已实现，尚未优化多请求Graph。
5. 下一步在已通过的多卡MTP Graph/连续补位路径上优化性能：减少Graph外草稿/事务/NCCL主机开销、每行投影/归约成本或prefill；扩大同配置严格对照和质量验收。SGLang可选数值后端的单卡收益及新旧差异见原报告，多卡新后端尚未独立验收。不要恢复旧失配路径或放宽阈值。
6. 用户当前聚焦 **Lumina 的 Qwen3.5、MTP 和线性注意力**。P-D、SGLang 二开和第二项目暂缓；用户本轮已明确要求多卡，普通TP2/4/8已实现；此前不扩TP8的边界已被覆盖。

## 2. 项目定位与环境

Lumina 是 PyTorch + Triton 的轻量 LLM 推理引擎，参考 vLLM 的连续批处理、分页 KV、调度与并行架构。代码包名是 `zjhvllm`，公开入口是 `from zjhvllm import LLM, SamplingParams`。
还支持 Qwen3 Dense / Qwen3-MoE，但不同模型的功能覆盖不同，Qwen3.5普通TP/原生Graph已独立实现验收，MTP后续也已支持TP1/2/4/8；MTP的验收与限制独立见 [MTP_TP.md](MTP_TP.md)。

| 项目 | 实际位置或版本 |
|---|---|
| 工作区 | `/home/jhzhou/sft_prj` |
| Lumina | `/home/jhzhou/sft_prj/Lumina` |
| conda | `lumina` |
| Python | `/home/data/jhzhou/conda_envs/lumina/bin/python` |
| PyTorch | `2.8.0+cu128` |
| Transformers | `5.20.1` |
| Triton | `3.4.0` |
| FlashAttention | 既有环境记录为 `2.8.3.post1` |
| 权重 | `/home/data/jhzhou/huggingface/Qwen3.5-27B` |
| 硬件 | 单机 8×A100-SXM4-80GB，共享服务器 |
| SGLang 结构参考 | `/home/jhzhou/sft_prj/sglang`，参考提交 `e2982985110fb432fd8ddba5f0147a5004fd03ab` |

约束与经验：

- 使用 `lumina` 环境，不要使用 LMCache/vLLM 的其他环境代替，不要为此升级现有基础包或重装驱动。
- 部分执行沙箱内 CUDA/NVML 不可见，需要在有 GPU 权限的执行环境运行。以前已验证驱动正常，不能仅根据沙箱返回认定服务器 CUDA 坏了。
- 没有 ncu 硬件计数器权限；可以用 nsys、NVTX、CUDA event、PyTorch profiler 和编译器属性，不以 sudo/root/ncu 为前提。
- 当前 `Lumina/` 没有独立 `.git`。实验复现主要依靠源码快照和 SHA256，先检查文件状态，不要假定可用 git 回滚。
- 八卡实验结束时全部释放、无遗留计算任务；这只是当时核查结果，接手后必须重新检查占用。
- 只结束自己创建并核实身份的 PID/进程组，不能 `pkill python`、清理其他用户任务或误杀编辑器、服务。
- 输出/实验使用新目录，保留旧失败 JSON、日志、源码快照，不覆盖历史证据。

建议每次开始先执行：

```bash
cd /home/jhzhou/sft_prj/Lumina
conda activate lumina
nvidia-smi
python -c 'import torch, transformers, triton; print(torch.__version__, transformers.__version__, triton.__version__); print(torch.cuda.is_available())'
```

## 3. 代码阅读地图

| 文件 | 作用与接手重点 |
|---|---|
| [config.py](zjhvllm/config.py) | 解包 `text_config`；MTP 显式开关、TP支持及请求容量约束 |
| [registry.py](zjhvllm/models/registry.py) | `qwen3_5_text → Qwen3_5ForCausalLM` |
| [qwen3_5.py](zjhvllm/models/qwen3_5.py) | 混合模型、norm/RoPE、GatedDeltaNet prefill/decode、全 token logits 开关 |
| [gated_delta.py](zjhvllm/layers/gated_delta.py) | Triton chunk scan 与原地 decode 递归更新 |
| [qwen3_5_mtp.py](zjhvllm/models/qwen3_5_mtp.py) | 真实 MTP 层与独立 SDPA 草稿 KV |
| [loader.py](zjhvllm/utils/loader.py) | checkpoint 名映射、MTP 参数完整性审计 |
| [attention.py](zjhvllm/layers/attention.py) | 目标模型 prefill 使用 FA varlen/paged KV，decode 使用自定义 paged kernel |
| [paged_attention.py](zjhvllm/layers/paged_attention.py) | full-attention decode kernel，需要纳入数值排查 |
| [model_runner.py](zjhvllm/engine/model_runner.py) | 分配 KV/S/conv，构建 context，保存 target hidden，MTP 草稿和两种验证模式 |
| [sequence.py](zjhvllm/engine/sequence.py) | token、缓存长度、状态槽、生成时间等元数据 |
| [scheduler.py](zjhvllm/engine/scheduler.py) | 连续批处理、分块 prefill、抢占重算、状态槽释放 |
| [block_manager.py](zjhvllm/engine/block_manager.py) | 分页 KV；`reserve_private` / `truncate_private` 验证窗口 |
| [speculative.py](zjhvllm/engine/speculative.py) | `HybridCheckpoint`、贪心接受前缀及 prompt lookup 对照；其“无 MTP 权重”模块注释只描述该辅助模块，不是引擎当前能力 |
| [llm_engine.py](zjhvllm/engine/llm_engine.py) | `step`、`speculative_step`、`generate_speculative`，负责元数据提交 |
| [context.py](zjhvllm/utils/context.py) | 全局前向 context、CPU/GPU 序列边界和状态槽；异常后必须 reset |

关键入口：`GatedDeltaNet._forward_prefill/_forward_decode/_recurrence`，`ModelRunner.run_model/record_target_hidden/draft_mtp/verify_greedy`，`LLMEngine.speculative_step/generate_speculative`。

## 4. Qwen3.5 结构及已完成适配

实际 27B text config：

| 项目 | 数值 |
|---|---|
| hidden / intermediate | 5120 / 17408 |
| 总层数 | 64：48 linear + 16 full，每四层最后一层 full |
| full-attention heads | Q=24，KV=4，head_dim=256 |
| RoPE | theta=10000000，partial factor=0.25，仅 64 维旋转 |
| linear heads | key=16，value=48，Dk=Dv=128 |
| causal conv | kernel=4，历史长度=3，通道=10240 |
| 激活/权重 | BF16；递归 S 为 FP32 |
| vocab | 248320 |
| MTP | 1 层，非 dedicated embeddings |

状态池布局：

```text
S_cache    [num_slots, 48, 48, 128, 128]  FP32
conv_cache [num_slots, 48, 10240, 3]      BF16
```

每请求 S+conv 约 153,944,064 字节（约 146.8 MiB）；checkpoint 只复制该请求全部线性层，不复制整个池。
各线性层拿到 `S_cache[:, layer_idx]` 的非连续 view，因此 slot/head stride 不能假定连续。
KV 只给 16 个 full-attention 层分配；MTP 另用私有 KV，不混入目标模型分页层数。

已经处理的结构细节：

- 多模态 checkpoint 的文本权重 `model.language_model.* → model.*`，跳过视觉；MTP 只在启用后加载。
- Qwen3.5 RMSNorm 使用 `(1 + weight)`；Gated DeltaNet 的 gated norm 有不同权重/舍入顺序，不能混用。
- full attention 的 Q projection 是每 head 的 query/gate 成对排列，输出乘 sigmoid gate。
- partial RoPE 保留 HF 激活 dtype 的中间乘积舍入，不能随意改回公共 RoPE 路径。
- 标准 Pre-LN residual，非此前其他模型可能采用的残差融合语义。
- linear prefill 跨 chunk 保留 S/conv，结束释放槽；抢占释放后从完整 token 前缀重算。
- hybrid 禁用仅 KV 的 prefix caching：复用 KV 不会自动恢复 S/conv。不要直接打开共享前缀。

线性注意力当前路径：

- `L <= 32` 的 `_recurrence` 是逐 token PyTorch recurrence；长输入采用 chunk=64、三角求解和 Triton chunk 间 scan。
- 默认 scan 是 `ieee`、8 warps；wrapper 显式处理三角求解产生的非连续输入。
- 普通 decode 走 Triton 原地状态更新，不 gather/scatter 完整 S；conv 仍有 PyTorch gather/拼接/分组 conv。
- `_forward_prefill` 使用 CPU 序列边界与状态槽元数据，避免 48 层逐次 GPU 标量同步。

## 5. MTP 的实际实现与限制

启用方式：`LLM(..., enable_mtp=True, max_num_seqs=1)`。
默认 `enable_mtp=False`，普通 `generate()` 不自动做投机；启用后调用 `generate_speculative()`，默认 `draft_method="mtp"`、`max_draft_tokens=1`、`verification_mode="serial"`。

多请求使用 `max_num_seqs=2/4` 和 `generate_speculative_batch(prompts, params)`，默认连续补位；`continuous=False`保留固定cohort，在线入口为`step_speculative()`。低层 `speculative_step_batch(seq_ids, drafts)` 对已prefill请求一次验证并分别提交，无跨请求min。普通单请求接口仍兼容。

真实权重包括 fc、embedding/hidden 两个 pre-fc norm、一个 decoder layer（attention/MLP/两处 norm）和 MTP final norm，共 15 组、424,699,392 参数，BF16 约 810 MiB。
embedding 和 LM head 使用主模型已有权重；任一 MTP 参数缺失都会报错。

位置 t 的条件是：

```text
embedding(token[t+1]) → pre_fc_norm_embedding ─┐
                                            ├→ concat(embedding first) → fc
target final-norm hidden[t] → pre_fc_norm_hidden ┘
→ 一个 full-attention decoder layer（RoPE position=t）→ MTP norm → 共享 LM head
```

不是使用 target 的 pre-norm hidden，也不是将两个分支拼接顺序颠倒。
`ModelRunner.target_hidden` 保存已计算位置的 target 最终 norm 输出。
当目标已有 C 个 cached input、一个待计算 token 时，MTP 只扩展到 C 个 `(h[t], token[t+1])` 配对。
接受一个草稿并输出 bonus 后，下轮扩展两个配对；拒绝后下轮只扩展一个，因此不让未提交的 target 后缀进入草稿 KV。

`MTPAttention` 使用按状态槽独立预分配的KV bank和逻辑 `lengths`，通过 `for_slot/get_length/set_length` 选择请求，内部使用PyTorch SDPA/GQA。新请求/重算清空该槽长度，批量目标异常恢复本轮所有请求的草稿长度。多请求 `target_hidden` 也按槽存储。
结构参考本地 SGLang `python/sglang/srt/models/qwen3_5_mtp.py`，Lumina 没有直接依赖 SGLang runtime。

当前明确限制：

- Qwen3.5文本、TP=1/2/4/8、EP=1，只支持MTP-1。`max_num_seqs`须显式选1–8；本轮验证C1/C2/C4，不宣称C8已验收。
- greedy argmax，repetition_penalty=1、top_k=-1、top_p=1；未实现随机采样的 speculative rejection sampling。
- 不支持视觉或随机拒绝采样；MTP已有多请求连续补位和多卡验证Graph，显式`verification_cuda_graph=True`开启。FP8/宽窗口/超过16种布局回退eager，草稿仍eager；未开启MTP的普通推理保留原生Graph。
- 通用草稿验证辅助接口最多 32 个草稿；这个上限不等于 MTP 已支持多步草稿。
- prompt lookup 只是显式 `draft_method="prompt_lookup"` 对照，不能用它替代用户要求的 MTP。
- 按请求管理target hidden、draft KV和接受/提交长度已实现；默认连续补位，完成请求释放槽后可在下一prefill轮接入等待请求。

## 6. 验证、提交与回滚语义

普通 prefill 生成首 token 后：缓存覆盖 prompt，最后生成的 token 尚未经过模型。
已完成 prefill 的运行请求持续保持：

```text
num_tokens = num_cached_tokens + 1
```

输入 K 个草稿时，目标验证输入是 `[原待计算 token] + draft[0:K]`，需要 K+1 行预测。
`compute_logits(..., all_tokens=True)` 只在验证路径显式启用，不能沿用普通 prefill 的“每序列只取最后一行”。

| 验证模式 | 行为 | 结论 |
|---|---|---|
| serial | 每个输入走普通 decode 的形状/内核，逐项接受，到拒绝或 bonus 停止 | 正确性参考，没有目标前向节省 |
| batched_experimental | 一次窗口遍历，内部逐token decode算子，各步S/conv暂存后按接受边界提交 | 最新256/256一致；常规MTP-1重放0 |

若第 j 个草稿拒绝（j 从 0 开始）：输出 j 个已接受草稿加 correction，共 j+1 个；实际提交输入是原待计算 token 加 j 个草稿，也为 j+1 个。
当前中间状态路径在验证期间不推进持久S/conv，拒绝时直接选择第j步的暂存状态。只有显式 `verification_state_commit=False` 或C1通用大窗口超过暂存预算时才恢复快照并重放。多余KV页回收，保留页中的无效后缀通过逻辑长度隐藏。
全接受则输出 K 个草稿加 bonus，直接保留相应状态；EOS 和 max_tokens 可提前结束，不能多提交输出预算。

事务分工：

- `verify_greedy/verify_greedy_batch`：S/conv快照、目标前向、逐请求接受、暂存状态提交；失败恢复本轮全部请求。旧C1重放分支保留为显式参考/大窗口回退，所有路径finally reset context。
- `speculative_step`：先原子预留私有页，成功后提交 token/长度，回收拒绝后缀；失败还原新增页。
- `generate_speculative`：组织真实 MTP 草稿与验证，目标异常时回退相应 MTP length；容量不足可退回普通 step。
- KV 验证页必须私有且禁用前缀共享；不允许覆盖共享 prefix 页。

已测试接受/各拒绝位置、EOS/预算、255/256/257 页边界、容量不足、重放故障、乱序/非连续槽位、真实 MTP 写入 KV 后异常及恢复普通生成。
这些局部/事务测试不替代整模型验收；当前完整C1归档及C2/C4配对验收另见最新报告。

## 7. 八卡证据：最新修复与保留的历史失败

2026-11-07最新目录：[qwen35_mtp_state_commit_8gpu_20261107](benchmarks/qwen35_mtp_state_commit_8gpu_20261107/)。C1完整128输入×两轮×三模式仍768次全完成，batch/serial各256/256一致、重放0、768/768资源回收；baseline与旧归档256/256一致。吞吐baseline87.41、serial85.84、batch77.83 output tok/s，batch目标前向13,352。另有C2/C4各32/32配对和C1同引擎重放A/B，见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。

2026-11-06数值修复目录：[qwen35_mtp_fixed_8gpu_20261106](benchmarks/qwen35_mtp_fixed_8gpu_20261106/)。精确复用下面旧归档的workload（文件字节相同），128输入×两轮×三模式，768次生成、72,834输出token。batch与serial各256/256一致，三模式各自跨卡128/128复现，768/768资源回收。`validation.json`数值验收为true。吞吐baseline87.58、serial87.23、batch76.69 output tok/s；没有加速。模型调用baseline24,588、batch14,760，后者不等于算子计算量同比减少。见[修复报告](MTP_NUMERICAL_FIX.md)。

以下保留修复前原始失败，不覆盖、不与最新指标混算：

目录：[benchmarks/qwen35_mtp_8gpu_20261106](benchmarks/qwen35_mtp_8gpu_20261106/)。
8 个独立 27B 单卡副本，每卡活跃并发1，总并发8；不是 TP8，也不是高并发 C128。
128 个不同输入 × 两轮 × 三模式 = 768 次测量生成，72,834 输出 token；预热不计入。

输入组成：自然语言34、AIME-2025题干30、真实本地函数前缀32、技术文档长片段32；输入20–2076 token，输出上限64/128，正常遵守 EOS；chat template 关闭 thinking，无 oracle 草稿或答案泄漏。
第二轮轮换物理 GPU 并反转模式顺序。三模式共用已加载引擎，基线也驻留 MTP 权重。

| 模式 | 对基线逐 token 一致 | 八卡 output tok/s | TTFT p99 | 平均 TPOT p99 | E2E p99 | 接受率 |
|---|---:|---:|---:|---:|---:|---:|
| 普通 decode | 两轮自身128/128一致 | 88.21 | 1477.40 ms | 90.35 ms | 12.221 s | — |
| MTP serial | 256/256 | 87.85 | 1473.31 ms | 91.41 ms | 12.384 s | 88.90% |
| MTP batched | 184/256 | 115.74 | 1473.98 ms | 74.52 ms | 9.941 s | 89.21% |

批量分歧：natural 30/68、math 6/60、code 10/64、long_context 26/64。
两轮各模式自身输出逐 token 相同，128/128 输入均换卡；即 36 个不同失败输入在两轮中稳定复现成 72 条失配。
所有 768 次 KV 页/状态槽完整回收。基线和 serial 各 24,588 次 target forwards，batch 为14,694次；batch 计数属于未验收路径。

**约31.2%的原始吞吐差值不能称为有效加速，28.1%请求输出不一致。**
该实验证明了跨卡复现和状态资源回收，不代表开放域任务准确率、HTTP服务 SLA、1→8扩展效率或MTP并发能力。
每模式256样本的p99是经验分位数；平均TPOT和输出批次间隔不能冒充投机同批token的逐token ITL改善。

证据入口：

- [REPORT.md](benchmarks/qwen35_mtp_8gpu_20261106/REPORT.md)：可读报告。
- [summary.json](benchmarks/qwen35_mtp_8gpu_20261106/summary.json)：总体、分类、失配ID、时延/吞吐。
- [validation.json](benchmarks/qwen35_mtp_8gpu_20261106/validation.json)：`measurement_complete=true`、`numerical_validation_passed=false`。
- [workload.json](benchmarks/qwen35_mtp_8gpu_20261106/workload.json)：固定的精确 token 输入；复现失败优先读它，不要重新生成近似文本。
- [manifest.json](benchmarks/qwen35_mtp_8gpu_20261106/manifest.json)、[checksums.json](benchmarks/qwen35_mtp_8gpu_20261106/checksums.json)：参数、输入及源码校验。
- `repeat{0,1}_{baseline,serial,batched_experimental}.gpu{0..7}.jsonl`：每请求完整输出、聚合接受/重放数、目标前向数和时间。
- `source/`：该次源码快照；`processes.json`、`workers.json`、`status.json`：进程和完成信息。

注意：大规模 JSONL 没有每轮草稿 token、逐层 hidden、S/conv 或 logits 转储。接手者需针对失败样本增加诊断，不要假定已有这些 trace。

## 8. 其他验证和已验证优化：不要与最新结果混算

### 8.1 HF 严格 logits 仍失败

[ALIGNMENT.md](ALIGNMENT.md) 是2026-11-01阶段记录。HF SDPA/FA2各8请求×8步，64/64 next-token argmax相同，但 raw logits 严格阈值失败：

| HF 参考 | max_abs | 最大RMSE | 失败步骤 |
|---|---:|---:|---:|
| SDPA | 7.546875 | 1.106640 | 29/64 |
| FA2 | 8.875000 | 1.416720 | 28/64 |

原阈值：max_abs≤1、RMSE≤0.1、近邻argmax gap≤0.25。保留失败和非零退出，不能把top1相同说成逐元素对齐。
HF自身batch形状/缓存前向也有显著BF16敏感性，但这不是“所有剩余误差都是舍入”的证明。
这批HF证据对应历史源码和有限短生成，不能自动视为当前MTP代码的完整HF验收。

### 8.2 线性注意力 prefill 优化

[PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md)：保持IEEE、chunk64、tile16，仅4→8warps，编译器 `n_spills` 1732→112。
27B、单卡单请求1024输入→1输出、eager，同一模型中位耗时0.917478→0.437165秒（2.10×），优化前后完整logits最大差异0。
算子1024长度整个chunk路径12.583→3.326ms，4096长度49.314→10.302ms。
这些只属于给定形状与旧阶段源码，不是MTP吞吐或所有长度的通用收益。

tf32x3虽然随机算子误差很小，整模型发生token632→2528翻转且HF top1 gap=3.25，因此没有设为默认。
nsys最终整请求中scan占比约58.4%→11.1%，BF16 GEMM约46.7%；“scan仍占九成”的旧定位已过时。
早期decode约7.8%整模型收益也是更早源码的历史数据，不能当当前性能验收。

### 8.3 非 MTP 的八副本与调度结果

- `benchmarks/service_8gpu/`：既有普通推理、总并发128，1157.5 output tok/s；每卡固定并发8时1→8副本扩展7.85×。不是MTP，也不是TP8，不能与本次C8的88.21 tok/s直接比较。
- [SCHEDULING_OPTIMIZATION.md](SCHEDULING_OPTIMIZATION.md)：CPU调度元数据缓存，4副本C16，吞吐573.7→602.1，ITL p99 879→688ms，1024请求hash相同，nsys同步1154→2。负载/源码特定，不等于生产SLA。
- [ADAPTIVE_SCHEDULING.md](ADAPTIVE_SCHEDULING.md)：adaptive跨策略400/1536输出不同，仍有HF regret残留，未验收，只显式实验选项。默认仍是alternating。
- 全仓历史回归曾有44 passed、1 failed（严格跨batch一致性），没有弱化原断言；当前不能宣称全仓全绿。

## 9. 已跑测试与最小启动

最新普通TP阶段为 **144 passed、0 skipped**，日志 `benchmarks/qwen35_tp_20261107/regression_production.log`。命令还需加入 `tests/test_qwen35_tp.py`；新原生Graph测试位于test_mtp_batch，超2^31地址测试位于test_gated_delta。

最新可选批量后端为 **135 passed、0 skipped**，日志 `benchmarks/qwen35_sglang_invariant_20261107/regression_final.log`。在下面命令再加入 `tests/test_invariant_linear.py` 即为本轮相关集；包括新旧后端及135项，非全仓。

最新验证Graph阶段为 **105 passed、0 skipped**，实际CUDA，日志 `benchmarks/qwen35_mtp_perf_20261107/regression_final.log`；下面97项为此前中间状态提交阶段。

历史MTP回归日志为71项，数值修复阶段为84项。最新连同多请求事务和GPU接受测试，共 **97 passed、0 skipped**，日志见 [regression_final.log](benchmarks/qwen35_mtp_state_commit_20261107/regression_final.log)；不要把这些说成全仓测试。

```bash
cd /home/jhzhou/sft_prj/Lumina
conda activate lumina
# 需要可访问GPU，检查测试确实运行，没有因CUDA不可见而全部skip。
python -m pytest tests/test_qwen35_mtp.py tests/test_speculative.py \
  tests/test_gated_delta.py tests/test_scheduler_state.py tests/test_scheduler_policy.py \
  tests/test_mtp_diagnostic.py tests/test_mtp_replica_report.py \
  tests/test_verification_decode_equivalent.py tests/test_mtp_batch.py -q
# 报告保护：CPU，不需要加载权重。
python -m pytest tests/test_mtp_replica_report.py -q
```

前者覆盖真实GatedDeltaNet、生产48头的128步递归对照、状态隔离与回滚、MTP增量/full、独立Transformers decoder/norm/RoPE组件对照、15组权重审计、embedding/hidden错位检查。
`tests/conftest.py` 有dist初始化fixture和其他模型路径；部分纯CPU测试覆写fixture。不要为跑无关HF fixture去改动共享环境。

单卡MTP示例（先确认物理GPU空闲，在进程启动前设置 `CUDA_VISIBLE_DEVICES`）：

```python
from zjhvllm import LLM, SamplingParams

llm = LLM("/home/data/jhzhou/huggingface/Qwen3.5-27B",
          enable_mtp=True, max_num_seqs=1, max_model_len=4096,
          max_num_batched_tokens=256, enforce_eager=True,
          gpu_memory_utilization=.85, distributed_port=2357)
try:
    result = llm.generate_speculative(
        "Explain how a hash table handles collisions.",
        SamplingParams(greedy=True, max_tokens=64),
        draft_method="mtp", max_draft_tokens=1,
        verification_mode="serial",  # 正确性参考，没有投机加速
    )
    print(result["token_ids"], result["rounds"])
finally:
    llm.exit()
```

改成 `batched_experimental` 可使用已修复的窗口验证；内部仍沿用逐token算子。eager版本较慢；构造LLM时再设 `verification_cuda_graph=True` 可启用最新C1验证Graph加速，首次捕获成本及适用边界见新报告。
多个引擎进程要独立 `distributed_port`，即便world_size=1也会初始化NCCL。
若自己创建长期benchmark，负责信号清理及进程组，不能只等父进程退出而留下GPU worker。

## 10. 下一步怎么做：按这个顺序

### P0：逐层定位与生产数值修复已完成

见 [MTP_NUMERICAL_DIAGNOSIS.md](MTP_NUMERICAL_DIAGNOSIS.md) 与 [MTP_NUMERICAL_FIX.md](MTP_NUMERICAL_FIX.md)：QKV投影和RMSNorm形状敏感差异已定位；生产验证和拒绝重放均使用decode一致路径，完整归档集已通过。`benchmarks/diagnose_mtp_verification.py` 当前默认比较生产修复路径，历史原始路径需使用对应源码快照。以下为当时排查方向；当前验证已统一到逐token decode，未来优化任何一项都须重新对照：

- full-attention：ordinary decode自定义paged kernel vs验证prefill的FlashAttention路径。
- linear attention：decode的Triton原地更新 vs短prefill逐tokenPyTorch recurrence；S/conv布局、精度与推进顺序。
- batch维度改变的BF16 Q/K/V、MLP及其他GEMM舍入；norm/gate顺序。
- 接受/拒绝后状态、KV逻辑长度和target hidden配对，尤其是重放后的下一轮。

先取八卡报告中的已知失败输入（生成token索引从0开始）：

| request_id | 类别 | 第一轮首次分歧索引 |
|---:|---|---:|
| 2 | natural | 3 |
| 39 | math | 86 |
| 76 | code | 11 |
| 127 | long_context | 70 |

建议从 `id=2` 开始，失败更早。复现入口：

```python
import json
from pathlib import Path
from zjhvllm import LLM, SamplingParams

workload = json.loads(Path("benchmarks/qwen35_mtp_8gpu_20261106/workload.json").read_text())
item = next(row for row in workload if row["id"] == 2)
llm = LLM("/home/data/jhzhou/huggingface/Qwen3.5-27B",
          enable_mtp=True, max_num_seqs=1, max_model_len=4096,
          max_num_batched_tokens=256, enforce_eager=True,
          gpu_memory_utilization=.85, distributed_port=2357)
params = SamplingParams(greedy=True, max_tokens=item["max_tokens"], ignore_eos=False)
try:
    outputs = {}
    for mode in ("baseline", "serial", "batched_experimental"):
        if mode == "baseline":
            result = llm.generate([item["prompt_token_ids"]], params, use_tqdm=False)[0]
        else:
            result = llm.generate_speculative(item["prompt_token_ids"], params,
                                             verification_mode=mode, draft_method="mtp")
        outputs[mode] = result["token_ids"]
    for mode in ("serial", "batched_experimental"):
        a, b = outputs["baseline"], outputs[mode]
        first = next((i for i, (x, y) in enumerate(zip(a, b)) if x != y), None)
        if first is None and len(a) != len(b):
            first = min(len(a), len(b))
        print(mode, "exact=", a == b, "first_divergence=", first)
finally:
    llm.exit()
```

该snippet提供复现方法，交接时没有为写文档再启动27B；具体结果以新运行记录为准，不能硬编码历史分歧索引来“通过测试”。

诊断应在首个分歧之前强制使用相同token历史、相同已提交状态和固定草稿，逐层比较hidden、S、conv、KV有效前缀、logits/top-k/gap。
先判定“当前预测已不同”还是“前一轮状态已漂移”。一旦两条自由生成历史分叉，后续logits不能直接拿来判定同输入误差。
建议新增小型诊断程序并保存源码SHA256、实际context长度、slots/page表和每轮草稿token；不要只追加一张输出文本截图。

### P1：保持数值修复，优化当前较慢的批量执行

本轮已完成四个失败样本、84项相关测试、完整128输入两轮和性能对照。下一步先profile逐token投影/norm/递归/attention及快照、重放开销，逐项设计更高效实现；必要时扩大真实输入和输出长度。
保持greedy严格输出比较和现有HF阈值，保留失败结果。目标是同一历史下数值路径可解释且候选输出通过，不能仅筛选易通过案例。
性能必须和正确性绑定、固定模型/长度/并发/硬件/源码、排除加载与JIT并记录预热；先别把更多卡当成定位单请求差异的替代。

### P2：固定cohort的多请求已实现，连续投机补位待做

已核查 SGLang 固定提交和本机 vLLM 0.11.0：两者相关路径按请求保存接受长度，没有跨请求取min。可移植设计和精确源码入口见 [MTP_BATCH_REFERENCE.md](MTP_BATCH_REFERENCE.md)，重点参考每步中间S/conv及按请求提交，先减少拒绝后的整模型重放，再实现多请求状态所有权。

上述每请求状态所有权、GPU独立接受、中间S/conv提交、页预留及草稿长度故障回滚已实现；C2/C4混合长短请求各32/32通过。详见 [MTP_STATE_COMMIT.md](MTP_STATE_COMMIT.md)。后续已实现结束后自动补位、混合prefill/投机decode与容量不足时的抢占重算，见MTP_CONTINUOUS_GRAPH.md；取消API、C8与高并发尾延迟仍未验收。

### P3：按新profile优化线性注意力与投机开销

候选包括decode conv的gather/concat、短验证recurrence的实现、scan前后布局/三角求解、约147MiB请求快照及拒绝重放成本。
真正热点需重新nsys确认；不要套用旧scan九成结论，也不要把有整模型翻转的tf32x3直接设默认。
中间状态保存已实现并验收；后续减少checkpoint复制、压缩暂存状态或多步MTP仍须独立输出/故障恢复验收。

## 11. 更大实验与既有工具

```bash
# 两GPU HF参考，需两张足够空闲80GB；已知严格阈值可能非零退出。
python -m benchmarks.validate_qwen35 --output /tmp/qwen35_hf_sdpa_new.json
python -m benchmarks.validate_qwen35 --hf-attention flash_attention_2 \
  --output /tmp/qwen35_hf_fa2_new.json
# 单卡真实MTP、三类32token及真实draft故障；旧结果为serial通过、batch未通过。
python -m benchmarks.validate_qwen35_mtp --output /tmp/qwen35_mtp_new.json
# 私有页/可控草稿验证；不是MTP业务加速测试。
python -m benchmarks.validate_qwen35_speculative --output /tmp/qwen35_spec_new.json
# 八GPU扩大测试：必须新目录，先确认八卡空闲；默认128输入、两轮三模式。
python -m benchmarks.bench_mtp_replicas --gpus 0 1 2 3 4 5 6 7 \
  --workload benchmarks/qwen35_mtp_8gpu_20261106/workload.json \
  --repeats 2 --output benchmarks/qwen35_mtp_8gpu_new
python -m benchmarks.report_mtp_replicas benchmarks/qwen35_mtp_8gpu_new
```

八卡输入数学题已在 [math.jsonl](benchmarks/qwen35_mtp_scale_inputs/math.jsonl) 提取，运行不依赖lumina安装pyarrow。
重新读取原始parquet时可用其他已有环境的pyarrow做纯数据导出，不要因此替换模型运行环境。
当前Transformers的 `apply_chat_template` 在该脚本显式使用 `return_dict=False`，保证拿到整数token列表；不要把BatchEncoding的键当token，输入预检必须保留。
重新生成测试集可能受当前源码/文档影响；准确复现旧失败优先使用归档workload，而不是重新构造文本。

Profile优先读 [PREFILL_OPTIMIZATION.md](PREFILL_OPTIMIZATION.md) 的nsys命令。`bench_nsys.py`旧默认是Qwen3-0.6B，不能直接冒充Qwen3.5 profile。

## 12. 文档和其他项目边界

- 当前入口：本文 → [SPECULATIVE_DECODING.md](SPECULATIVE_DECODING.md) → [MTP_SCALE.md](MTP_SCALE.md) → 原始报告。
- [TUTORIAL.md](TUTORIAL.md)、[RESUME_PREP.md](RESUME_PREP.md) 是用户常读的解释文档，稳定结果后同步。
- [HANDOFF.md](HANDOFF.md)、`/home/jhzhou/sft_prj/任务.md` 和 Claude JSONL 主要用于历史交接，可能包含后来已改变的优先级。
- 历史Claude记录目录：`/home/jhzhou/.claude/projects/-home-jhzhou-sft-prj/`；主要Lumina会话曾为 `e6da0cab-563a-49d4-af9d-36b3f1f8d87b.jsonl`。没有必要重读全部历史才开始P0。
- `/home/jhzhou/sft_prj/sx/infra简历.tex` 是简历；用户本轮要交接，不要擅自把未验收MTP加速写入简历。
- `/home/jhzhou/sft_prj/LMCacheLab`、`CUDA-Kernel-Library`、DecodeAttentionLab等是其他项目，当前暂停；LMCache目录的AGENTS规则不能自动套用于Lumina。
- P-D仅有KV交接等先前阶段工作，不应默认支持Qwen3.5的S/conv迁移，也不是当前主线。

## 13. 可以直接给下一位 AI 的启动指令

> 请先阅读 `/home/jhzhou/sft_prj/Lumina/QWEN35_HANDOFF.md`、`MTP_CONTINUOUS_GRAPH.md`、`MTP_TP.md` 与 `QWEN35_TP.md`。普通推理和真实MTP-1均已支持TP1/2/4/8、EP1；多卡多请求验证Graph与连续补位也已实现，不要重做接线。`verification_cuda_graph=True`开启目标验证Graph，`generate_speculative_batch()`默认连续补位，在线入口`step_speculative()`，保留`continuous=False`控制。162项相关CUDA回归通过；正式证据在`benchmarks/qwen35_mtp_continuous_graph_20261107`。保留单token BF16 GEMM/NCCL归约形状，不放宽Graph/eager逐token比较；跨prefill调度方式仍可能有数值差异，cohort要用对应ordinary控制。下一步扩大质量/容量验收、减少Graph外草稿/事务/NCCL主机开销，优化prefill，不再把单请求或C4小集当C128容量。普通非MTP C128的1779/2651/3208解码tok/s属于另一实验。可选batch_invariant多卡/HF严格logits未新验收；随机采样与HTTP自动MTP未实现。保留失败、完整输出、源码快照，先查GPU占用，只清理自有进程，仅修改Lumina。
