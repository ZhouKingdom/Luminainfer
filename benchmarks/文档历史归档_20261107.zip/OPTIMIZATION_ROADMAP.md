# zjhvllm 优化路线图（AI Infra 实习简历向）

> 目标：把一个"能跑"的从零 vLLM 实现，变成一个在 AI Infra 面试里**有深度、有数据、有故事**的项目。
> 每个方案都标注：现状代码定位 → 做法 → 难度/工期 → 简历上能写的一句话。

---

## 0. 现状盘点（先搞清楚你已经有什么，别浪费）

这个项目底子其实不错，以下是你**已经实现、可以直接写进简历**的点：

| 能力 | 代码位置 | 面试价值 |
|---|---|---|
| 连续批处理（Continuous Batching）| `engine/scheduler.py`：prefill/decode 交替、chunked prefill、抢占 | ⭐⭐⭐ 核心概念 |
| Paged Attention + 前缀缓存 | `engine/block_manager.py`：物理块、hash 前缀复用 | ⭐⭐⭐ |
| 张量并行（TP）| `layers/linear.py` + `engine/model_runner.py`：NCCL + spawn 子进程 | ⭐⭐⭐ |
| CUDA Graph 解码 | `engine/model_runner.py:capture_cudagraph` | ⭐⭐ |
| 手写 Triton 采样器 | `layers/sampler.py`：top_k/top_p 二分阈值、Gumbel-max、Philox 可复现 | ⭐⭐⭐ |
| Flash Attention | `layers/attention.py`（varlen + kvcache）| ⭐⭐ |

**关键短板**（面试官一定会问、也是优化机会）：
1. 只支持 Qwen3 一种模型，没有模型抽象/注册机制。
2. 没有正确性测试 —— "你怎么证明你的实现是对的？"这是 AI Infra 面试的第一杀。
3. 没有服务层（HTTP/OpenAI 兼容），只能跑脚本。
4. 没有量化（FP8 KV cache / 权重量化）。
5. 没有 speculative decoding、没有 MoE。
6. TP 通信用 `pickle` 走 1MB 共享内存 RPC，比较朴素。

---

## 1. 优先级总览

| 优先级 | 方案 | 难度 | 工期（业余）| 简历杠杆 |
|---|---|---|---|---|
| **P0** | 正确性测试套件 | 低 | 1 周 | 极高（信任基石）|
| **P0** | OpenAI 兼容 HTTP 服务 + 流式 | 中 | 1~2 周 | 极高（从"库"变"产品"）|
| **P0** | 多模型支持 + **MoE** | 高 | 3~4 周 | 极高（架构深度）|
| **P1** | FP8 KV cache 量化 | 中 | 1~2 周 | 高（内存减半）|
| **P1** | Speculative Decoding | 高 | 3~4 周 | 极高（旗舰性能）|
| **P1** | 融合 Triton kernel（RMSNorm/RoPE/SiLU）| 中 | 1~2 周 | 高 |
| **P2** | 自研 Paged Attention kernel | 高 | 2~3 周 | 高 |
| **P2** | logprobs / beam search / 结构化输出 | 中 | 1~2 周 | 中 |
| **P2** | TP 通信优化 / 多节点 | 高 | 3~4 周 | 高 |
| **P2** | 性能剖析 + 压测基建 | 低 | 0.5 周 | 中 |

---

## 2. P0 方案详解

### 2.1 正确性测试套件（最先做，别跳过）

**为什么是第一位**：面试官拿到一个"从零实现的推理引擎"，第一个问题就是"你怎么验证它输出是对的"。没有测试，前面所有优化都没有可信度。

**做法**：
1. 用 HuggingFace `transformers` 作参考，对同一模型、同一 prompt、`greedy` + 固定 seed，逐 token 比对输出 ID。
2. 覆盖几条关键路径，每条都要测：
   - 单条 prefill+decode（最基础）
   - **prefix caching**：两条共享前缀的序列，第二条要走缓存路径，结果仍一致
   - **preemption**：KV 块耗尽触发抢占后，输出仍一致
   - **chunked prefill**：长 prompt 被切块，结果一致
   - **tensor_parallel_size=4** 与 tp=1 输出一致
   - **采样**：`top_k`/`top_p`/`repetition_penalty` 与参考实现对齐（可对照 vLLM 或手写 numpy 参考）
3. 数值层面：除了 token ID，最好再比一比 `logits` 的 max abs diff（`< 1e-3` 量级），能覆盖更多细节。

**关键点**：你现在 `Sampler` 里 Gumbel-max、top_k/top_p 二分阈值这些是**最容易有静默 bug** 的地方，一定要单独测。

**简历卖点**："为推理引擎建立端到端正确性测试，覆盖 paged attention / prefix caching / preemption / tensor parallelism 四条路径，与 HuggingFace 逐 token 对齐"。

---

### 2.2 OpenAI 兼容 HTTP 服务 + 流式输出

**为什么**：绝大多数 AI Infra 实习 JD 都写"熟悉推理服务/部署"。把一个引擎包成 OpenAI 兼容服务，是把它从"玩具"变成"产品"的关键一步，也是最容易被面试官在简历上注意到的点。

**做法**：
1. 用 FastAPI + pydantic 实现 `/v1/completions` 和 `/v1/chat/completions`（至少前者）。
2. **流式输出（SSE）**：这是关键 —— 现在 `generate()` 是一次性返回的。要把 `LLMEngine.step()` 循环拆成可增量产出的形式，每生成一个 token 就 push 出去。`engine/llm_engine.py:generate()` 里的 `while not self.is_finished()` 循环就是天然的改造点。
3. 异步并发：用 `asyncio` + 一个后台线程跑 `step()`，多个请求共享同一个 scheduler（这才是 continuous batching 的意义 —— 展示"多请求如何共享一次前向"）。
4. 顺带做：请求队列、max_tokens 限制、简单的并发压测。

**简历卖点**："将引擎封装为 OpenAI 兼容的流式服务，支持多请求并发共享一次前向（continuous batching 的完整闭环），TTFT/TPOT 下降 X%"。

---

### 2.3 多模型支持 + MoE（最有深度的方向）

**为什么**：从"只跑 Qwen3"到"支持多个模型家族"，是架构能力的直接证明。而 **MoE 是当前 LLM 推理最热的话题**（DeepSeek-V3/R1 就是 MoE），面试官对"你懂不懂 MoE 的专家并行和稀疏激活"会非常感兴趣。

**第一步：模型抽象（难度中，1 周）**
- 现在 `models/qwen3.py` 把 Qwen3 的层结构写死。抽象出一个 `ModelRegistry` / 基类，用 config 的 `architectures` 字段分发。
- 加 Llama-3、Mistral、Qwen2 这类 dense 模型（层结构大同小异，主要差在 norm 位置、rope 参数、GQA 头数）。

**第二步：MoE（难度高，2~3 周，含金量最高）**
- 目标：支持 Qwen3-MoE / DeepSeek-V3 这类稀疏专家模型。
- 核心要解决：
  1. **Router + top-k 专家选择**：每个 token 走 top-k 个专家，不是全量 FFN。
  2. **专家并行（EP）**：专家权重分布在多卡上，token 通过 all-to-all 路由到对应专家的卡。这比 TP 更难，是你现有 `layers/linear.py` 里没有的东西。
  3. **专家权重分片 + 稀疏激活**：显存占用不是 671B 全加载，而是按卡分专家。
- 简历卖点（这条最强）："支持 MoE 架构（专家并行 + all-to-all 路由 + top-k 稀疏激活），能在 X 张 A100 上跑通 DeepSeek-V3 规模的稀疏模型"。

> 如果时间紧，只做到 dense 多模型 + 把 MoE 的**方案设计文档**写出来，也很值 —— 面试时你能讲清楚 EP 和 all-to-all 就比大多数人强。

---

## 3. P1 方案详解

### 3.1 FP8 KV cache 量化

**为什么**：KV cache 是显存大头。把 KV 从 bf16 换成 FP8（E4M3），KV 显存直接减半 → 同样显存下上下文长度翻倍、或 batch 翻倍。这是"内存效率"最直接的体现。

**做法**（定位到现有代码）：
1. `engine/model_runner.py:116` 分配 KV cache 时，dtype 改成 `torch.float8_e4m3fn`。
2. `layers/attention.py` 的 `store_kvcache_kernel` 写入时做 `bf16→fp8` 量化，读入 flash_attn 前做 `fp8→bf16` dequant。
3. 关键是要做**逐块/逐 token 的 scale**（per-token or per-block quantization），保证精度损失可控，否则输出会漂。
4. 用 2.1 的正确性测试验证量化后输出仍对齐（max abs diff 可接受）。

**简历卖点**："实现 FP8 KV cache 量化（per-block scale），KV 显存占用下降 50%，支持更长上下文 / 更大 batch"。

---

### 3.2 Speculative Decoding（旗舰性能优化）

**为什么**：这是推理加速里最有故事、最能体现"懂 attention 和 decode 瓶颈"的方向。decode 阶段是 memory-bound（每步只算 1 个 token），speculative decoding 用一个小模型一次性猜 K 个 token，大模型并行验证，命中就一次推进多步。

**做法**：
1. 最简单版本：draft model（同家族的 0.6B）跑 K 步，target model（32B）一次性验证 K 个 token 的 logits，比对是否一致，接受前缀。
2. 更进阶：EAGLE（用 target 的 hidden state 做 draft）或 Medusa 头。
3. 改造点：`engine/scheduler.py` 需要引入"speculative 调度"（draft 的 K 步 + target 的 1 次验证），`Sampler` 需要"接受/拒绝"逻辑（对比 draft token 和 target argmax，逐位接受直到第一次不匹配）。

**简历卖点**："实现 speculative decoding，decode 吞吐提升 1.5~2.5x"（这是能上简历的硬数字）。

---

### 3.3 融合 Triton kernel

**为什么**：你现在 RMSNorm、RoPE、SiLU 用的是 `@torch.compile`（`layers/layernorm.py`、`layers/rotary_embedding.py`、`layers/activation.py`），能跑但对 kernel 的掌控力弱。自己写融合 kernel 是"会写 Triton"的直接证明，也是 AI Infra 面试常考点。

**具体可做的**：
1. **RMSNorm + residual 融合**：`layernorm.py:add_rms_forward` 现在是 `@torch.compile` 的 elementwise，且有 `.float()` upcast。写成一个 Triton kernel，去掉显式 float 往返。
2. **RoPE 融合进 QKV**：`rotary_embedding.py:apply_rotary_emb` 有 `x.float()`、`chunk`、`cat` 三次显存往返。可以在 QKV 线性层输出后直接融合 RoPE，避免中间张量。
3. **SiLU+gate 融合**：`activation.py` 的 `SiluAndMul` 已经挺简单，可以和第 1 条一起做成统一的融合 pass。
4. 衡量标准：用 nsys 或 `torch.cuda.Event` 测每个 kernel 的耗时，给出前后对比。

**简历卖点**："手写融合 Triton kernel（RMSNorm+residual、RoPE 融合），减少 kernel launch 与显存往返，prefill 耗时下降 X%"。

---

## 4. P2 方案简述

### 4.1 自研 Paged Attention kernel
现在 `layers/attention.py` 依赖 `flash_attn_with_kvcache`。可以自己写一个 Triton 的 paged attention kernel，处理 `block_table` 索引 + `block_size` 跨块。难度高但"从 flash-attn 库解耦"本身就是能力的证明（vLLM 早期也这么干过）。

### 4.2 logprobs / beam search / 结构化输出
`Sampler` 已经能 greedy/top_k/top_p/repetition_penalty。补上：
- `logprobs` 输出（推理服务标配，用户要拿概率）
- beam search（`scheduler.py` 需要维护 beam 状态）
- guided decoding / JSON 模式（用 logit mask 约束）

### 4.3 TP 通信优化 / 多节点
- 现状：LM head 用 `dist.gather`（`embed_head.py:63`），RowParallelLinear 用 `all_reduce`（`linear.py:155`），rank0→worker 用 `pickle` 走 1MB 共享内存（`model_runner.py:69-84`）。
- 优化方向：通信与计算 overlap；decode 阶段 all-reduce 的量很小，可以合并；RPC 用更高效协议替代 pickle。
- 多节点：NCCL 从 `tcp://localhost:2333` 改成跨机地址（需 IB/RoCE 或高带宽网）。

### 4.4 性能剖析 + 压测基建
- 用 `nsys` / `ncu` 剖析 prefill 和 decode 的 kernel 时间分布。
- 做一个自动 benchmark 脚本，测不同 `num_seqs`、`max_model_len`、`tp_size` 下的吞吐/TTFT/TPOT。
- 简历卖点："建立性能剖析与压测体系"。

---

## 5. 推荐的「4 周冲刺组合」

如果你时间有限，按这个顺序做，性价比最高：

1. **第 1 周**：正确性测试套件（2.1）+ 把 `bench.py` 扩成能测 TTFT/TPOT/吞吐的压测脚本（4.4）。→ 先有"信任"和"数据基线"。
2. **第 2 周**：OpenAI 兼容服务 + 流式（2.2）。→ 从库变产品。
3. **第 3~4 周**：FP8 KV cache（3.1）或 speculative decoding（3.2）二选一。→ 拿到一个能写进简历的硬性能数字。

> MoE（2.3）是含金量最高但最费时的，如果实习目标是大厂推理组（vLLM/SGLang/DeepSeek 那类），值得优先投入；如果时间紧，先用上面 4 周组合把项目打磨完整，MoE 作为"进行中"的方向在简历和面试里讲。

---

## 6. 简历呈现建议

**项目一句话（示例）**：
> 从零实现一个 vLLM 风格的 LLM 推理引擎（Python + PyTorch + CUDA/Triton），支持连续批处理、Paged Attention + 前缀缓存、张量并行、CUDA Graph 解码与手写 Triton 采样内核；实测 Qwen3-32B 在 4×A100 上解码吞吐 ~3000 tok/s。

**量化指标（一定要有数字）**：
- 吞吐 / TTFT / TPOT（你已经跑出 `2995 tok/s` 这个数了）
- KV cache 显存占用 / 支持的最大上下文长度
- 支持模型的 GPU 数、模型规模
- 每个优化前后的对比（"FP8 让 KV 显存 -50%"、"spec decode 让 decode +2x"）

**面试常问（提前准备）**：
- 为什么 decode 是 memory-bound、prefill 是 compute-bound？
- Paged Attention 相比朴素 KV cache 解决了什么？`block_table` 怎么索引？
- 连续批处理里 prefill 和 decode 怎么交替、为什么 decode 优先？
- 前缀缓存的 hash 碰撞怎么处理？抢占策略是什么？
- 张量并行里哪些层是 column-parallel、哪些是 row-parallel？为什么 row-parallel 需要 all-reduce？

---

## 7. 附：当前代码里几个可以直接改进的小点（顺手做）

1. `engine/model_runner.py:69-84`：共享内存 RPC 的 buffer 只有 1MB（`size=2**20`），大 batch 时 pickle 可能超限。改成动态扩容或换 `Pipe`。
2. `utils/context.py`：`_CONTEXT` 是全局单例，靠 `set_context/reset_context` 手动管理，非线程安全且容易漏 reset。可以改成把 context 显式传进 forward，或至少用 `contextmanager` 保证成对。
3. `layers/rotary_embedding.py:11`：`apply_rotary_emb` 里 `x.float()` 上转 + `chunk/cat` 有三次显存往返，是 prefill 里可观的浪费（正是 3.3 的切入点）。
4. `layers/sampler.py:279`：`logits.float()` 每个 decode step 都分配一个 `[num_seqs, vocab]` 的 fp32 张量（256×151936×4B ≈ 155MB），可以复用 buffer 或部分保持 bf16。

---

*这份文档是路线图，不是任务清单。建议先从第 2.1（正确性测试）和第 5 节的 4 周组合开始动手。任何一条想展开成具体实现方案，随时叫我。*
