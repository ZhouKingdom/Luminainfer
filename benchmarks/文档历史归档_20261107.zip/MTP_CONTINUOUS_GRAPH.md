# 多卡 MTP 验证 Graph 与连续补位

Qwen3.5-27B 的 MTP-1 支持 TP=1/2/4/8 的多请求目标验证 CUDA Graph，以及调度器驱动的连续补位。`generate_speculative_batch()` 默认连续调度；需要固定 cohort 控制时显式传 `continuous=False`。

```python
from zjhvllm import LLM, SamplingParams

llm = LLM('/home/data/jhzhou/huggingface/Qwen3.5-27B',
          tensor_parallel_size=4, enable_mtp=True, max_num_seqs=4,
          max_model_len=4096, max_num_batched_tokens=512,
          verification_cuda_graph=True, enforce_eager=True,
          distributed_port=2490)
try:
    outputs = llm.generate_speculative_batch(
        prompts, SamplingParams(greedy=True, max_tokens=128))
finally:
    llm.exit()
```

`enforce_eager` 控制普通 decode Graph，`verification_cuda_graph` 独立控制目标验证 Graph。普通 `generate()` 保留非投机行为。启动前设置足够且空闲的 `CUDA_VISIBLE_DEVICES`。

需要在线请求时，调用 `add_request(prompt, params)`，重复调用 `step_speculative()`；可以在两次 step 之间继续 add_request。返回值与普通 step 一致：完成请求、token 计数、`(seq_id, token_id)` 流。一个投机轮可以流出同一请求的多个 token。`last_speculative_stats` 保存该轮各请求的独立接受与 Graph 使用情况。

## Graph 行为

- 所有 rank 同步预热、捕获和重放目标模型的 NCCL 行并行归约，继续使用单 token GEMM/归约形状，保持同配置 greedy 算术路径。
- 按每请求窗口长度的 tuple 缓存，例如 `(2,2,2)`、`(2,1)`、`(1,)`；支持不同输出预算导致的混合窗口。MTP-1 每请求1或2行，不填充请求或重复状态槽。
- 每次重放更新 input、position、物理 KV slot、状态槽、页表和有效 causal 长度。新请求可以复用刚释放的槽位和页，不绑定首次捕获的请求。
- S/conv 的中间状态写入预留 scratch，接受、状态提交和 target hidden 发布仍在 Graph 外。草稿层、采样决策和调度也在 Graph 外。
- 同一 scratch 下最多缓存16种布局，共享 CUDA Graph 内存池；更多布局、FP8 KV 或宽于 MTP-1 的窗口回退 eager。不随运行请求数量无限扩张 Graph 缓存。
- Graph 元数据分配先跨 rank 检查错误，已覆盖单 rank 分配失败后的全 rank 回滚与继续运行；NCCL/进程故障仍为引擎级失败。

## 连续补位与容量回退

`step_speculative()` 使用普通调度器的 prefill/decode 决策。分块 prefill 与投机轮交替，完成请求立即释放 S/conv 槽和 KV 页，等待请求可在下一次 prefill 轮进入；不等整个 cohort 完成。输出结果保持输入顺序。

重新分配槽位时，目标递归状态清零、草稿逻辑 KV 长度重置，target hidden 的新前缀重新计算。验证页或工作区不足时恢复草稿长度，直接执行已预留的普通 decode 批次，避免二次调度改变请求集合。抢占仍通过完整前缀重算恢复混合状态。

新增修复：唯一 decoder 跨页时，若部分 prefilling 请求持有可回收页，先抢占该部分 prefill；避免先抢占 decoder 后等待队首需要更多页、队尾又占着剩余页的死锁。两页容量、255-token 输入及反复抢占的回归可完成并释放全部资源。

## 验收与指标

162项相关CUDA回归通过、无skip，覆盖页边界、槽位复用、混合接受/预算、EOS、在线到达、内存回退、抢占和故障恢复。真实模型共96/96次连续MTP生成与相同TP普通解码逐token一致；C4小负载预热后TP2/4/8约23.05/26.68/26.26 output tok/s，Graph冷启动与eager分列，不代表高并发容量。

故障退出还加入Python引用环回收和销毁通信组前的跨rank同步；分布式测试必须在全部子进程退出后才标记processes_exited。

真实模型、分布式测试与吞吐见 [本轮报告](benchmarks/qwen35_mtp_continuous_graph_20261107/REPORT.md)。

Graph 预热/捕获与预热后的测量分列；吞吐只计输出 token，E2E 包含 prefill 和各 rank 有限值检查。Graph+MTP 相对普通 eager 的差异不能单独归因于投机算法。

连续和固定 cohort 会改变 prefill 的打包/执行形状；BF16 下不能宣称跨任意调度方式逐位一致。严格比较使用相同 TP、数值后端与对应调度配置。报告保留跨调度差异，连续 Graph 与连续 eager/普通基线的逐 token 比较不放宽。

仍限定 greedy、MTP-1、显式 `max_num_seqs=1–8`。本轮真实模型容量为4，未将其称为C128或几千token/s的容量评测；随机拒绝采样和HTTP服务层自动切换MTP不在本轮范围。
