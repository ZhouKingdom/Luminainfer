# MoE 设计与专家并行（EP）方案

## 当前已完成

- `layers/moe.py`：`MoE` 层（router `gate` + top-k 专家选择 + 稀疏激活 FFN），`ExpertFFN` 复用 TP-aware 的 `MergedColumnParallelLinear`/`RowParallelLinear`。
- `models/qwen3_moe.py`：`Qwen3MoeForCausalLM`，复用 Qwen3 的 attention/norm/embedding/lm_head，仅 MLP 换成 MoE。
- `models/registry.py`：按 `config.model_type` 分发（`qwen3` / `qwen3_moe`）。
- 权重加载：专家 `gate_proj`/`up_proj` 通过 `packed_modules_mapping` 合并进 `gate_up_proj`，router `gate.weight` 走默认加载。
- **专家并行（EP）**：`layers/ep_moe.py` 的 `ExpertParallelMoE`——router replicated + 本地专家 + all-to-all dispatch/combine。已用多卡（4×A100）验证：EP 输出与单卡全量 MoE 输出误差 ~8e-8。
- 测试：`tests/test_moe.py`（单卡 MoE）、`tests/test_ep_moe.py`（EP 多卡验证，子进程 `_ep_runner.py`）。

## 专家并行（EP）——已实现核心

MoE 的核心问题：模型**总参数量大**（如 DeepSeek-V3 671B），但每个 token 只激活 top-k 个专家（稀疏激活）。EP 把**整个专家**分布到不同卡上，而不是像 TP 那样把每个专家内部切开。

### 数据流

设 E 张卡，N 个专家，每卡 N/E 个专家，每个 token 激活 top-k 个专家：

```
        [token hidden states, 形状 [num_tokens, hidden]]
                          │
                          ▼
        ┌─────────────────────────────────┐
        │  Router（每卡都有一份，replicated）│
        │  → 每个 token 选出 top-k 个专家 id │
        └─────────────────────────────────┘
                          │
                          ▼
        ┌─────────────────────────────────┐
        │  all-to-all 通信（permute/dispatch）│
        │  把每个 token 发到它选中的专家所在的卡 │
        └─────────────────────────────────┘
                          │
        ┌──────────┬──────────┬──────────┐
        │ 卡 0：专家 0.. │ 卡 1：专家 ...│ ...     每卡只算自己本地专家
        │ 算本地专家 FFN │          │          │
        └──────────┴──────────┴──────────┘
                          │
                          ▼
        ┌─────────────────────────────────┐
        │  all-to-all 通信（unpermute）      │
        │  把专家输出送回 token 原所在卡       │
        └─────────────────────────────────┘
                          │
                          ▼
                 加权求和（top-k 权重）→ 输出
```

### 关键点

1. **Router 是 replicated**：每张卡都有完整的 router（很小），各自算出自己 token 的 top-k 专家。
2. **all-to-all 通信**：token 按「目标专家所在卡」分组，一次 `all_to_all` 交换。这是 EP 的核心通信开销，也是面试必考点。
3. **稀疏激活**：每张卡只存 N/E 个专家的权重。DeepSeek-V3（256 专家，8 卡 → 每卡 32 个专家）单卡权重从 671B 降到 ~84B，显存瓶颈大幅缓解。
4. **与 TP 组合**：EP 切专家 + 每个专家内部再 TP 切（2D 并行），是 DeepSeek 这类超大 MoE 的标配。
5. **负载均衡**：不同 token 命中的专家不同，可能某卡专家被集中命中（热点），需要 aux loss 或平衡策略。

### 实现切入点（对现有代码）

- 现有 `layers/linear.py` 只实现了 TP（column/row 并行）。EP 需要新增一个 **MoE 前向的 all-to-all 调度**：在 `MoE.forward` 里，把「本地专家计算」和「all-to-all dispatch」分开。
- 复用 `torch.distributed.all_to_all_single`（或 NCCL group 的 all_to_all）做 token 的 permute/unpermute。
- 权重加载：EP 下每个 rank 只加载自己那部分专家的权重（`weight_loader` 按 rank 过滤专家 id）。

### 8 卡资源规划（Qwen3-30B-A3B 为例）

- 模型：30B 总参 / 3B 激活，128 专家，top-8。
- 单卡（TP=8）：8 卡各存 30B/8 ≈ 3.75B 权重，能跑但不优雅。
- **EP=8**：8 卡各存 16 个专家（128/8），每卡 ~3.75B 权重，token 通过 all-to-all 只路由到 8 个活跃专家所在卡。这才是 MoE 的正确打开方式。

## 当前状态与下一步

- ✅ **下载 Qwen3-30B-A3B 跑通真实 MoE**：TP=4 跑通 generate。
- ✅ **EP 接入 engine**：`expert_parallel_size` 配置 + `utils/tp.py` 解耦 TP 维度 + MoE 层 all-to-all + 专家权重按 rank 过滤加载。真实模型用 **EP=8 跑通**（每卡 16 专家 + all-to-all，输出与 TP=4 一致）。
- ⏳ **负载均衡**（aux loss / expert 均衡，避免专家热点）。
- ⏳ **EP + TP 2D 并行**（专家并行切专家 + 每个专家内部再 TP 切），DeepSeek 这类超大 MoE 的标配。

> 注意：Qwen3-30B-A3B 的 `num_key_value_heads=4`，纯 TP 最大 4。EP=8（128 专家/8 卡）比 TP=4 每卡显存更省，且能上满 8 卡。
